package com.notes.polymorphic05;
//多态参数
//方法定义的形参类型为父类类型，实参类型允许为子类类型
public class PolyParameter {
    /*定义员工类Employee，包含姓名和月工资，以及计算年工资getAnnual的方法
    普通员工和经理继承了员工，经理类多了奖金bonus数学和管理manage方法，普通员工类多了
    work方法，普通员工和经理类要求分别重写getAnnual方法
    * */
    public static void main(String[] args) {
        /*测试类中添加一个方法showEmpAnnual(Employee e)，
        实现获取任何员工对象的年工资，并在main方法中调用该方法
        * */
        Worker tom = new Worker("tom", 2500);
        Manager milan = new Manager("milan", 5000, 200000);
        PolyParameter parameter = new PolyParameter();
        //方法定义的形参类型为父类类型，实参类型允许为子类类型
        parameter.showEmpAnnual(tom); //由于动态绑定机制,
        //1. 当调用对象方法的时候，该方法会和该对象的内存地址/运行类型绑定
        //2. 当调用对象属性时，没有动态绑定机制，哪里声明，哪里使用
        // tom的运行类型（看右边）为Worker
        //所以在调用方法时，也有运行类型Worker决定，即tom.getAnnual() ,会去查找Worker类中的getAnnual方法并调用
        parameter.showEmpAnnual(milan); //milan运行类型为Manager

        parameter.testWork(tom);
        parameter.testWork(milan);
    }
    //形参类型Employee为父类，把子类类型作为实参传给e,父类的引用指向了子类对象，向上转型
    public void showEmpAnnual(Employee e) { // e --> tom
        System.out.println(e.getAnnual()); //根据传入的实参对象，调用不同子类中的getAnnual方法
    }
    public void testWork(Employee e) { //用父类来接收子类对象实参
        if (e instanceof Worker) { // 判断子类对象的运行类型是否为Worker类型
            //要求父类的引用必须指向的是当前目标类型的对象，即e之前指向的是Worker类型，才能把它向下转型
            Worker worker = (Worker) e; //向下转型，把父类的引用强转为子类类型  子类类型 引用名 = （子类类型）父类引用名
            worker.work();//当向下转型后，可以调用子类类型中的所有成员(属性、方法)
            // ((Worker) e).work(); //向下转型，这样写也可以
        } else if (e instanceof Manager) { //判断子类对象的运行类型是否为Manager类型
            Manager manager = (Manager) e;
            manager.manage(); //调用子类Manager中的方法
        }
    }
}
class Employee { //员工类
    private String name = null;
    private double salary; //月工资

    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public double getSalary() {
        return  salary;
    }
    public void setSalary(double salary) {
        this.salary = salary;
    }
    //得到年工资的方法
    public double getAnnual() {
        return 12 * salary; //12个月的基本工资
    }
}
class Worker extends Employee { //普通员工类
    public Worker(String name, double salary) {
        super(name, salary);
    }
    //子类特有方法
    public void work() {
        System.out.println("普通员工 " + getName() + " is working");
    }

    @Override
    public double getAnnual() { //因为普通员工没有其他收入，则直接调用父类方法
        return super.getAnnual();
    }
}
class Manager extends Employee { //经理类
    private double bonus; //奖金
    public Manager(String name, double salary, double bonus) {
        super(name, salary);
        this.bonus = bonus;
    }
    public double getBonus() {
        return bonus;
    }
    public void setBonus(double bonus) {
        this.bonus = bonus;
    }
    //特有的管理方法
    public void manage() {
        System.out.println("经理 " + getName() + " is managing");
    }
    //重写获取年薪的方法
    @Override
    public double getAnnual() {
        return super.getAnnual() + bonus; //年基本工资加上奖金
    }
}