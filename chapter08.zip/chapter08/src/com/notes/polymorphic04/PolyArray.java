package com.notes.polymorphic04;
//多态数组 数组的定义类型为父类类型，里面保存的实际元素类型为子类类型
public class PolyArray {
    public static void main(String[] args) {
        //实例：现有一个继承结构如下，要求创建1个Person对象
        //2个Student对象和2个Teacher对象，统一放在数组中，并调用每个对象的say()方法

        Person[] persons = new Person[5]; //创建多态数组 元素为多个类构成
        //多态的向上转型 父类的引用指向了子类的对象
        //a. 可以调用父类中的所有成员(即属性和方法)，需要遵循访问权限，如private私有类就不能访问调用
        //b. 不能调用子类中特有成员(子类重写父类方法除外,属性没有重写之说，属性的值看编译类型)，最终运行效果看子类的具体实现
        persons[0] = new Person("jack", 20); //创建对象时，调用不同的构造器完成属性初始化
        persons[1] = new Student("bobo", 18, 100);
        persons[2] = new Student("smith", 19, 30.1);
        persons[3] = new Teacher("scott", 30, 20000);
        persons[4] = new Teacher("weiwei", 30, 20000);

        //循环遍历多态数组，调用say()方法
        for (int i = 0; i < persons.length; i++) {
            //1. 当调用对象方法的时候，该方法会和该对象的内存地址/运行类型绑定
            //2. 当调用对象属性时，没有动态绑定机制，哪里声明，哪里使用
            //persons[i]的编译类型是Person，而运行类型是根据实际情况由JVM机来判断
            String returnResult = persons[i].say(); //动态绑定机制 调用方法由运行类型决定
            System.out.println(returnResult); //输出say()方法返回结果
            //实例升级：如何调用子类特有的方法，比如Teacher有一个teach，Student有一个study方法，怎么调用？
            if(persons[i] instanceof Student) { //判断persons[i]的运行类型是否为Student
                ((Student) persons[i]).study(); //向下转型
            } else if(persons[i] instanceof Teacher) {
                ((Teacher) persons[i]).teach();
            } else if(persons[i] instanceof Person) {
                //do nothing
            } else {
                System.out.println("你的类型有误，请检查...");
            }
        }
        //（二）多态的向下转型  子类类型  引用名 = （子类类型）父类引用名
        //(2)只能强制转换父类的引用(即对象名)，不能强转父类的对象
        //(3)要求父类的引用必须指向的是当前目标类型的对象
        //(4)当向下转型后，可以调用子类类型中的所有成员(属性、方法)
        Student stu = (Student) persons[1]; //persons[1]就是父类的引用(父类对象名),它是Person类型
        //而之前persons[1]指向的是Student子类，所以可以强制转换父类的引用类型为Student
        stu.study(); //向下转型后可以调用子类特有方法，此时stu的编译类型为子类Student，运行类型也是子类Student
        //stu, persons[1]这两个对象名都指向子类Student，调用方法时由运行类型决定，查找Student类中的study()方法
        //而对象persons[1]的编译类型也由之前的Person类型转换为Student类型
        Teacher tea = (Teacher) persons[3];
        tea.teach();
    }
}
class Person {
    private String name; //父类 共有属性
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String say() { //返回名字，年龄
        return name + "\t" + age;
    }
}
class Student extends Person { //子类
    private double score;

    public Student(String name, int age, double score) {
        super(name, age); //调用父类有参构造器，完成父类属性的初始化
        this.score = score; //子类属性的初始化
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }
    //重写父类中的say()方法
    @Override
    public String say() {
        return "学生：" + super.say() + "\tscore = " + score;  //super.say()调用父类中的say方法
    }

    //子类Student特有方法 study
    public void study() {
        System.out.println("学生 " + getName() + "正在学习...");
    }
}
class Teacher extends Person { //子类
    private double salary;

    public Teacher(String name, int age, double salary) {
        super(name, age); //调用父类有参构造器，完成父类属性的初始化
        this.salary = salary; //子类属性的初始化
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
    //重写父类中的say()方法
    @Override
    public String say() {
        return "老师：" + super.say() + "\tsalary = " + salary;
    }

    //子类Teacher特有方法 teach
    public void teach() {
        System.out.println("老师 " + getName() + "正在上课...");
    }
}
