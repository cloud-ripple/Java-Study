package com.notes;

public class Object02 {
    public static void main(String[] args) {
        //封装：就是把抽象出的数据(属性)和对数据的操作(方法)封装在一起，
        //数据被保护在内部，程序的其他部分只有通过被授权的操作(方法)，才能对数据进行操作
        //1. 封装的理解和好处
        /*（1）隐藏实现细节 方法(连接数据库)<===调用(传入参数..)
           (2)可以对数据进行验证，保证安全合理
        * */
        //2. 封装的实现步骤(三步)
        /*  (1) 将属性进行私有化private(就不能直接修改属性)
            （2）提供一个公共的set方法，用于对属性判断并赋值
            public void setXxx(类型 参数名) {
                加入数据验证的业务逻辑
                属性 = 参数名；
            }
            （3）提供一个公共的get方法，用于获取属性的值
            public XX getXxx() { //权限判断
                return xx;
            }
            封装快速入门 那么在java中如何实现这种类似的控制尼
            问题：如下程序，不能随便查看人的年龄、工资等隐私，并对设置的年龄进行合理的
                 验证，年龄合理就设置，否则给默认
                 年龄必须在1-120，年龄、工资不能直接查看，name的长度在2-6字符
        */
        Person person = new Person();
        person.setName("啵啵");
        person.setAge(30);
        person.setSalary(30000);
        System.out.println(person.info()); //输出信息
        System.out.println(person.getSalary()); //年龄是私有的，不能直接 person.age 这样访问，得通过方法返回属性

        //如果使用自己的构造器来指定属性，setXxx方法就失效了
        Person smith = new Person("smith", 2000, 50000);
        System.out.println("====smith的信息====");
        System.out.println(smith.info());


    }
}
/*问题：如下程序，不能随便查看人的年龄、工资等隐私，并对设置的年龄进行合理的
验证，年龄合理就设置，否则给默认。年龄必须在1-120，年龄、工资不能直接查看，name的长度在2-6字符*/

class Person {
    public String name; //名字公开
    private int age; //年龄私有化
    private double salary; //..

    //无参构造器 new Person();
    public Person() {

    }
    //有三个属性的构造器
    public Person(String name, int age, double salary) {
//        this.name = name;
//        this.age = age;
//        this.salary = salary;
        //如果使用自己的构造器来指定属性，setXxx方法就失效了。我们可以将set方法写在构造器中，这样仍然可以验证
        setName(name); //在一个类中 this可以不写
        this.setAge(age);
        this.setSalary(salary);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        //加入对数据的校验 使得name的长度在2-6字符 相当于增加了业务逻辑
        if(name.length() >= 2 && name.length() <= 6) {
            this.name = name; //满足条件就赋值
        } else {
            System.out.println("名字的长度不对，需要在2-6个字符，默认名字");
            this.name = "无名人";
        }
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        //判断属性的合理范围，是就赋值
        if(age >= 1 && age <= 120) {
            this.age = age;
        } else {
            System.out.println("你设置的年龄需在1-120之间，给默认年龄18");
            this.age = 18; //给一个默认年龄
        }
    }

    public double getSalary() {
        //可以在这里增加当前对象的权限判断
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    //写一个方法，返回属性信息
    public String info() {
        return "信息为 name = " + name + " age = " + age + " salary = " + salary;
    }
}
