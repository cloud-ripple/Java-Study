package com.notes.super_;

public class Super01 {
    public static void main(String[] args) {
        Test02 test02 = new Test02();
        test02.sum();
    }
}
class Test01 {
    public int n1 = 100;
    protected int n2 = 200;
    int n3 = 300;
    private int n4 = 400;
    public Test01() { //无参构造器
    }
    public Test01(String name) { //有参构造器
    }
    public Test01(String name, int age) {
    }
    public void test100() {}
    protected void test200() {}
    void test300() {}
    private void test400() {}

    public void call() {
        System.out.println("父类Test01中的call()方法被调用...");
    }
//    private void call() { //私有类方法只能在本类中调用
//        System.out.println("父类Test01中的call()方法被调用...");
//    }
//    public void getCall() { //通过公共方法来调用私有方法
//        call();
//    }
}
class Test02 extends Test01 {
    //super基本语法
    public void hi() {
        //1.访问父类的属性，但不能访问父类的private私有属性 ===> super.属性名;
        System.out.println(super.n1 + " " + super.n2 + " " + super.n3); //super.n4会报错
        //2.访问父类的方法，不能访问父类的private私有方法   ===> super.方法名(参数列表);
        super.test100();
        super.test200();
        super.test300(); //test400()是私有方法。super.test400();这样写会报错
    }
    //3.访问父类的构造器(只能在构造器中使用)，只能放在构造器的第一句，只能出现一句 ===> super(参数列表);
    public Test02() {
        //super(); //默认调用父类无参构造器，可不写，如果父类没有提供无参构造器(即父类提供的是其它有参构造器)
        //则必须用super(参数列表);语句来指定调用父类的构造器
        //super("bobo"); //调用父类Test01(String name)构造器
        //super("bobo", 22); //调用父类Test01(String name, int age)构造器
    }
    public void sum() {
        System.out.println("子类Test02中的sum()方法被调用");
        //如果想要调用父类Test01中的 call方法，这时，因为子类中没有call方法，因此可以使用一下三种方式
        //1.找call方法时，先找本类，如果有则调用。如果没有则往上一级父类中找,父类中有并且可以调用，则调用
        call();
       //getCall(); //查找过程中，找到了，但父类中的call方法是私有的，只能通过父类提供的公共方法来间接调用
        this.call(); //this代指当前对象(本类)，等价于 call();
        super.call(); //super语句(指向父类)，找call方法的顺序是,跳过子类中的call方法，直接查找父类中的call
        //即使子类中有call()方法也不会被调用，而是直接走父类的call()方法
    }
}

