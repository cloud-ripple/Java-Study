package com.notes.object_;

public class toString {
    public static void main(String[] args) {
        Monster monster = new Monster("小妖怪", "巡山的", 1000);
        //1. 因为Monster类中没有重写toString()方法，
        //此处的toString()方法调用的是父类Object中的方法，默认返回 全类名+@+哈希值的十六进制
        //System.out.println(monster.toString());
        //输出 com.notes.object_.Monster@1b6d3586

        //2. 如果子类Monster中重写了toString方法，则用于返回对象的属性信息
        //此处的toString()方法调用的是Monster中的方法
        System.out.println(monster.toString());
        //输出 Monster{name='小妖怪', job='巡山的', sal=1000.0}

        //3. 当直接输出一个对象时，toString方法会被默认的调用
        System.out.println(monster); //等价于 monster.toString() 调用方法
        //如果子类没有重写toString方法，则调用的是继承自Object类中的方法，默认返回 全类名+@+哈希值的十六进制
        //如果子类Monster重写了该方法，则调用的是这个子类的toString方法，而不会调用父类的
    }
}
class Monster { //默认继承 extends Object
    private String name;
    private String job;
    private double sal;

    public Monster(String name, String job, double sal) {
        this.name = name;
        this.job = job;
        this.sal = sal;
    }
    //2. 重写toString方法，输出对象的属性
    //3. 重写toString方法，打印对象或拼接对象时，都会自动调用该对象的toSting形式
    @Override
    public String toString() { //重写后，一般是把对象的属性输出，当然也可以自己定制输出内容
        return "Monster{" +
                "name='" + name + '\'' +
                ", job='" + job + '\'' +
                ", sal=" + sal +
                '}';
    }
}
