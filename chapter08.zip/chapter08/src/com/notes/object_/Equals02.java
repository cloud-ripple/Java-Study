package com.notes.object_;
/*如何重写equals方法 */
public class Equals02 {
    public static void main(String[] args) {
        //判断两个Person对象的内容是否相等，如果两个Person对象的各个数学值都一样，则返回true，反之false
        Person person1 = new Person("jack", 10, '男');
        Person person2 = new Person("jack", 10, '男');

        //1. 这里的equals方法是继承了父类Object中的方法，所以默认比较的是地址是否相等
        //System.out.println(person1.equals(person2)); //false 不同对象地址不同

        //2. 假入在Person类中重写一个equals方法，再次调用时，用于判断内容是否相等
        System.out.println(person1.equals(person2)); //true 子类中重写该方法判断的是内容
        System.out.println(person1.equals(person1)); //true
    }
}
class Person { //默认继承 extends Object
    private String name;
    private int age;
    private char gender;

    //2. 重写Object的 equals方法
    public boolean equals(Object obj) { //obj时父类的引用，指向传入的子类对象，向上转型
        //判断如果比较的两个对象是同一个对象，则直接返回true
        //eg: System.out.println(person1.equals(person1)); //true
        if (this == obj) { //谁调用equals方法，那么this就代表谁（这个对象）
            return true;  //此处的this代表person1，obj代表传入进来的对象
        }
        //类型判断 如果传入进来的对象是Person类型，才进行比较
        if (obj instanceof Person) {
            //进行类型转换，向下转型后可以调用子类的方法和属性,得到obj对象的属性
            Person p = (Person) obj;
            //person1.equals(person2) person1对象调用该方法，那么this就代表person1
            //而obj 指向传入的person2对象，p 就代表person2对象
            //此处的equals()方法是 String类中的方法，已经由系统重写好了
            return this.name.equals(p.name) && this.age == p.age && this.gender == p.gender;
        }
        //如果类型不是Person，直接返回false
        return false;
    }

    public Person(String name, int age, char gender) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }
}
