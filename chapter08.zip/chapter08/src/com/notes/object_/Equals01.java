package com.notes.object_;

public class Equals01 {
    public static void main(String[] args) {
        A a = new A();
        A b = a;
        A c = b;
        System.out.println(a == c); //true 地址一样
        System.out.println(b == c); //true 地址一样
        B bObj = a; //向上转型，父类的引用指向了子类对象
        System.out.println(bObj == c); //true 因为c也指向A

        System.out.println("=====================");
        System.out.println("啵啵".equals("bobo")); //false
        /*---Object是顶级父类 其equals方法用于判断的是地址是否相等，
         ---而Integer类是Object的子类，Integer类里也有equals方法，重写了父类方法，用于判断内容是否相等
         ---String类同理
        * */
        Integer integer1 = new Integer(1000);
        Integer integer2 = new Integer(1000);
        System.out.println(integer1 == integer2); //false 不同对象
        System.out.println(integer1.equals(integer1)); //true 内容相同

        String str1 = new String("hsp");
        String str2 = new String("hsp");
        System.out.println(str1 == str2); //false
        System.out.println(str1.equals(str2)); //true
    }
}
class B {
}
class A extends B {
}



