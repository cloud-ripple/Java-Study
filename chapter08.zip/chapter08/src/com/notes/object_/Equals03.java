package com.notes.object_;

public class Equals03 {
    public static void main(String[] args) {
        Persons p1 = new Persons();
        p1.name = "hspedu";
        Persons p2 = new Persons();
        p2.name = "hspedu";
        //1. == 既可以判断引用类型（用于比较对象，是否为同一个地址），又可以判断基本类型(用于比较值是否相等)
        //2. equals方法 --重写前比较地址，子类重写后比较内容
        // 只能判断引用类型，在父类Object中默认比较对象的是地址是否相等
        //如果子类中重写了equals方法，则用于比较的是内容
        System.out.println(p1 == p2); //false 不同对象地址不同
        //此处的equals方法是String类中的，jdk源码已经在子类重写好了，所以这里比较的是内容
        System.out.println(p1.name.equals(p2.name)); //true
        //因为Persons类中没有重写equals方法，
        //所以此处的equals方法则只是继承了顶级父类Object中的方法，用于默认比较地址
        System.out.println(p1.equals(p2)); //false

        String s1 = new String("asdf");
        String s2 = new String("asdf");
        //子类String中已经默认重写了父类Object中的equals方法，比较的是内容
        System.out.println(s1.equals(s2)); //true
        // == 在判断引用类型时，用于比较对象的地址
        System.out.println(s1 == s2); //false
    }
}
class Persons {
   public String name;
}
