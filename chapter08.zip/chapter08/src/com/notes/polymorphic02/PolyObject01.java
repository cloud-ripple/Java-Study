package com.notes.polymorphic02;

public class PolyObject01 {
    public static void main(String[] args) {
        Animal animal = new Dog(); //1. 其中animal编译类型是Animal，运行类型是Dog
        //因为运行时，这时执行到该行时，
        // animal运行类型是Dog,所以这里的cry()方法就是 Dog类中的cry()方法
        animal.cry(); //输出 Dog cry() 小狗汪汪叫...

        animal = new Cat(); //2. 这里，animal的运行类型是Cat，但编译类型仍然是Animal
        //这里的cry()方法就是 Cat类中的cry()方法
        animal.cry(); //输出 Cat cry() 小猫喵喵叫...
    }
}
//父类
class Animal {
    public void cry() {
        System.out.println("Animal cry() 动物在叫唤...");
    }
}
//子类
class Cat extends Animal {
    //方法重写父类的cry()
    public void cry() {
        System.out.println("Cat cry() 小猫喵喵叫...");
    }
}
class Dog extends Animal {
    public void cry() {
        System.out.println("Dog cry() 小狗汪汪叫...");
    }
}
