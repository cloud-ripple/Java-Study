package com.notes.houseRent.utils;

public class TestUtility {
    public static void main(String[] args) {
        String s = Utility.readString(5);
        System.out.println("s = " + s);
    }
}
