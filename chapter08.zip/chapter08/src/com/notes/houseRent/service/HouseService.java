package com.notes.houseRent.service;

import com.notes.houseRent.domain.House;

/**
 * 定义House[] ,保存House对象
 * 1. 响应HouseView界面的调用
 * 2. 完成对房屋信息的各种操作
 * */
public class HouseService {

    private House[] houses; //存放House对象的数组
    private int houseNums = 1; //记录当前有多少个房屋信息，初始化默认有1个
    private int idCounter = 1; //id计数器，记录当前的 id 增长到哪个

    public HouseService(int size) {
        houses = new House[size]; //当创建HouseService对象时，指定数组大小
        houses[0] = new House(1, "jack", "112", "乱星海", 3000, "未出租");
    }

    //查找房屋方法
    public House find(int findById) {
//        System.out.println("数组长度 = " + houses.length);
//        System.out.println("房屋数量 = " + houseNums);
        //当前有多少个房屋就遍历多少个，如果 i < houses，表示遍历整个数组大小，比如：当前只有1个房屋，但数组大小却有2个
        // 则 houses[i].getId() 会产生空指针异常，即houses[1]不存在
        for (int i = 0; i < houseNums; i++) {
            if (findById == houses[i].getId()) {
                return houses[i];
            }
        }
        return null;
    }

    //del方法，删除一个房屋信息
    public boolean del(int delId) {
        //先找到要删除的房屋信息对应的下标
        int index = -1;
        for (int i = 0; i < houseNums; i++) {
            if (delId == houses[i].getId()) { //要删除的房屋id ，是数组下标为i的房屋的id
                index = i; //记录当前下标
            }
        }
        //判断是否找到
        if (index == -1) { //说明要删除的id，在数组中不存在
            return false;
        }
        //如果找到,从找到的下标处开始遍历
        for (int i = index; i < houseNums - 1; i++) {
        //把要删除对象的后面一个对象换到前面来,遍历到最后时，要删除的目标对象已经放到数组最后一个元素了
            houses[i] = houses[i + 1];
        }
        //下标 houseNums - 1 即为数组最后一个元素
        houses[--houseNums] = null; //把数组中最后一个对象指向null，不再输出显示
        //然后houseNums再自减1，表示删除一个房屋对象，那么房屋数量减一
        return true;
    }

    //添加新的房屋，返回boolean
    public boolean add(House newHouse) {
        //判断是否可以继续添加，暂时不考虑数组扩容的问题
        if (houseNums == houses.length) { //如果房屋数量已经等于指定的数量(即数组大小)，就不能再添加了
            System.out.println("数组已满，不能再添加了！");
            return false;
        }
        //把 newHouse对象加入到数组houses中，houseNums初始化为1，就是数组中的第二个房屋
        //先把newHouse对象加入到第houseNums个位置处，然后houseNums再自增加1，表示房屋数量加1
        houses[houseNums++] = newHouse;
        //设计一个id自增长,更新newHouse对象的 id
        //idCounter++;
        /** 这里不用houseNums房屋数量，来作为id，是因为如果删除房屋，数量减少那么id信息就随着变化了，为了做出区分 */
        newHouse.setId(++idCounter); //简写前面的idCounter加1，先自增，再...
        return true; //执行完上面后，返回true
    }

    //返回houses信息
    public House[] list() {
        return houses;
    }
}
