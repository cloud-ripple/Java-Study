package com.notes.extend02;

public class ExtendsExercise03 {
    public static void main(String[] args) {
        /*需求：编写Computer类，包含CPU、内存、硬盘等属性，getDetail方法用于返回Computer的详细信息
        编写PC子类，继承Computer类，添加特有属性【品牌brand】
         */
        PC pc = new PC("intel", 16, 500, "IBM");
        System.out.println(pc.getCpu());
        pc.setCpu("AMD");
        pc.printInfo();
    }
}

class Computer {
    private String cpu;
    private int memory;
    private int disk;

    public Computer(String cpu, int memory, int disk) {
        this.cpu = cpu; //父类构造器完成父类属性初始化
        this.memory = memory;
        this.disk = disk;
    }
    public String getCpu() {
        return cpu;
    }
    public void setCpu(String cpu) {
        this.cpu = cpu;
    }
    public int getMemory() {
        return memory;
    }
    public void setMemory(int memory) {
        this.memory = memory;
    }
    public int getDisk() {
        return disk;
    }
    public void setDisk(int disk) {
        this.disk = disk;
    }
    //返回详细信息
    public String getDetails() {
        return "电脑详细信息：" + cpu + " " + memory + " " + disk;
    }
}
class PC extends Computer {
    private String brand; //子类特有属性 品牌

    public PC(String cpu, int memory, int disk, String brand) {
        super(cpu, memory, disk); //调用父类构造器,完成父类属性初始化
        this.brand = brand; //子类构造器完成子类的属性初始化
    }
    public String getBrand() {
        return brand;
    }
    public void setBrand(String brand) {
        this.brand = brand;
    }
    public void printInfo() {
        //调用父类的getDetails方法，得到相关属性
        System.out.println("PC信息：" + getDetails() + " brand=" + brand);
    }
}

