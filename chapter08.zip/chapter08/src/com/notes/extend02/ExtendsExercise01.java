package com.notes.extend02;
public class ExtendsExercise01 {
    public static void main(String[] args) {
        //创建对象时，系统会默认调用无参构造器
        //创建子类对象B时，总是先去调用父类的无参构造器,然后再去调用子类的构造器
        Bb b = new Bb(); //输出a name, a, b name ,b
    }
}
class Aa {
    Aa() { //无参构造器
        this("bobo"); //this代指当前对象，调用父类A的 Aa(String name)构造器
        System.out.println("a");
    }
    Aa(String name) {
        System.out.println("a name");
    }
}
class Bb extends Aa {
    Bb() { //无参构造器
        //super(); //默认指向父类的无参构造器，可以省略不写，
        //但是super 和 this 不能共存在同一个构造器中，且只能放在构造器第一行
        this("abc"); //this代指当前对象，调用子类Bb的 Bb(String name)构造器
        System.out.println("b");
    }
    Bb(String name) {
        //super("bobo"); //super指向父类，调用父类Aa的 Aa(String name)构造器
        System.out.println("b name");
    }
}
