package com.notes.extend02;

public class ExtendsExercise02 {
    public static void main(String[] args) {
        //创建子类对象时，总是先去调用上一级父类的无参构造器，即默认在第一行都有一个super();
        //构造器（构造方法），谁调用就返回到谁处
        C c = new C(); //输出 我是A类,我是B类的有参构造器,我是C类的有参构造器,我是C类的无参构造器
        //this调用调用当前子类，super调用父类
    }
}
class A {
    public A() {
        //这里有隐藏的super();默认指向调用上一级父类的无参构造器，可以不写
        System.out.println("我是A类");
    }
}
class B extends A {
    public B() { //这个无参构造器被覆盖了
        //这里有隐藏的super();默认指向调用上一级父类的无参构造器，可以不写
        System.out.println("我是B类的无参构造器");
    }
    public B(String name) { //添加自己的有参构造器后，默认的无参构造器就被覆盖了，不再使用
        //这里有隐藏的super();默认指向调用上一级父类的无参构造器，可以不写
        System.out.println(name + "我是B类的有参构造器");
    }
}
class C extends B {
    public C() { //new C();使用无参构造器
        //这里有隐藏的super();默认指向调用上一级父类的无参构造器（如果被覆盖，super()就不调用了），可以不写
        this("hello"); //this代指当前对象C，调用C(String name)构造器
        System.out.println("我是C类的无参构造器");
    }
    public C(String name) {
        super("haha"); //指向上一级父类的B(String name)构造器
        System.out.println("我是C类的有参构造器");
    }
}


