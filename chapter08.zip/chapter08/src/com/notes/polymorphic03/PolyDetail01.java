package com.notes.polymorphic03;

public class PolyDetail01 {
    public static void main(String[] args) {
        //（一）多态的向上转型
        //(1)本质：父类的引用指向了子类的对象 （即父类的对象名，存放着指向子类对象的地址）
        //(2)语法：父类类型 引用名 = new 子类类型();
        //(3)特点：编译类型看左边，运行类型看右边
        //(4)多态的向上转型调用方法的规则如下：
        //a. 可以调用父类中的所有成员(即属性和方法)，需要遵循访问权限，如private私有类就不能访问调用
        //b. 不能调用子类中特有成员(子类重写父类方法除外,属性没有重写之说，属性的值看编译类型)，最终运行效果看子类的具体实现
        Animal animal = new Cat(); //animal就是父类对象名，是父类的引用,存放指向父类数据空间的地址
        // new Cat()是匿名对象，只是没有对象名，此时animal指向了子类Cat对象

        //Object obj = new Cat(); //也可以,Object 也是 Animal , Cat的父类
        //animal.catchMouse(); //编译报错，不能调用子类特有的方法属性，因为animal的编译类型是Animal父类
        //c. 因为在编译阶段，能调用那些成员(方法和属性)由编译类型来决定,而Animal父类中没有catchMouse()方法
        //d. 最终运行效果看子类的具体实现，即调用方法时，按照从子类(运行类型)开始查找方法，
        // 会从子类Cat()中先找方法，因为继承了父类，如果在子类中找不到，继续往父类中找
        animal.eat(); //编译类型Animal，运行类型Cat，两个类中都有共同的eat()方法(重写)
        //e. 执行到这里时，调用的是运行类型Cat类中的eat()方法，
        animal.run(); //先从子类中找run()方法，没有就从父类找，调用父类方法
        animal.show();
        animal.sleep();

        //如果希望调用Cat的 catchMouse方法
        //（二）多态的向下转型
        //(1)语法: 子类类型  引用名 = （子类类型）父类引用名
        //(2)只能强制转换父类的引用，不能强转父类的对象
        //(3)要求父类的引用必须指向的是当前目标类型的对象
        //(4)当向下转型后，可以调用子类类型中的所有成员(属性、方法)

        //animal就是父类对象名，是父类Animal类型的引用，而cat是子类对象名，是子类Cat类型的引用
        //animal , cat 都可以看作数据类型的引用，存放指向父类、子类数据空间的地址
        //相当于 int num = 0;中num这个变量名，只不过num是基本数据类型，而animal , cat是引用类型

        //此时，cat的编译类型(看=号左边)为 Cat，运行类型(看=号右边)还是为Cat，因为右边父类的引用被强制转换成子类的引用了
        //每个类看作一种数据类型，相当于animal的数据类型强转为Cat类型,此时animal和cat都是一只猫Cat，即都指向Cat类
        //animal原本指向父类的数据空间地址，cat指向子类的数据空间地址，此时让cat指向animal cat-->animal 类似引用传递，地址拷贝
        Cat cat = (Cat)animal;
        cat.catchMouse(); //执行调用方法时，取决于右边的运行类型，即从子类Cat中找catchMouse()方法
        //animal, cat都指向Cat(即它们都是一只猫)
        Dog dog = (Dog)animal; //===>这样写运行会报错 抛出ClassCastException类型转换异常，不能这样做
        // 这里，相当于把名叫animal的这只猫，变成了一条狗，
        // 虽然Cat,Dog都是Animal的子类，但子类之间狗和猫是没有关系的，猫就是猫，狗就是狗，不能瞎搞
        //又让原本指向Cat的animal,重新强转指向Dog, 即dog-->animal(类似引用传递，地址拷贝).此时dog和animal都指向了Dog狗

        //(3)要求父类的引用必须指向的是当前目标类型的对象，即指向Cat这个类的对象名cat
    }
}
class Animal {
    String name = "动物";
    int age = 10;
    public void sleep() {
        System.out.println("睡觉");
    }
    public void run() {
        System.out.println("跑步");
    }
    public void eat() {
        System.out.println("吃饭");
    }
    public void show() {
        System.out.println("hello,你好");
    }
}
class Cat extends Animal {
    public void eat() { //方法重写父类eat()
        System.out.println("猫吃鱼");
    }
    public void catchMouse() { //子类特有方法
        System.out.println("猫抓老鼠");
    }
}

class Dog extends Animal { //Dog是Animal的子类

}
