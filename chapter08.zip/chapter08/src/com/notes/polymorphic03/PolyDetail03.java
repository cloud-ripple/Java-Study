package com.notes.polymorphic03;

public class PolyDetail03 {
    public static void main(String[] args) {
        //左边为编译类型，右边为运行类型
        Sub2 s = new Sub2();
        System.out.println(s.count); //输出Sub2中的20 属性值看编译类型
        s.display(); //输出20，调用Sub2中的display()方法 调用方法时由运行类型决定
        //编译类型为Base2，运行类型为s(指向new Sub2())
        Base2 b = s; //向上转型，父类的引用指向了子类对象，此时 b,s都指向了子类Sub2对象
        System.out.println(b == s); //true
        System.out.println(b.count); //属性值看编译类型 输出Base2中的10
        b.display(); //调用方法时由运行类型决定 输出20，调用Sub2中的display()方法
    }
}
class Base2 { //父类
    int count = 10;
    public void display() {
        System.out.println(this.count);
    }
}

class Sub2 extends Base2 {
    int count = 20;
    public void display() {
        System.out.println(this.count);
    }
}
