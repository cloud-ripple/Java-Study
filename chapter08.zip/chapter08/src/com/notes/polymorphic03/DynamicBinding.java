package com.notes.polymorphic03;

//java的动态绑定机制 ====> 非常重要
//1. 当调用对象方法的时候，该方法会和该对象的内存地址/运行类型绑定
//2. 当调用对象属性时，没有动态绑定机制，哪里声明，哪里使用
public class DynamicBinding {
    public static void main(String[] args) {
        //向上转型 父类的引用指向了子类对象
        //方法调用有运行类型决定  属性值由编译类型决定
       Father fa = new Son(); //fa的编译类型Father，运行类型Son
        System.out.println(fa.sum()); //从运行类型Son中查找sum()方法，如果没有就接着往上一级父类中查找

        System.out.println(fa.sum1()); //从运行类型Son中查找sum1()方法，如果没有就接着往上一级父类中查找
    }
}
class Father { //父类
    public int i = 10;
    public int sum() {
        //由于fa.sum()，fa在调用这个方法时由运行类型Son决定，会产生动态绑定机制(运行类型绑定)，
        // 因为没找到，接着在父类Father中找到了sum()方法时进入，此处又遇到一个getI()方法，
        //由于该方法会和对象 Son 的内存地址/运行类型绑定，所以这里还是会调用Son类中的getI()方法，而不调用Father类中的getI()方法
        return getI() + 10; // 20 + 10
    }
    public int sum1() {
        //由于fa.sum1()，fa在调用这个方法时由运行类型Son决定
        // 因为没找到，接着在父类Father中找到了sum()方法时进入，此处遇到一个 i 属性，而不是方法
        //当调用对象属性时，没有动态绑定机制，哪里声明，哪里使用，即此处的属性 i 就是Father类中声明的
        return i + 10; // 10 + 10
    }
    public int getI() {
        return i;
    }
}

class Son extends Father { //子类Son
    public int i = 20;
//    public int sum() {
//        return i + 20;
//    }
    public int getI() {
        return i;
    }
//    public int sum1() {
//        return i + 10;
//    }
}
