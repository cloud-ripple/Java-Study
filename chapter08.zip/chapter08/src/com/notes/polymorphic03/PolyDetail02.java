package com.notes.polymorphic03;

public class PolyDetail02 {
    public static void main(String[] args) {
        //1. 属性没有重写之说，属性的值看编译类型
        //而方法有重写，最终运行效果看子类的具体实现，即调用方法时，按照从子类(运行类型)中开始查找方法，
        Base base = new Sub(); //向上转型 父类的引用指向了子类的对象
        // new Sub() 看作一个匿名对象，只是没有对象名而已，让base指向这个Sub对象,而原先base是父类Base的引用
        // 此时，base指向了Sub对象，编译类型看左边Base，运行类型看右边Sub
        System.out.println(base.count); // 10 属性的值看编译类型，输出父类Base中的count属性值

        Sub sub = new Sub(); //编译类型Sub ,运行类型Sub
        System.out.println(sub.count); //输出20 属性的值看编译类型，输出子类Sub中的count属性值

        //2. instanceof 比较操作符，用于判断对象的运行类型是否为XX类型 或 XX类型的子类型
        BB bb = new BB(); //bb这个对象的编译类型(看=号左边)为BB，而运行类型(看=号右边)为BB
        System.out.println(bb instanceof BB); //判断bb对象的运行类型 是BB这个类型吗？ 输出true
        System.out.println(bb instanceof AA); //判断bb对象的运行类型 是AA这个类型的子类型吗？ 输出true
        //输出true代表是，否则不是

        //aa编译类型为 AA，运行类型为 BB
        AA aa = new BB();
        System.out.println(aa instanceof AA); //true 判断aa对象的运行类型 是AA这个类型的子类型吗？
        System.out.println(aa instanceof BB); //true 判断aa对象的运行类型 是BB这个类型吗？
        //obj运行类型看左边，为Object
        Object obj = new Object(); //Object顶级父类
        //用于判断obj对象的运行类型是否为AA类型 或 AA类型的子类型？
        System.out.println(obj instanceof AA); //false

        String str = "hello"; //String是引用类型
        //System.out.println(str instanceof AA); //这样写直接报错，因为字符串str跟AA之间没有任何关系
        System.out.println(str instanceof Object); //true

        Integer num = 4; //Integer是引用类型
        System.out.println(num instanceof Object); //true
        int num2 = 4; //int是基本数据类型
        //System.out.println(num2 instanceof Object); //这样写直接报错，一个是基本数据类型，一个是引用类型
    }
}
class Base { //父类
    int count = 10;
}
class Sub extends Base { //子类
    int count = 20;
}

class AA {

}
class BB extends AA { //子类BB

}
