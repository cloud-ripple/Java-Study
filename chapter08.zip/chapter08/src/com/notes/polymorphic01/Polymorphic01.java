package com.notes.polymorphic01;
//引出多态  编写一个程序，Master类中有一个feed(喂食)方法，可以完成主人给动物喂食的信息
public class Polymorphic01 { //传统方法
    public static void main(String[] args) {
    //new Dog("小白狗")是匿名对象，与 Dog dog = new Dog("小白狗");等价，只是不知道对象名
        // 创建一个子类对象时，构造器都有super()语句，总是先调用父类构造器完成父类属性初始化
        Master master = new Master("啵啵"); //主人类
        //Dog("小白狗")使用Dog(String name)构造器
        master.feed(new Dog("小白狗"), new Bone("牛骨头"));
        master.feed(new Cat("大花猫"), new Fish("黄鱼干"));
    }
}
//父类 食物
class Food {
    private String name;
    public Food(String name) { //父类有参构造器
        this.name = name;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
}
//子类鱼 继承 Food的属性方法
class Fish extends Food {
    public Fish(String name) { //子类有参构造器
        super(name); //调用父类的构造器，完成属性初始化
    }
}
//子类骨头 继承 Food
class Bone extends Food { //子类有参构造器
    public Bone(String name) {
        super(name); //调用父类的构造器，完成属性初始化
    }
}

//父类 动物
class Animal {
    private String name;
    public Animal(String name) { //父类有参构造器
        this.name = name;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
}
//子类猫 继承 Animal的属性方法
class Cat extends Animal {
    public Cat(String name) { //子类有参构造器
        super(name); //调用父类的构造器，完成属性初始化
    }
}
//子类狗 继承 Animal
class Dog extends Animal {
    public Dog(String name) { //子类有参构造器
        super(name); //调用父类的构造器，完成属性初始化
    }
}

//父类 Master(主人)
class Master {
    private String name;
    public Master(String name) { //父类有参构造器
        this.name = name;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

//    //完成主人给小狗喂食(feed) 骨头 方法接收两个实参对象
//    public void feed(Dog dog, Bone bone) {
//        System.out.println("主人 " + name + " 给" + dog.getName() + " 吃 " + bone.getName());
//    }
//    //主人给小猫喂鱼
//    public void feed(Cat cat, Fish fish) { //feed方法重载
//        System.out.println("主人 " + name + " 给" + cat.getName() + " 吃 " + fish.getName());
//    }

    //使用多态机制，可以统一的管理主人喂食的问题
    //animal编译类型是Animal,可以指向(接收)Animal的子类对象
    //food编译类型是Food,可以指向(接收)Food的子类对象
    public void feed(Animal animal, Food food) { //父类的引用可以指向子类
        System.out.println("主人 " + name + " 给" + animal.getName() + " 吃 " + food.getName());
    }
    //如果动物很多，食物也很多
    //===> feed方法会很多，代码的复用性不高，不利于管理和维护===>引出多态
}

