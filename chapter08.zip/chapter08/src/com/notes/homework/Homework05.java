package com.notes.homework;

public class Homework05 {
    public static void main(String[] args) {
        Worker jack = new Worker("jack", 3000);
        jack.printSal();
        Teachers momo = new Teachers("momo", 2000);
        //课时费
        momo.setClassDay(36);
        momo.setClassSal(10);
        momo.printSal();
        Scientist bobo = new Scientist("bobo", 2000);
        bobo.setBonus(2000000);
        bobo.printSal();
    }
}
//父类 员工类
class Employee {
    private String name;
    private double salary; //月工资
    private double salMonth = 12; //带薪月，12薪
    //带薪月数不确定，通过set方法单独指定
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public double getSalMonth() {
        return salMonth;
    }

    public void setSalMonth(double salMonth) {
        this.salMonth = salMonth;
    }
    //打印全年工资
    public void printSal() {
        System.out.println(name + " 的年工资 = " + (salary * salMonth));
    }
}
//子类 普通工人
class Worker extends Employee {
    public Worker(String name, double salary) {
        super(name, salary);
    }

    @Override
    public void printSal() {
        super.printSal();
    }
}
//子类 农民类
class Peasant extends Employee {

    public Peasant(String name, double salary) {
        super(name, salary);
    }
    @Override
    public void printSal() {
        super.printSal();
    }
}
//子类 教师类
class Teachers extends Employee {
    private int classDay; //上课天数 子类特有属性
    private double classSal; //课时费

    public Teachers(String name, double salary) {
        super(name, salary);
    }

    public int getClassDay() {
        return classDay;
    }

    public void setClassDay(int classDay) {
        this.classDay = classDay;
    }

    public double getClassSal() {
        return classSal;
    }

    public void setClassSal(double classSal) {
        this.classSal = classSal;
    }
    //

    @Override
    public void printSal() {
        System.out.println("老师 ");
        System.out.println(getName() + " 年工资是: " +
                (getSalary() * getSalMonth() + classDay * classSal));
    }
}
class Scientist extends Employee {
    private double bonus; //年终奖

    public Scientist(String name, double salary) {
        super(name, salary);
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    @Override
    public void printSal() {
        System.out.println("科学家");
        System.out.println(getName() + " 年工资是:" + (getSalary() * getSalMonth()
        + bonus));
    }
}