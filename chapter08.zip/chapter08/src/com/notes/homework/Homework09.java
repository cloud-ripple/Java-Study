package com.notes.homework;

public class Homework09 {
    public static void main(String[] args) {
        //向上转型
        Persons p = new Student();
        p.eat();
        p.run();
        //向下转型
        Student student = (Student) p;
        student.study();
    }
}
class Persons {
    public void run() {
        System.out.println("person run");
    }
    public void eat() {
        System.out.println("person eat");
    }
}
class Student extends Persons {
    @Override
    public void run() {
        System.out.println("student run");
    }

    @Override
    public void eat() {
        System.out.println("student eat");
    }
    public void study() {
        System.out.println("student is studying");
    }
}