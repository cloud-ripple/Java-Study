package com.notes.homework;

public class Homework06 {
    public static void main(String[] args) {
        CheckingAccount checkingAccount = new CheckingAccount(1000);
        //存款 10元
        checkingAccount.deposit(10);
        //取款10元
        checkingAccount.withdraw(10);
        //输出余额
        System.out.println(checkingAccount.getBalance()); //1009
        SavingAccount savingAccount = new SavingAccount(1000);
        savingAccount.deposit(100);
        savingAccount.deposit(100);
        savingAccount.deposit(100);

        System.out.println(savingAccount.getBalance()); //输出余额
        savingAccount.earnMonthlyInterest();
        System.out.println(savingAccount.getBalance());
    }

}
class BankAccount {
    private double balance; //余额
    public BankAccount(double initialBalance) {
        this.balance = initialBalance;
    }
    //存款方法
    public void deposit(double amount) {
        balance += amount;
    }
    //取款方法
    public void withdraw(double amount) {
        balance -= amount;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
class CheckingAccount extends BankAccount {
    public CheckingAccount(double initialBalance) {
        super(initialBalance);
    }

    //重写父类存款方法
    @Override
    public void deposit(double amount) {
        super.deposit(amount - 1); //手续费减一
    }
    //重写父类取款方法

    @Override
    public void withdraw(double amount) {
        super.withdraw(amount + 1); //手续费+1
    }
}
class SavingAccount extends BankAccount {
    private int count = 3; //
    private double rate = 0.01; //利率

    public SavingAccount(double initialBalance) {
        super(initialBalance);
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    @Override
    public void deposit(double amount) {
        //判断是否可以免手续费
        if (count > 0) {
            super.deposit(amount);
        } else {
            super.deposit(amount - 1);
        }
        count--;
    }

    @Override
    public void withdraw(double amount) {
        //判断是否可以免手续费
        if (count > 0) {
            super.withdraw(amount);
        } else {
            super.withdraw(amount - 1);
        }
        count--;
    }
    public void earnMonthlyInterest() {
        count = 3;
        super.deposit(getBalance() * rate );
    }


    }

