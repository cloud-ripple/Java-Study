package com.notes.homework;

public class Homework07 {
}
class Point {
    private double x;
    private double y;

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }
}
class LabeledPoint extends Point {
    private String labelValue;

    public LabeledPoint(double x, double y, String labelValue) {
        super(x, y);
        this.labelValue = labelValue;
    }
}
