package com.notes.homework.Homework10;

public class Homework10 {
    public static void main(String[] args) {
        Student student = new Student("小明", 15, "男", "2200249066");
        student.printInfo();
        System.out.println("---------------");
        Teacher teacher = new Teacher("薇薇", 22, "女", 2);
        teacher.printInfo();
    }
}
class Person {
    private String name;
    private int age;
    private String sex;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Person(String name, int age, String sex) {
        this.name = name;
        this.age = age;
        this.sex = sex;
    }
   public String play() {
        return name + " 爱玩";
   }

   public String basicInfo() {
        return "姓名：" + name + "\n年龄：" + age + "\n性别：" + sex;
   }

}
class Student extends Person {
    private String stu_id; //学号

    public Student(String name, int age, String sex, String stu_id) {
        super(name, age, sex);
        this.stu_id = stu_id;
    }
    public void study() {
        System.out.println("我承诺， 我会 好好学习");
    }

    @Override
    public String play() {
        return super.play() + "足球";
    }

    public void printInfo() {
        System.out.println("学生信息：");
        System.out.println(super.basicInfo());
        System.out.println("学号：" + stu_id);
        study();
        System.out.println(play());
    }
}
class Teacher extends Person {
    private int work_age;

    public int getWork_age() {
        return work_age;
    }

    public void setWork_age(int work_age) {
        this.work_age = work_age;
    }

    public Teacher(String name, int age, String sex, int work_age) {
        super(name, age, sex);
        this.work_age = work_age;
    }

    public void teach() {
        System.out.println("我承诺，我会认真教学 java...");
    }

    @Override
    public String play() {
        return super.play() + "象棋";
    }

    public void printInfo() {
        System.out.println("老师的信息：");
        System.out.println(super.basicInfo());
        System.out.println("工龄：" + work_age);
        teach();
        System.out.println(play());
    }
}
