package com.notes.homework;

public class Homework11 {
    public static void main(String[] args) {
        C c = new C();
        //通过 getClass()方法来查看运行类型
        System.out.println(c.getClass());

    }
}
class A {
    public A() {
        System.out.println("我是A类");
    }
}
class B extends A {
    public B() {
        System.out.println("我是B类的无参构造器");
    }
    public B(String name) {
        System.out.println("我是B类的有参构造器");
    }
}
class C extends B {
    public C() {
        this("hello"); //调用本类的有参构造器
        System.out.println("我是C类的无参构造器");
    }
    public C(String name) {
        super("hhhh");//调用父类的有参构造器
        System.out.println("我是C类的有参构造器");
    }
}
/*
我是A类
我是B类的有参构造器
我是C类的有参构造器
我是C类的无参构造器
 */

