package com.notes.homework;

public class Homework04 {
    public static void main(String[] args) {
        Manager bobo = new Manager("bobo", 400, 30, 2);
        //设置部门经理的奖金
        bobo.setMoney(3000);
        //打印工资
        bobo.printSalary();
    }
}
//父类 员工类
class Employees {
    private String name;
    private double daySal; //单日工资
    private int days; //工作天数
    private double grade; //员工等级

    public Employees(String name, double daySal, int days, double grade) {
        this.name = name;
        this.daySal = daySal;
        this.days = days;
        this.grade = grade;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getDaySal() {
        return daySal;
    }

    public void setDaySal(double daySal) {
        this.daySal = daySal;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }
    //打印工资方法
    public void printSalary() {
        System.out.println(name + " 基本工资= " + daySal * days * grade);
    }
}
//子类 部门经理
class Manager extends Employees {
    private double money; //子类特有属性 奖金
    //奖金是多少并不是确定的，可以通过set方法
    public Manager(String name, double daySal, int days, double grade) {
        super(name, daySal, days, grade);
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    @Override
    public void printSalary() {
        System.out.println("部门经理" + getName() + " 工资是 " + (money + getDaySal() * getDays() * getGrade()));
    }
}
