package com.notes.extend01;

public class Extends01 {
    public static void main(String[] args) {
        //继承原理
        /*继承可以解决代码复用，当多个类存在相同的属性(变量)和方法时
        可以从这些类中抽象出父类，在父类中定义这些相同的属性和方法，所有的子类不需要重新定义
        这些属性和方法，只需要通过extends来声明继承父类即可
        继承基本语法：
        class 子类 extends 父类 {

        }
        子类就会自动拥有父类定义的属性和方法，父类又叫超类，基类。子类又叫派生类。
        * */
        //小学生对象
        Pupil pupil = new Pupil();
        pupil.name = "银角大王";
        pupil.age = 10;
        pupil.testing();
        pupil.setScore(60);
        pupil.showInfo();

        //大学生对象
        System.out.println("========");
        Graduate graduate = new Graduate();
        graduate.name = "金角大王";
        graduate.age = 22;
        graduate.testing();
        graduate.setScore(100);
        graduate.showInfo();
    }
}
