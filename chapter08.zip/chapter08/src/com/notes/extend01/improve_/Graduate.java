package com.notes.extend01.improve_;
//让子类Graduate继承Student的共有属性属性和方法
public class Graduate extends Student {
    //testing()方法是子类Graduate中所特有的方法
    public void testing() {
        System.out.println("大学生 " + name + " 正在考大学数学..");
    }
}
