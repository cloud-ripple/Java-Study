package com.notes.extend01.improve_;

//光标定位到类名，按住ctrl + H 可以查看类的继承关系
public class Sub extends Base {

    public Sub() { //子类中的无参构造器
        //super(); //当构造器中默认指向父类无参构造器时，super()语句可以不写，隐藏可省略
        //3.如果父类没有提供无参构造器时，
        // 则必须在子类的构造器中用super去指定使用父类的哪个构造器完成对父类的初始化工作，否则编译不通过
        super("smith", 10); //指定使用父类中的Base(String name, int age)构造器
        System.out.println("子类中的Sub()无参构造器被调用");
    }
    //1.当创建子类对象时，不管使用子类的哪个构造器，默认情况下总会去调用父类的无参构造器
    public Sub(String name) { //子类中的有参数构造器
        super("tom", 30); //指定使用父类中的Base(String name, int age)构造器
        System.out.println("子类中的Sub(String name)构造器被调用");
    }
    public Sub(String name, int age) {
        //4.若想要调用父类的无参构造器,如下 或者什么都不写，默认就调用super();
        //super(); //指定使用父类的无参构造器
        //5.若想要调用父类的Base(String name)构造器，必须显格式的强调一下
        //super("hsp"); //构造器的调用须在第一条语句（前面的调用语句要注释），且只能在构造器之间调用
        //6.若想要调用父类的Base(String name, int age)构造器
        super("ning", 20);
        //7.super() 和 this() 都只能放在构造器第一行，因此这两个方法不能共存在一个构造器
        System.out.println("子类中的Sub(String name, int age)构造器被调用");
    }
    public void sayOk() { //子类中的方法
        //2.子类继承了所有的属性和方法，父类的非private属性和方法都可以访问，
        //但是私有属性和私有方法不能在子类直接访问调用，要通过父类提供公共的方法去访问调用
        System.out.println(n1 + " " + n2 + " " + n3); //n4私有属性不能直接访问
        System.out.println("n4 = " + getN4()); //调用父类中的公共方法getN4()来访问属性 n4
        //子类继承了所有的属性和方法，在子类中调用父类中的方法，直接调用
        test100();
        test200();
        test300();
        //test400(); 是私有方法，不能直接调用
        callTest400(); //委托父类提供的公共方法callTest400()进一步调用私有方法(只能在本类中使用)

    }
}
