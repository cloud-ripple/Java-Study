package com.notes.extend01.improve_;
//让Pupil继承父类Student的共有属性属性和方法
public class Pupil extends Student {
    //testing()方法是子类Pupil中所特有的
    public void testing() {
        System.out.println("小学生 " + name + " 正在考小学数学..");
    }
}
