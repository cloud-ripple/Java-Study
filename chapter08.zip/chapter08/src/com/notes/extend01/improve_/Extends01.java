package com.notes.extend01.improve_;

import com.notes.extend01.Graduate;
import com.notes.extend01.Pupil;

public class Extends01 {
    public static void main(String[] args) {
        //小学生对象
        Pupil pupil = new Pupil();
        pupil.name = "银角大王~";
        pupil.age = 11;
        pupil.testing();
        pupil.setScore(50);
        pupil.showInfo();

        //大学生对象
        System.out.println("========");
        com.notes.extend01.Graduate graduate = new Graduate();
        graduate.name = "金角大王~";
        graduate.age = 23;
        graduate.testing();
        graduate.setScore(80);
        graduate.showInfo();
    }
}
