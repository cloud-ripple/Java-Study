package com.notes.extend01.improve_;

public class ExtendsDetail {
    public static void main(String[] args) {
//  （3）当创建子类对象时，不管使用子类的哪个构造器，默认情况下总会先去调用父类的无参构造器，
//  如果父类没有提供无参构造器，则必须在子类的构造器中用super去指定使用父类的哪个构造器完成对父类的初始化工作，
//  否则编译不通过
        //总之，都是先调用父类的构造器，完成初始化
        System.out.println("===创建第1个对象时===");
        Sub sub = new Sub(); //创建了一个子类对象 sub 默认使用无参构造器

        System.out.println("===创建第2个对象时===");
        Sub sub2 = new Sub("jack"); //创建了一个子类对象 sub2 使用Sub(String name)有参构造器

        System.out.println("===创建第3个对象时===");
        Sub sub3 = new Sub("king", 10); //创建了一个子类对象 sub3 使用Sub(String name, int age)有参构造器


        //sub.sayOk();
    }
}
