package com.notes.extend01.improve_;

public class Base extends TopBase {
    //父类中的4个属性
    public int n1 = 100;
    protected int n2 = 200;
    int n3 = 300; //默认属性
    private int n4 = 400;

    public Base() { //无参构造器
        System.out.println("父类中的Base()无参构造器被调用");
    }
    public Base(String name, int age) { //添加自己的有参构造器后，则默认无参构造器就被覆盖了
        System.out.println("父类中的Base(String name, int age)构造器被调用...");
    }
    public Base(String name) { //第三个有参构造器
        System.out.println("父类中的Base(String name)构造器被调用...");
    }
    //父类提供一个公共public的方法，访问私有属性 n4
    public int getN4() {
        return n4; //返回n4属性值到方法调用处
    }
    //4个方法
    public void test100() {
        System.out.println("test100方法被调用");
    }
    protected void test200() {
        System.out.println("test200方法被调用");
    }
    void test300() {
        System.out.println("test300方法被调用");
    }
    private void test400() { //私有方法(只能在本类中使用)
        System.out.println("test400方法被调用");
    }
    public void callTest400() {
        test400(); //通过公共方法达到调用 私有方法的目的
    }
}
