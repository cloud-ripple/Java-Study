package com.notes.extend01.improve_;

public class TopBase {

    public TopBase() {
        System.out.println("构造器TopBase()被调用");
    }
}
