package com.notes.override;

public class Override01 {
    public static void main(String[] args) {
        //演示方法重写的情况
        Dog dog = new Dog();
        dog.say();
    }
}
class Animal {
    public void say() {
        System.out.println("动物叫唤...");
    }
}
class Dog extends Animal {
    //1. 因为Dog是 Animal子类
    //2. Dog的cry方法和 Animal的cry方法定义形式一样(名称、返回类型、形参)
    //3. 这时我们就说Dog的cry方法，重写了Animal的cry方法
      public void say() {
        System.out.println("小狗汪汪叫...");
    }
}
