package com.notes.override;

public class Override02 {
    public static void main(String[] args) {
        //编写一个Person类，包括属性name,age，构造器、方法say()返回自我介绍的信息
        //再编写一个Student类，继承Person类，增加id score属性，以及构造器，定义say()方法
        Person jack = new Person("jack", 21);
        System.out.println(jack.say()); //父类信息
        Student student = new Student("bobo", 22, 1, 95.0);
        System.out.println("自我介绍：" + student.say());
    }
}

class Person {
    private String name;
    private int age;
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    public String say() {
        return " name=" + name + " age=" + age;
    }
}
class Student extends Person {
    private int id;
    private double score;
    public Student(String name, int age,int id, double score) {
        super(name, age); //调用父类构造器，完成父类属性的初始化，super指向父类
        this.id = id; //子类属性初始化，this代指本类
        this.score = score;
    }
    public String say() { //say()方法重写父类的say()方法
        return "id=" + id + " score=" + score + super.say(); //super.say()调用父类的say()方法
    }
}