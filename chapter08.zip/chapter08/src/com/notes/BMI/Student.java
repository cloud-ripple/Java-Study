package com.notes.BMI;

import java.math.BigDecimal;

public class Student {
    private double height; //身高 m
    private double weight; //体重 kg
    private double bmi;

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public Student(double height, double weight) {
        this.height = height;
        this.weight = weight;
    }

    //计算BMI
    public double getBmi() {
        return weight / (height * height);
    }


    //体型判断
    public String tiXi() {
        if (18.5 <= getBmi() && getBmi() <= 24.9) {
            return "正常";
        } else if (24 <= getBmi() && getBmi() <= 27.9) {
            return "超重";
        } else if (28 <= getBmi()) {
            return "肥胖";
        } else {
            return "消瘦";
        }
    }

    @Override
    public String toString() {
        return "height = " + height +
                "  weight = " + weight +
                "  bmi = " + getBmi() +
                "  体型：" + tiXi();
    }
}
