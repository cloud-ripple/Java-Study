package com.notes.BMI;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Student[] students = new Student[2];
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < students.length; i++) {
            System.out.print("请输入第" + (i+1) + "个同学的身高(单位：m)和体重(单位：kg)：");
            double height = scanner.nextDouble();
            double weight = scanner.nextDouble();
            students[i] = new Student(height, weight);
            System.out.println(students[i]);
        }

    }
}
