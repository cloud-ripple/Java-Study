package com.notes.BMI;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DiffNum30 {
    public static void main(String[] args) {
        int[] arr = new int[30];
        List list = new ArrayList();
        while (list.size() < 30) {
            int num = (int)(Math.random() * 30 + 1);
            if (!list.contains(num)) {
                list.add(num);
            }
        }
        System.out.println("------------");
        for (int i = 0; i < list.size(); i++) {
            arr[i] = (int) list.get(i);
            System.out.print(arr[i] + "  ");
        }
        Arrays.sort(arr);
        System.out.println("--------排序---------");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + "  ");
        }

    }
}
