package com.notes.debug_;
//演示 debug对象的创建过程
public class DebugExercise {
    public static void main(String[] args) {
        //创建对象的流程
        //1. 加载 Person类信息 分配内存空间
        //2. 初始化：默认初始化、显式初始化、构造器初始化
        //3. 返回对象的地址
        Person jack = new Person("jack", 22);
        System.out.println(jack);
    }
}
class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
