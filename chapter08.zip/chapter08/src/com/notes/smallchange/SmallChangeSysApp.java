package com.notes.smallchange;

public class SmallChangeSysApp {
    public static void main(String[] args) {
        SmallChangeSysOOP changeSysOOP = new SmallChangeSysOOP();
        changeSysOOP.mainMenu();
    }
}
