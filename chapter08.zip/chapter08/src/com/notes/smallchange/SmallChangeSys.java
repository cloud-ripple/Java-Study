package com.notes.smallchange;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class SmallChangeSys {
    //1. 先完成显示菜单，并可以选择菜单，给出对应提示
    //2. 完成零钱通明细
    //3. 完成收益入账
    //4. 消费
    //5. 退出
    //6. 用户在输入4退出时，给出提示是否确定退出
    //7. 在收益入账和消费时，判断金额是否合理，并给出提示
    //8. 将面向过程改为面向对象 SmallChangeSysOOP ，并使用SmallChangeSysApp完成测试

    public static void main(String[] args) {
        //定义相关变量
        boolean loop = true;
        Scanner scanner = new Scanner(System.in);
        String key = "";

        //2.
        String details = "----------零钱通明细------------";
        //3.
        double money = 0; //消费
        double balance = 0; //余额
        Date date = null; //日期
        //用于日期的格式化 年月日 时分秒
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String note = null;


        do {
            System.out.println("\n==========零钱通菜单==========");
            System.out.println("\t\t1 零钱通明细");
            System.out.println("\t\t2 收益入账");
            System.out.println("\t\t3 消费");
            System.out.println("\t\t4 退     出");

            System.out.print("请选择（1-4）：");
            key = scanner.next();

            //使用switch分支控制
            switch(key) {
                case "1" :
                    System.out.println(details);
                    break;
                case "2" :
                    System.out.print("输入收益入账金额：");
                    money = scanner.nextDouble();
                    //money的值应该校验
                    //找出不正确金额的条件，然后给出提示。直接break
                    if (money <= 0) {
                        System.out.println("收益入账金额范围应大于0");
                        break;
                    }
                    balance += money;
                    date = new Date(); //获取当前的日期
                    //明细 details = details + 收益入账....
                    details += "\n收益入账\t+" + money + "\t" + sdf.format(date) + "\t余额：" + balance;
                    break;
                case "3" :
                    System.out.print("输入消费金额：");
                    money = scanner.nextDouble();
                    //校验消费金额
                    if (money <= 0 || money > balance) {
                        System.out.println("你的消费金额应该在0-" + balance + "之间");
                        break;
                    }
                    System.out.print("消费说明：");
                    note = scanner.next();
                    balance -= money; //在余额的基础上减去支出的钱
                    date = new Date(); //获取当前的日期
                    //明细 details = details + 消费说明....
                    details += "\n" + note + "\t-" + money + "\t" + sdf.format(date) + "\t余额：" + balance;
                    break;
                case "4" :
                    //当用户退出时给出提示
                    String choice = "";
                    while (true) {
                        System.out.println("确定要退出吗，y/n?");
                        choice = scanner.next();
                        if("y".equals(choice) || "n".equals(choice)) {
                            break;
                        }
                    }
                    if (choice.equals("y")) {
                        loop = false;
                    }
                    break;
                default:
                    System.out.println("选择有误，请重新输入！");
            }
        }while (loop);
        System.out.println("退出了零钱通项目...");
    }
}
