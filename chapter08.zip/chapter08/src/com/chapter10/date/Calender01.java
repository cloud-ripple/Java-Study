package com.chapter10.date;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

/**
 * 日期：2023/2/21
 * 需求/说明：第二代日期类 Calendar日历
 */

public class Calender01 {
    public static void main(String[] args) {
        //1.Calender是一个抽象类，并且构造器是private
        //2.可以通过 getInstance()来获取实例
        //3.提供大量的方法和字段
        Calendar c = Calendar.getInstance(); //创建日历对象
        System.out.println(c);
        //获取日历对象的某个日历字段属性
        System.out.println("年：" + c.get(Calendar.YEAR));
        //Calendar返回月的时候，是按照0开始编号，所以要加1
        System.out.println("月：" + (c.get(Calendar.MONTH) + 1));
        System.out.println("日：" + c.get(Calendar.DAY_OF_MONTH));
        System.out.println("时：" + c.get(Calendar.HOUR_OF_DAY));
        System.out.println("分钟：" + c.get(Calendar.MINUTE));
        System.out.println("秒：" + c.get(Calendar.SECOND));
        //4.Calendar没有提供对应的格式化的类，需要自己来组合显示日期

        //5.第三代日期类常见方法
        //LocalDate 只包含日期 年月日，可以获取日期字段
        //LocalTime 只包含时间，可以获取时间字段
        //LocalDateTime 包含日期+时间
        LocalDateTime ldt = LocalDateTime.now();
        System.out.println(ldt);
        System.out.println(ldt.getYear());
        System.out.println(ldt.getHour());
        //6.格式日期类
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy年MM月dd日 HH:mm:ss E");
        String format = dateTimeFormatter.format(ldt);
        System.out.println(format); //格式化后的日期

        //7.时间戳 Instant
        Instant now = Instant.now();
        System.out.println(now);
        //Instant --> Date
        Date date = Date.from(now);
        //Date --> Instant
        Instant instant = date.toInstant();

        //提供 plusDays和 minusMinutes方法可以对当前时间进行加减
        //如890天后，是什么时候
        LocalDateTime localDateTime = ldt.plusDays(890);
        System.out.println("890天后的日期：" + localDateTime);

    }
}
