package com.chapter10.date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 日期：2023/2/21
 * 需求/说明：日期类常见方法
 */

public class Date01 {
    public static void main(String[] args) throws ParseException {
        //1.获取当前系统时间
        //2.默认输出的日期格式是国外的方式，因此需要对格式进行转换
        Date date = new Date();
        System.out.println("当前日期：" + date);

        //创建SimpleDateFormat对象
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss E"); //E是星期
        String format = sdf.format(date);
        System.out.println("格式化后的日期：" + format);

        //可以把一个格式化的字符串转成对应的 Date
        //得到的Date在输出时，还是按照国外的形式
        //在把String -> Date时，使用的 sdf格式需要和你给的String的格式一样，否则会抛出转换异常
        String str = "2021年02月09日 20:45:34 星期三";
        Date parse = sdf.parse(str);
        System.out.println(parse);

    }
}
