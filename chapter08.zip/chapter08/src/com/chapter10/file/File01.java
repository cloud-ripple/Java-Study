package com.chapter10.file;

import java.io.File;
import java.io.IOException;

/** 创建文件对象相关构造器和方法 */
public class File01 {
    public static void main(String[] args) {
        create01();
        create02();
        create03();
    }
    /** 方式1. new File(String pathname) --> 根据路径构建一个File对象 */
    public static void create01() {
        String filePath = "d:\\news1.txt";
        File file = new File(filePath);
        try {
            file.createNewFile();
            System.out.println("文件1创建成功..");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /** 方式2. new File(File parent, String child) ---> 根据父目录文件+子路径构建 */
    public static void create02() {
        File parentFile = new File("d:\\");
        String fileName = "news2.txt";
        /** 这里的file对象，在java程序中，只是一个对象
         * 只有执行了 createNewFile方法，才会在磁盘创建该文件 */
        File file = new File(parentFile, fileName);
        try {
            file.createNewFile();
            System.out.println("文件2创建成功..");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /** 方式3. new File(String parent, String child) ---> 根据父目录 + 子路径构建 */
    public static void create03() {
        String parentPath = "d:\\";
        String fileName = "news3.txt";
        File file = new File(parentPath, fileName);
        try {
            file.createNewFile();
            System.out.println("文件3创建成功..");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
