package com.chapter10.file.writer;

import java.io.FileWriter;
import java.io.IOException;

/** 演示使用FileWriter将 “风雨之后，顶尖彩虹”写入到 note.txt文件中,
 * 如果文件不存在，会自动创建相应文件 */
public class FileWriter_ {
    public static void main(String[] args) {

        String filePath = "d:\\note.txt";
        FileWriter fileWriter = null; //文件输出流对象，写入
        char[] chars = {'a', 'b', 'c'};

        try {
            fileWriter = new FileWriter(filePath); //覆盖模式，不会追加
            /** 1. write(int)方法，写入单个字符 */
            //fileWriter.write('田');
            /** 2. write(char[])方法，写入指定数组中的元素 */
            //fileWriter.write(chars);
            /** 3. write(char[], off, len)方法，写入数组下标位置从off开始，长度为len的指定部分 */
            //fileWriter.write(chars, 0, chars.length); //把整个数组中的全部写入
            //抖音String类中的toCharArray()方法，转换成一个字符数组
            //fileWriter.write("韩顺平教育".toCharArray(), 0, 3); //只会写入长度为3个 韩顺平
            /** 4. write(String, off, len)方法，写入字符串指定部分 */
            fileWriter.write("啵啵我来了", 0, 2); //只会写入2个，啵啵

        } catch (IOException e) {
            e.printStackTrace();
        /** 注意：FileWriter使用后，必须要关闭(close)或刷新(flush),否则写入不到指定的文件 */
        } finally {
            try {
                if (fileWriter != null) {
                    fileWriter.close(); //或者 fileWriter.flush();
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

    }
}
