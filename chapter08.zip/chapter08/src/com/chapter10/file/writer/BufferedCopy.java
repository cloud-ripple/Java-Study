package com.chapter10.file.writer;

import java.io.*;

/** 演示使用BufferedReader和BufferedWriter完成文文本件拷贝 */

public class BufferedCopy {
    public static void main(String[] args) {
        //创建缓冲流对象，套接在指定的节点流基础上
        //注意:因为Reader和writer是按照字符读取，因此不能操作二进制文件(字节文件)
        //比如：图片、音乐，视频等会造成读取数据错误
        String srcFilePath = "d:\\library.sql";
        String destFilePath = "d:\\library_copy.sql"; //拷贝到哪个文件
        BufferedReader br = null;
        BufferedWriter bw = null;
        String line;

        try {
            br = new BufferedReader(new FileReader(srcFilePath));
            bw = new BufferedWriter(new FileWriter(destFilePath));
            /** readLine()方法读取一行的内容，但是没有换行 */
            while ((line = br.readLine()) != null) {
                //System.out.println(line);
                //每读取一行，就写入
                bw.write(line);
                bw.newLine(); //插入换行
            }
            System.out.println("文件拷贝完成..");
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                br.close();
                bw.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
