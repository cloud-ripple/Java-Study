package com.chapter10.file.writer;

import java.io.*;

/** 演示BufferedWriter的使用 */

public class BufferedWriter_ {
    public static void main(String[] args) throws IOException {
        String filePath = "d:\\ok.txt";
        //创建BufferedWriter处理流,用节点流FileWriter去构造
        BufferedWriter bufWriter = new BufferedWriter(new FileWriter(filePath, true));
        //new FileWriter(filePath)覆盖方式
        //new FileWriter(filePath, true)追加方式，构造器
        bufWriter.write("hello,韩顺平教育");
        //换行
        bufWriter.newLine();
        bufWriter.write("hello2,韩顺平教育");
        bufWriter.close(); //关闭外层流即可，节点流会在底层自动关闭
    }
}
