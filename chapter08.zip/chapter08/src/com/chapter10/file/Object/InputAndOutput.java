package com.chapter10.file.Object;
/** 标准输入输出流 */
public class InputAndOutput {
    public static void main(String[] args) {
        //System类的 public final static InputStream in = null;
        //System.in 编译类型 InputStream
        //System.in 运行类型 BufferedInputStream
        //默认设备 键盘
        System.out.println("System.in运行类型 = " + System.in.getClass());

        //System类的 public final static PrintStream out = null;
        //System.out 编译类型 PrintStream
        //System.out 运行类型 PrintStream
        //默认设备 显示器
        System.out.println(System.out.getClass());
    }
}
