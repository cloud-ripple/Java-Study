package com.chapter10.file.Object;

import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

/**
 * 演示将字节流 FileOutputStream包装(转换成)字符流 OutputStreamWriter
 * 对文件进行写入内容，按照gbk、utf-8编码格式 */
public class OutputStreamWriter_ {
    public static void main(String[] args) throws Exception {
        String filePath = "d:\\hsp.txt"; //写入指定文件
        String charSet = "utf-8";
        OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(filePath), charSet);
        osw.write("hih,韩顺平教育");
        osw.close();
        System.out.println("按照" + charSet + "编码格式保存文件成功。");
    }
}
