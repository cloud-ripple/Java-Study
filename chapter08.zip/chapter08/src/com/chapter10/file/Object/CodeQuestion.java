package com.chapter10.file.Object;

import java.io.BufferedReader;
import java.io.FileReader;

/** 乱码引出转换流 */

public class CodeQuestion {
    public static void main(String[] args) throws Exception {
        //读取文件 在默认情况下是按照 utf-8编码 来读取
        //如果改变文件编码，则会出现乱码现象，这时候需要转换流
        String filePath = "d:\\ok.txt";
        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String str = br.readLine();
        System.out.println("读取的内容: " + str);
        br.close();
    }
}
