package com.chapter10.file.Object;

import java.io.IOException;
import java.io.PrintStream;

/**
 * 演示字节打印流 */
public class PrintStream_ {
    public static void main(String[] args) throws IOException {
        PrintStream out = System.out;
        /** 在默认情况下，PrintStream输出数据的位置是 标准输出，即显示器 */
        out.print("json, hello");
        //因为在PrintStream类的print()方法中，实际调用的是write()方法来实现打印/输出
        //所以这里可以直接调用该方法write(byte[] b)打印输出，效果等价
        out.println();
        out.write("韩顺平".getBytes());

        out.close();
        //可以修改打印流输出的位置/设备
        System.setOut(new PrintStream("d:\\out.txt"));
        System.out.println("hello, 啵啵"); //此时不会输出到控制台显示器
        //而是打印输出到指定的文件中了

        //源码注释
//        public static void setOut(PrintStream out) {
//            checkIO();
//            setOut0(out);
//        }
        //构造器会构建一个输出流
//        public PrintStream(String fileName) throws FileNotFoundException {
//            this(false, new FileOutputStream(fileName));
//        }

    }
}
