package com.chapter10.file.Object;

import java.io.*;

/**使用ObjectOutputStream序列化基本数据类型和一个对象，并保存到文件中
 *  序列化就是在保存数据时，保存数据的值和数据类型
 * 反序列化就是在恢复数据时，恢复数据的值和数据类型
 * ObjectInputStream提供反序列化功能(读取)，ObjectOutputStream提供序列化功能(写入) */
public class ObjectOutputStream_ {
    public static void main(String[] args) throws Exception {
        //注意：序列化后，保存的文件格式并不是纯文本，而是按照它的格式来保存
        String filePath = "d:\\data.dat";//指定的文件格式无意义
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath));
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath));
        //序列化数据
        oos.writeInt(100); //int -> Integer (该包装类实现了Serializable接口)
        oos.writeBoolean(true); //boolean -> Boolean (实现了Serializable接口)
        oos.writeChar('a');
//        oos.writeDouble(9.9);
//        oos.writeUTF("写入字符串"); //String(实现了Serializable接口)
        //保存一个Dog对象
        oos.writeObject(new Dog("旺财", 10, "冰岛", "白色"));
        oos.close(); //关闭流
        System.out.println("数据保存完毕，序列化形式");

        /** 读取(反序列化)的顺序需要和保存数据(序列化)的顺序一致，否则会抛出异常 */
        //反序列化,控制台输出对象信息
        System.out.println(ois.readInt());
        System.out.println(ois.readBoolean());
        System.out.println(ois.readChar());

        //dog的编译类型是Object，运行类型是Dog
        Object dog =  ois.readObject(); //在保存数据的时候，值和数据类型都是一起保存的
        System.out.println("dog的运行类型：" + dog.getClass());
        System.out.println("狗的信息：" + dog);
        /**在保存对象时，保存(序列化)的是哪一个包下的类，则进行读取(反序列化)时
         * 需要将该类的定义声明，导入或拷贝到可以引用的位置 */
        Dog dog2 = (Dog)dog; //向下转型，才可以调用该类中的方法
        System.out.println(dog2.getName());

        ois.close(); //关闭外层流即可
    }
}
class Dog implements Serializable { //该对象必须实现Serializable接口，让其类是可序列化的
    private String name;
    private int age;
    /** 序列化对象时，默认将里面所有属性都进行序列化(写入保存)，但是除了static或transient修饰的成员 */
    private static String nation; //该属性不会被序列化，即在保存对象时，不会写入保存到文件中
    private transient String color;
    //serialVersionUID 序列化版本号，可以提高兼容性
    private static final long serialVersionUID = 1L;
    /** 序列化对象时，要求里面属性的类型也需要实现序列化接口,否则会抛出异常 */
    private Master master = new Master(); //要求Master类要实现序列化接口

    public Dog(String name, int age, String nation, String color) {
        this.name = name;
        this.age = age;
        this.nation = nation;
        this.color = color;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", color='" + color + '\'' +
                ", nation='" + nation + '\'' +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
class Master implements Serializable {

}

