package com.chapter10.file.Object;

import java.io.*;

/** 演示使用 InputStreamReader转换流解决中文乱码问题
 * 将字节流 FileInputStream 转成字符流 InputStreamReader，并指定编码 */

public class InputStreamReader_ {
    public static void main(String[] args) throws IOException {
        String filePath = "d:\\ok.txt"; //把ok.txt文件从 原先的utf-8编码格式改成 gbk
        //1. 把FileInputStream流转换成InputStreamReader流
        InputStreamReader isr = new InputStreamReader(new FileInputStream(filePath), "gbk");
        //2. 把InputStreamReader 传入 BufferedReader
        BufferedReader br = new BufferedReader(isr); //构造器闯入一个Reader类或子类对象
        //3. 读取
        String str = br.readLine();
        System.out.println("读取内容: " + str);
        //4. 关闭外层流
        br.close();

    }

}
