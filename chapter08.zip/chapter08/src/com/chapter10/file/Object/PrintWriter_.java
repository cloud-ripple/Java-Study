package com.chapter10.file.Object;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * 演示字符打印流 */
public class PrintWriter_ {
    public static void main(String[] args) throws IOException {
        PrintWriter printWriter = new PrintWriter(System.out);
        //源码构造器
        // public PrintWriter(OutputStream out) {
        //        this(out, false);
        //    }
        /** 在默认情况下，PrintStream输出数据的位置是 标准输出，即显示器 */
        printWriter.print("hi, 薇薇1"); //默认输出到显示器控制台

        PrintWriter printWriter1 = new PrintWriter(new FileWriter("d:\\out2.txt"));
        printWriter1.print("hi, 薇薇2"); //输出写入到指定的文件
        printWriter.close();
        printWriter1.close(); /** 注意: 要关闭流，否则数据写不进去或不能输出 */
    }
}
