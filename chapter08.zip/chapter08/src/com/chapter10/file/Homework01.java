package com.chapter10.file;

import org.junit.Test;

import java.io.*;

/**
 * @author boboking
 * @date 2023/5/29
 * @description
 */
public class Homework01 {

    @Test
    public void write() throws IOException {
        String filePath = "d:\\myScore.txt";
        ObjectOutputStream oos = null;
        ObjectInputStream ois = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(filePath));
            ois = new ObjectInputStream(new FileInputStream(filePath));

            oos.writeObject(new Student("bobo", "2200249021", 98.9, 68.5));
            oos.close();
            System.out.println("写入成功");
            Object o = ois.readObject();
            Student student = (Student)o;

            System.out.println(student);
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            ois.close();
        }


    }
}
