package com.chapter10.file.properties;

import java.io.FileReader;
import java.util.Properties;

public class Properties02 {
    public static void main(String[] args) throws Exception {
        //使用Properties类来读取配置文件
        //1. 创建对象
        Properties properties = new Properties();
        //2. 加载指定配置文件 load(Reader reader)方法接收一个字符流对象或其子类对象
        properties.load(new FileReader("src\\mysql.properties"));
        //3. 把键值显示输出到控制台 list(PrintStream out)方法
        properties.list(System.out); //输出配置文件中的所有内容
        //4. 根据指定key键来获取
        String user = properties.getProperty("user"); //比如只获取用户信息
        String pwd = properties.getProperty("pwd"); //获取密码信息
        //输出
        System.out.println("用户名=" + user);
        System.out.println("密码=" + pwd);
    }
}
