package com.chapter10.file.properties;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * 配置文件引出Properties */
public class Properties01 {
    public static void main(String[] args) throws IOException {
        //读取mysql.properties文件，得到内容
        BufferedReader bufReader = new BufferedReader(new FileReader("src\\mysql.properties"));
        //循环读取文件
        String line = "";
        while ((line = bufReader.readLine()) != null) {
            //System.out.println(line);
            String[] split = line.split("="); //根据=号拆分
            //split[0]为=号左边，split[1]为右边
            //System.out.println(split[0] + "值是：" + split[1]); //输出所有
            //要求只需要打印ip的值
            if ("ip".equals(split[0])) {
                System.out.println(split[0] + "值是：" + split[1]);
            }
        }
        bufReader.close();
    }
}
