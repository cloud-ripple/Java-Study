package com.chapter10.file.properties;

import java.io.FileOutputStream;
import java.util.Properties;

public class Properties03 {
    public static void main(String[] args) throws Exception {
        //使用Properties类来修改配置文件
        Properties properties = new Properties();
        /** 如果该配置文件没有键(key),则创建
         *  如果配置文件已经有了键(key)，则替换/修改
         * */
        properties.setProperty("charset", "utf8");
        properties.setProperty("user", "啵啵"); //啵啵 的unicode码为：\u5575\u5575
        /** 注意保存中文信息到文件时，是按照中文的unicode码来存储 */
        properties.setProperty("pwd", "abc");

        //将键值存储到配置文件中 store(OutputStream out, String comments)方法，comments注解
        properties.store(new FileOutputStream("src\\mysql.properties"), null);
        System.out.println("保存配置文件成功");
    }
}
