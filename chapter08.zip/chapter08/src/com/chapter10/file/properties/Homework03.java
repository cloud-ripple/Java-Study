package com.chapter10.file.properties;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

/**
 * 编写一个dog.properties
 * name=tom
 * age=5
 * color=red
 * 编写Dog类，创建一个dog对象，读取dog.properties用相应的内容完成属性初始化，并输出
 */
public class Homework03 {
    public static void main(String[] args) throws IOException {
        Properties pro = new Properties();
        //加载配置文件。读取信息
        pro.load(new FileReader("src/com/chapter10/file/properties/dog.properties"));
        Dog dog = new Dog(pro.getProperty("name"),
                 Integer.parseInt(pro.getProperty("age")),
                 pro.getProperty("color"));
        System.out.println(dog.toString());
    }
}

