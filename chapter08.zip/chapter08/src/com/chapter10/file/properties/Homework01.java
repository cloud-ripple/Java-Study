package com.chapter10.file.properties;

import java.io.File;
import java.io.IOException;

/**
 * 1. 在判断d盘下是否有文件夹mytemp，如果没有就创建
 * 2. 在d:\\mytemp目录下，创建创建文件hello.txt
 * 3. 如果该文件已经存在，提示该文件存在，就不用再重复创建了 */
public class Homework01 {
    public static void main(String[] args) throws IOException {
        String filePath = "d:\\mytemp";
        File file = new File(filePath);
        if (!file.exists()) {
            file.mkdirs(); //如果不存在就创建目录
        }
        File file1 = new File(file, "hello.txt");
        if (file1.exists()) {
            System.out.println("该文件已经存在");
        } else {
            file1.createNewFile();
            System.out.println(file1.getName() + "创建成功");
        }

    }
}
