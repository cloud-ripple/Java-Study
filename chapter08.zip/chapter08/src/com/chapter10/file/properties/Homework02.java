package com.chapter10.file.properties;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * 使用BufferedReader读取一个文本文件，为每行加上行号
 * 再连同内容一并输出到控制台 */
public class Homework02 {
    public static void main(String[] args) throws IOException {
        String filePath = "d:\\MySQL_note.sql";
        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String line = "";
        int count = 1;
        while ((line = br.readLine()) != null) {
            System.out.println(line + (count++));
        }
    }
}
