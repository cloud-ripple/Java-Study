package com.chapter10.file.test;

import java.sql.*;

public class Test06 {

    public static void main(String[] args) {
        String driver = "com.mysql.cj.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/shop";
        Connection conn = null;
        PreparedStatement preState = null;
        ResultSet rs = null;

        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url, "root", "twb");
            String sql = "select price,name,number,madeTime" +
                        " from goods order by price desc";
            preState = conn.prepareStatement(sql);
            rs = preState.executeQuery();
            System.out.println("按照价格排序，输出表中数据如下：");
            while (rs.next()) {
                System.out.print(rs.getDouble(1));
                System.out.print("\t" + rs.getString(2));
                System.out.print("\t" + rs.getInt(3));
                System.out.println("\t" + rs.getString(4));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                preState.close();
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
