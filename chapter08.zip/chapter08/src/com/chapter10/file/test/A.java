package com.chapter10.file.test;

public class A {
    /** 编写一个Java应用程序，该程序中有3个类：Lader、Circle和主类A。
     * 具体要求如下：Lader类具有类型为double的上底、下底、高、面积属性，具有返回面积的功能，
     * 包括一个构造方法对上底、下底、高进行初始化。
     * Circle类具有类型为double的半径、周长和面积属性，具有返回周长、面积的功能，
     * 包括一个构造方法对半径进行初始化。
     * 主类A用来测试类Lader和类Circle的功能。*/

    public static void main(String[] args) {
        Lader lader = new Lader(13, 34, 14);
        System.out.println("Lader 面积：" + lader.getLaderArea());
        Circle circle = new Circle(3);
        System.out.println("Circle 周长：" + circle.getPerimeter());
        System.out.println("Circle 面积: " + circle.getCircleArea());
    }
}
class Lader {
    private double top; //上底
    private double bottom; //下底
    private double height; //高度
    private double laderArea; //面积

    public Lader(double top, double bottom, double height) {
        this.top = top;
        this.bottom = bottom;
        this.height = height;
    }

    public double getTop() {
        return top;
    }

    public void setTop(double top) {
        this.top = top;
    }

    public double getBottom() {
        return bottom;
    }

    public void setBottom(double bottom) {
        this.bottom = bottom;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getLaderArea() {
        return (top + bottom) * height / 2;
    }

}

class Circle {
    private double radius; //半径
    private double perimeter; //周长
    private double circleArea; //面积
    private final static double PI = 3.14;

    public Circle(double radius) {
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double getPerimeter() {
        return 2 * PI * radius;
    }

    public double getCircleArea() {
        return PI * radius * radius;
    }

}