package com.chapter10.file.test;

public class Test09 {
    public static void main(String[] args) {
        /** 分别用do-while和for循环计算1+1/2!+1/3!+1/4!+…+的前30项之和。*/
        doWhile();
        forSum();
    }
    public static void doWhile() {
        int n = 1; //多少项
        int jie = 1; //阶乘
        double sum = 0;
        do {
            jie *= n++;
            sum += 1.0 / jie;
        } while (n <= 30);
        System.out.println("do-while计算前30项之和为：" + sum);
    }
    public static void forSum() {
        int b = 1;
        double sum = 0;
        for (int i = 1; i <= 30; i++) {
            b *= i;
            sum += 1.0 / b;
        }
        System.out.println("for循环计算前30项之和为：" + sum);
    }
}
