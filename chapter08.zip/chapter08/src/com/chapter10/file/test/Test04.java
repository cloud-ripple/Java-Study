package com.chapter10.file.test;

public class Test04 {
    /**
     * 设计一个一个应用程序，求不同柱类体积。为了便于扩展采用面向抽象的编程思想来实现。
     * 画出设计类图，并编写相应的类以及主类（应用程序），并求出2种柱类的体积。
     */
    public static void main(String[] args) {
        //第一种柱体
        Column column1 = new Column(new CircleShape(5), 7);
        System.out.println("圆形柱体的体积为：" + column1.getVolume());
        //第二种柱体
        Shape shape = new CuboidShape(3, 4);
        Column column2 = new Column(shape, 9);
        System.out.println("长方形柱体的体积为：" + column2.getVolume());
    }
}

//抽象类 形状shape
abstract class Shape {
    public abstract double getArea(); //柱体底部面积
}

//柱体column
class Column {
    public double height;
    public Shape shape;

    //初始化形状，得到底部面积，高度
    public Column(Shape shape, double height) {
        this.shape = shape;
        this.height = height;
    }

    //体积volume
    public double getVolume() {
        return shape.getArea() * height;
    }

}

//底部为圆形的柱体
class CircleShape extends Shape {
    private double radius; //底部半径
    private final double PI = 3.14;

    public CircleShape(double radius) {
        this.radius = radius;
    }

    @Override
    public double getArea() {
        return PI * radius * radius;
    }
}

//底部为长方形的柱体
class CuboidShape extends Shape {
    private double length; //长
    private double width; //宽

    public CuboidShape(double length, double width) {
        this.length = length;
        this.width = width;
    }

    @Override
    public double getArea() {
        return length * width;
    }
}