package com.chapter10.file.test;

import java.io.*;

public class Test07 {
    public static void main(String[] args) {
        /** 设计一程序按行读取该文件内容，并在该行的后面尾加上该英语句子中含有的单词书目
         * ，然后再将该行写入到一个名字为englishCountt.txt的文件中，并将该文件输出如下：*/

        String filePath1 = "d:\\english.txt"; //读取的文件
        String filePath2 = "d:\\englishCount.txt"; //写入的文件

        FileReader fileReader = null; //文件输入流，字符流，读取
        BufferedReader bufRead = null; //缓冲输入流

        FileWriter fileWriter = null; //文件输出流，字符流，写入
        BufferedWriter bufWrite = null; //缓冲输出流

        String str = null; //把读取到的数据放在字符串str里
        try {
            //通过文件输入流来构造缓冲输入流
            fileReader = new FileReader(filePath1);
            bufRead = new BufferedReader(fileReader);

            //通过文件输出流来构造缓冲输出流
            fileWriter = new FileWriter(filePath2);
            bufWrite = new BufferedWriter(fileWriter);
            //不为空就循环读取字符串，按行读取
            while ((str = bufRead.readLine()) != null){
                int count = 1; //统计单词个数
                char[] ch = str.toCharArray(); //读取到的字符串转换成字符数组
                //遍历每个字符，如果有空格字符，代表读取完一个单词
                for (int i = 0; i < ch.length; i++) {
                    if (ch[i] == ' ') {
                        count++;
                    }
                }
                //一边读，一边写，读取多少就写多少，并在这一行的末尾处加上单词个数
                bufWrite.write(str + "  " + count);
                bufWrite.newLine(); //新行
                //输出读取到的内容
                System.out.println(str);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
               bufRead.close();
               //FileWriter文件输出流使用后，必须要关闭(close)或刷新(flush),否则写入不到指定的文件
               bufWrite.close(); //或者 bufWrite.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
