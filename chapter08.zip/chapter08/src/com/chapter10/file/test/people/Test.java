package com.chapter10.file.test.people;

public class Test {
    /** 创建如下三个类：（People类中的三个方法分别输出一些信息，
     * ChinaPeople和AmericanPeople类重写父类的三个方法）。*/
    public static void main(String[] args) {
        People people = new ChinaPeople(1.75, 65);
        people.printInfo();
        people = new AmericanPeople(1.77, 67);
        people.printInfo();
    }
}
class People {
    protected double height;
    protected double weight;

    public People(double height, double weight) {
        this.height = height;
        this.weight = weight;
    }

    public void speakHello() {
        System.out.println("Hello!");
    }

    public void averageHeight() {
        System.out.println("人的身高为：" + height + "米");
    }

    public void averageWeight() {
        System.out.println("人的体重为：" + weight + "kg");
    }

    public void printInfo() {
        speakHello();
        averageHeight();
        averageWeight();
    }
}

class ChinaPeople extends People {
    public ChinaPeople(double height, double weight) {
        super(height, weight);
    }

    public void chinaGongFu() {
        System.out.println("中国武术，坐如钟、站如松...");
    }

    @Override
    public void speakHello() {
        super.speakHello();
    }

    @Override
    public void averageHeight() {
        System.out.print("ChinaPeople ");
        super.averageHeight();
    }

    @Override
    public void averageWeight() {
        System.out.print("ChinaPeople ");
        super.averageWeight();
    }

    @Override
    public void printInfo() {
        super.printInfo();
        chinaGongFu();
    }
}

class AmericanPeople extends People {
    public AmericanPeople(double height, double weight) {
        super(height, weight);
    }

    public void americanBoxing() {
        System.out.println("西方武术，直拳、钩拳...");
    }

    @Override
    public void speakHello() {
        super.speakHello();
    }

    @Override
    public void averageHeight() {
        System.out.print("AmericanPeople ");
        super.averageHeight();
    }

    @Override
    public void averageWeight() {
        System.out.print("AmericanPeople ");
        super.averageWeight();
    }

    @Override
    public void printInfo() {
        super.printInfo();
        americanBoxing();
    }
}