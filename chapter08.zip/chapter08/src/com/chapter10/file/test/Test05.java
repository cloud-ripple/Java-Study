package com.chapter10.file.test;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.sql.*;

public class Test05 {
    /** 需求：
     * 创建一注册窗口类，运行结果图如下，并写一监视器类，
     * 使用对象输出流将注册的用户对象写入磁盘文件，
     * 并创建对象输入流读入磁盘文件对象，在控制台输出。
     */
    public static void main(String[] args) {
        new registerFrame();
    }
}

//用户实体类，序列化
//class User implements Serializable {
//    private String userName;
//    private String password;
//
//    public User(String userName, String password) {
//        this.userName = userName;
//        this.password = password;
//    }
//
//    public String getUserName() {
//        return userName;
//    }
//
//    public void setUserName(String userName) {
//        this.userName = userName;
//    }
//
//    public String getPassword() {
//        return password;
//    }
//
//    public void setPassword(String password) {
//        this.password = password;
//    }
//
//    @Override
//    public String toString() {
//        return "\n用户名：" + userName +
//                ", 密码：" + password;
//    }
//}

//监听器类
class MyListener implements ActionListener {
    String userName;
    String password;

//    String filePath = "d:\\registerInfo.txt"; //要操作的文件路径
//    FileOutputStream fileOut = null; //文件输出流，写入(字节输出流， 程序 ---> 文件)
//    ObjectOutputStream objOut = null; //对象输出流
//
//    FileInputStream fileInput = null; //文件输入流，读取(字节输入流， 文件 ---> 程序)
//    ObjectInputStream objInput = null; //对象输入流

    String driver = "com.mysql.cj.jdbc.Driver"; //驱动名
    String url = "jdbc:mysql://localhost:3306/db_user"; //数据库
    Connection conn = null;
    PreparedStatement preState = null;

    //实现ActionListener接口中的抽象方法
    @Override
    public void actionPerformed(ActionEvent e) {
        //得到用户输入的信息
        userName = registerFrame.getField1().getText().trim();
        password = registerFrame.getField2().getText().trim();
        //判断是否输入了完整的信息，如果是则进行写入和读取操作
        if (userName.length() != 0 && password.length() != 0) {
            //write(); //写入用户信息到磁盘文件
            //read(); //读取文件中的信息
            //用户信息添加到数据库
            //String sql = "insert into tb_users values ('" + userName + "','" + password + "')";//写sql语句
            String sql = "insert into tb_users values (?,?)";
            toDatabase(sql, new Object[] {
                    userName,password
            });
        } else {
            JOptionPane.showMessageDialog(
            registerFrame.getBtnSave(),
            "请先输入用户名和密码！",
            "提示",
            JOptionPane.INFORMATION_MESSAGE);
        }

    }

    //写入用户信息
//    public void write() {
//        try {
//            fileOut = new FileOutputStream(filePath, false);
//            objOut = new ObjectOutputStream(fileOut);
//            User user = new User(userName, password);
//            objOut.writeObject(user);
//        } catch (IOException e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                fileOut.close();
//                objOut.close();
//            } catch (IOException e) {
//                throw new RuntimeException(e);
//            }
//        }
//        System.out.println("保存成功..");
//    }

    //读取用户信息
//    public void read() {
//        try {
//            fileInput = new FileInputStream(filePath);
//            objInput = new ObjectInputStream(fileInput); //用文件输入流去构造对象输入流
//            //调用对象输入流的readObject()方法，读取并返回一个Object类
//            User user = (User) objInput.readObject(); //向下转型
//            System.out.println("注册的用户信息如下：" + user); //输出
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                fileInput.close();
//                objInput.close();
//            } catch (IOException e) {
//                throw new RuntimeException(e);
//            }
//        }
//    }

    //写入数据库
    public void toDatabase(String sql, Object[] parameters) {
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url, "root", "twb");
            System.out.println("数据库连接成功: " + conn);
            preState = conn.prepareStatement(sql);
            //给？号赋值
            for (int i = 0; i < parameters.length; i++) {
                preState.setObject(i+1, parameters[i]);
            }

            int i = preState.executeUpdate();
            if (i > 0) {
                System.out.println("用户信息已经保存到数据库..");
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            try {
                preState.close(); //关闭连接，释放资源
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }
}

//注册窗口类
class registerFrame extends JFrame {
    JLabel label1 = null;
    JLabel label2 = null;
    static JTextField field1 = null;
    static JTextField field2 = null;
    static JButton btnSave = null;
    static JButton btnCancel = null;

    MyListener myListener = new MyListener(); //监听器，类MyListener的对象实例

    public registerFrame() {
        this.setTitle("用户注册");
        this.setSize(450, 450);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(3);

        label1 = new JLabel("用户名:");
        label1.setBounds(100, 50, 70, 30);
        field1 = new JTextField();
        field1.setBounds(160, 50, 160, 30);

        label2 = new JLabel("密码:");
        label2.setBounds(100, 100, 40, 30);
        field2 = new JTextField();
        field2.setBounds(160, 100, 160, 30);

        btnSave = new JButton("保存");
        btnSave.setBounds(140, 150, 60, 30);
        btnCancel = new JButton("取消");
        btnCancel.setBounds(260, 150, 60, 30);
        //保存按钮添加监听事件
        btnSave.addActionListener(myListener);
        //取消按钮添加监听事件
        btnCancel.addActionListener(new MyListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                field1.setText("");
                field2.setText("");
            }
        });
        //添加组件到容器
        this.add(label1);
        this.add(field1);
        this.add(label2);
        this.add(field2);
        this.add(btnSave);
        this.add(btnCancel);

        this.setVisible(true); //设置窗口可见
    }

    public static JTextField getField1() {
        return field1;
    }

    public static JTextField getField2() {
        return field2;
    }

    public static JButton getBtnSave() {
        return btnSave;
    }

    public static JButton getBtnCancel() {
        return btnCancel;
    }
}
