package com.chapter10.file.test;

public class Test3 {
    /**
     * 按要求编写Java程序：
     * （1）编写一个接口：InterfaceA，只含有一个方法int method(int n)；
     * （2）编写一个类：ClassA来实现接口InterfaceA，实现int method(int n)接口方法时，
     * 要求计算1到n的和；
     * （3）编写另一个类：ClassB来实现接口InterfaceA，实现int method(int n)接口方法时，
     * 要求计算n的阶乘（n!）；
     * （4）编写测试类E，在测试类E的main方法中使用接口回调的形式来测试实现接口的类。
     */
    public static void main(String[] args) {
        InterfaceA a = new ClassA();
        //a.method(100);
        work(a, 100);

        ClassB classB = new ClassB();
        work(classB, 5);
    }

    public static void work(InterfaceA interfaceA, int n) {
        System.out.println(interfaceA.method(n));
    }
}

interface InterfaceA {
    int method(int n);
}

class ClassA implements InterfaceA {
    @Override
    public int method(int n) {
        int sum = 0;
        for (int i = 1; i <= n; i++) {
            sum += i;
        }
        return sum;
    }
}

class ClassB implements InterfaceA {
    @Override
    public int method(int n) {
        int factorial = 1; //阶乘
        for (int i = 1; i <= n; i++) {
            factorial *= i;
        }
        return factorial;
    }
}