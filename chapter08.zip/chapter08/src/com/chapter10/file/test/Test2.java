package com.chapter10.file.test;

public class Test2 {
    /** 设计一个动物声音“模拟器”，希望模拟器可以模拟许多动物的叫声，
     * 为了便于扩展采用面向接口的编程思想来实现。
     * 画出设计类图，并编写相应的类以及主类（应用程序），能够调用模拟器发出2种不同动物的叫声。*/
    public static void main(String[] args) {
        Cat cat = new Cat("小花猫");
        cat.birdCry();
        cat.dogCry();
    }
}
interface Cry {
    public abstract void birdCry(); //鸟叫
    public abstract void dogCry(); //狗叫
}

class Animal implements Cry {
    public String name;

    public Animal(String name) {
        this.name = name;
    }

    @Override
    public void birdCry() {
        System.out.println(name + " 通过努力学习不仅能鸟叫了，布谷布谷~~~");
    }

    @Override
    public void dogCry() {
        System.out.println(name + " 通过努力学习还会狗叫了，汪汪汪~~~");
    }
}

class Cat extends Animal {
    public Cat(String name) {
        super(name);
    }
}