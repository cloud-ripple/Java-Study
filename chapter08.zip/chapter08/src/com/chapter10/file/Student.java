package com.chapter10.file;

import java.io.Serializable;

/**
 * @author boboking
 * @date 2023/5/29
 * @description
 */
public class Student implements Serializable {
    private String name;
    private String id;
    private double mathScore;
    private double englishScore;

    public Student(String name, String id, double mathScore, double englishScore) {
        this.name = name;
        this.id = id;
        this.mathScore = mathScore;
        this.englishScore = englishScore;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public double getMathScore() {
        return mathScore;
    }

    public void setMathScore(double mathScore) {
        this.mathScore = mathScore;
    }

    public double getEnglishScore() {
        return englishScore;
    }

    public void setEnglishScore(double englishScore) {
        this.englishScore = englishScore;
    }

    @Override
    public String toString() {
        return "Student{" +
                "姓名 ='" + name + '\'' +
                ", 学号 ='" + id + '\'' +
                ", 数学成绩 = " + mathScore +
                ", 英语成绩 = "  + englishScore +
                '}';
    }
}
