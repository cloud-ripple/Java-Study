package com.chapter10.file.InputStream;

import org.junit.Test;

import java.io.FileInputStream;
import java.io.IOException;

/** 演示FileInputStream 文件输入流的使用，将文件中的数据读取出来(字节输入流， 文件 ---> 程序) */
public class FileInputStream_ {

    public static void main(String[] args) {

    }

    /** 1. read()方法，从该输入流读取一个字节的数据 */
    @Test
    public void readFile01() {
        String filePath = "d:\\hello.txt";
        FileInputStream fileInputStream = null; //定义一个文件输入流对象
        int readData = 0; //把文件对象读取的数据放到readData
        try {
            //创建 FileInputStream对象，用于读取 hello.txt 这个文件到程序中
            fileInputStream = new FileInputStream(filePath);
            //read()方法，从该输入流读取单个字节的数据，如果没有输入可用，此方法将阻止
            //数据的下一个字节，如果达到文件的末尾，返回 -1，表示文件已经读取完了
            while ((readData = fileInputStream.read()) != -1) { //没有返回-1就一直读取
                System.out.print((char)readData); //以char类型输出
            }
            System.out.println("\n文件读取完毕"); //此时readData == -1 ,退出循环

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                fileInputStream.close(); //关闭文件流，释放资源
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /** 2. read(byte[] b)方法，从该输入流读取最多 b.length字节的数据到字节数组
     * 如果文件读到结尾，返回-1 */
    @Test
    public void readFile02() {
        String filePath = "d:\\hello.txt";
        FileInputStream fileInputStream = null; //定义一个文件输入流对象
        byte[] buf = new byte[8]; //buf为读取数据的缓冲区，一次读取8个字节数据到数组中
        int readLength = 0; //用于接收实际读取的字节数
        int count = 0; //记录读取的次数
        try {
            //创建 FileInputStream对象，用于读取 hello.txt 这个文件到程序中
            fileInputStream = new FileInputStream(filePath);
            //read(byte[] b)方法，从该输入流读取最多 b.length字节的数据到字节数组，
            //如果达到文件的末尾，返回 -1
            /** 如果读取正常，返回实际读取的字节数 到readLength，本身最多读取8个字节
             * 如果文本中的字节数不够8个，则按照实际读取的返回到该数组中 */
            while ((readLength = fileInputStream.read(buf)) != -1) { //没有返回-1就一直读取
                System.out.print(new String(buf, 0, readLength));
                //用字节数组去构建一个字符串显示出来，按照 0 到 readLength实际读取这个长度来构建字符串
                count++;
            }
            System.out.println("\n文件读取完毕,读取次数：" + count); //

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                fileInputStream.close(); //关闭文件流，释放资源
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
