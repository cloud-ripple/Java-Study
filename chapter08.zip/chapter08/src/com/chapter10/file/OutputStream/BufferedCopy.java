package com.chapter10.file.OutputStream;

import java.io.*;

/** 演示完成图片、音乐的拷贝 */

public class BufferedCopy {
    public static void main(String[] args) {
        String srcFile = "d:\\umbrella.jpg";
        String destFile = "d:\\umbrella_copy.jpg"; //目标路径
        //创建字节处理流
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;

        try {
            //构造器BufferedInputStream(InputStream in)，接收一个子类对象
            //FileInputStream继承了InputStream
            bis = new BufferedInputStream(new FileInputStream(srcFile));
            bos = new BufferedOutputStream(new FileOutputStream(destFile));

            //循环读取文件，并写入到destFile文件
            byte[] buf = new byte[1024]; //每次读取1024字节，把读取的数据放到数组里
            int readLen = 0; //用来接收实际读取到的长度
            //read(byte[] b)方法，返回实际读取到的长度，当返回-1时，表示文件读取完毕
            while ((readLen = bis.read(buf)) != -1) {
                bos.write(buf, 0, readLen); //边读边写，读到多少就写多少
            }
            System.out.println("图片拷贝完成..");
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            //关闭外层的处理流即可，底层回去关闭节点流
            try {
                bis.close();
                bos.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
