package com.chapter10.file.OutputStream;

import org.junit.Test;

import java.io.FileOutputStream;
import java.io.IOException;

/** 演示FileOutputStream 文件输出流的使用,将数据写入文件中(字节输出流， 程序 ---> 文件) */
public class FileOutputStream_ {
    public static void main(String[] args) {

    }
    /** 案例：在a.txt文件中写入 hello,world，如果文件不存在，会自动创建相应文件 */
    @Test
    public void writeFile() {
        String filePath = "d:\\a.txt"; //文件路径
        FileOutputStream fileOutputStream = null; //输出流对象
        try {
            /** 注意：
             * 4. 如果是使用 new FileOutputStream(filePath)构造器创建方式，当写入内容时，会覆盖原来的内容
             * 5. 如果是使用 new FileOutputStream(filePath, true)构造器,第二个参数是true，则字节将被写入文件的末尾
             * 而不是开头，相当于是追加文件内容，不会覆盖之前写入的内容 */
            //fileOutputStream = new FileOutputStream(filePath); //4. 方式
            fileOutputStream = new FileOutputStream(filePath, true); //5. 方式

            /** 1. write(int b)方法将指定的字节写入此文件输出流 */
            //fileOutputStream.write('H'); //char 会自动转换成 int 两者可以随时互换
            /** 2. write(byte[] b)方法 */
            String str = "hello,world";
            //调用String类中的getBytes()方法，把该字符串转换成一个字节数组，byte[]
            //fileOutputStream.write(str.getBytes()); //写入字符串
            /** 3. write(byte[] b, int off, int len)方法，将len字节从位于偏移量off的指定
             * 字节数组写入此文件输出流 ，即从该数组的 起始位置 ~ 目标位置这部分的数据写入文件中 */
            fileOutputStream.write(str.getBytes(), 0, str.length()); //把整个字符串都写入
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                fileOutputStream.close(); //关闭输出流，释放资源
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
