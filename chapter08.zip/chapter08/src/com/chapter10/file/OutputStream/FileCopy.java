package com.chapter10.file.OutputStream;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Writer;

/** 演示FileOutputStream 文件输出流的使用,拷贝文件(字节输出流， 程序 ---> 文件) */
public class FileCopy {
    public static void main(String[] args) {
        /** 案例：完成文件拷贝，将 flower.jpg 图片拷贝到 c:\\ */
        //思路分析：
        //1. 创建文件的输入流，将文件读取到程序中
        //2. 创建文件的输出流，将上面读取到的文件数据，写入到指定的文件
        /** 文件1 ---输入流(读取)---> java程序(内存) ---输出流(写入)---> 文件2
         * 在完成程序时，应该是读取部分数据，就写入到指定文件(使用循环操作)，
         * 如果文件数据量很大，一次性读完再写入文件中的话，可能内存会不够用 */
        //先确定要拷贝的文件路径
        String srcFilePath = "C:\\Users\\花海\\Pictures\\Saved Pictures\\flower.jpg";
        //再确定要拷贝到哪里
        String destFilePath = "d:\\1.jpg";
        FileInputStream fileInputStream = null; //文件输入流对象，读取
        FileOutputStream fileOutputStream = null; //文件输出流对象，写入
        byte[] buf = new byte[1024]; //一次读取1024字节到数组中
        int readLen = 0; //用来接收接收读取的长度

        try {
            fileInputStream = new FileInputStream(srcFilePath);
            fileOutputStream = new FileOutputStream(destFilePath);
            while ((readLen = fileInputStream.read(buf)) != -1) {
                //读取到后就写入文件中。一边读，一边写
                fileOutputStream.write(buf, 0 ,readLen);
            }
            System.out.println("拷贝完毕");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {  //关闭输入流、输出流，释放资源
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

}
