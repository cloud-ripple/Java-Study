package com.chapter10.file;

import org.junit.Test;

import java.io.*;

public class Directory_ {
    public static void main(String[] args) {

    }
    @Test
    public void m1() {
        String filePath = "d:\\news1.txt";
        File file = new File(filePath);
        //判断 d:\news1.txt该文件是否存在，如果存在就删除
        if (file.exists()) {
            if (file.delete()) {
                System.out.println(filePath + " 删除成功");
            } else {
                System.out.println(filePath + " 删除失败");
            }
        } else {
                try {
                    file.createNewFile();
                    System.out.println("文件不存在，已经为你创建成功！");
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
        }
    }

    //判断目录是否存在，存在就删除，目录也被当作文件来对待
    @Test
    public void m2() {
        String filePath = "d:\\demo02\\bobo";
        File file = new File(filePath);
        //判断 d:\demo02 该目录是否存在，如果存在就删除
        if (file.exists()) {
            if (file.delete()) {
                System.out.println(filePath + " 删除成功");
            } else {
                System.out.println(filePath + " 删除失败");
            }
        } else {
            //file.mkdir(); //创建一级个目录，该方法返回一个boolean值
            //file.mkdirs(); //创建多级目录
            if (file.mkdirs()) {
                System.out.println("目录创建成功！");
            } else {
                System.out.println("目录创建失败");
            }
        }
    }
}
