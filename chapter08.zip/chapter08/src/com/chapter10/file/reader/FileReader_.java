package com.chapter10.file.reader;

import org.junit.Test;

import java.io.FileReader;
import java.io.IOException;

public class FileReader_ {
    public static void main(String[] args) {

    }

    /** 1. read()方法，每次读取单个字符，返回该字符，如果到文件末尾返回-1 */
    @Test
    public void readFile01() {
        String filePath = "d:\\story.txt";
        FileReader fileReader = null; //文件输入流对象，读取
        int data = 0;
        try {
            fileReader = new FileReader(filePath);
            //循环读取
            while ((data = fileReader.read()) != -1) {
                System.out.print((char) data); //输出
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if(fileReader != null) {
                    fileReader.close();
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

    }

    /** 2. read(char[])方法，批量读取多个字符到数组，返回读取到的字符数，如果到文件末尾返回-1 */
    @Test
    public void readFile02() {
        String filePath = "d:\\story.txt";
        FileReader fileReader = null; //文件输入流对象，读取
        int readLen = 0;
        char[] buf = new char[8]; //一次读取8个字符
        try {
            fileReader = new FileReader(filePath);
            //循环读取 read(char[])方法,返回的是实际读取到的字符数
            while ((readLen = fileReader.read(buf)) != -1) {
                System.out.print(new String(buf, 0, readLen)); //输出
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if(fileReader != null) {
                    fileReader.close();
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

    }

}
