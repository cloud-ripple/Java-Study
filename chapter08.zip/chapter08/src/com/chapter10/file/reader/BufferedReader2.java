package com.chapter10.file.reader;

import java.io.BufferedReader;
import java.io.FileReader;

/** 演示BufferedReader的使用 */

public class BufferedReader2 {
    public static void main(String[] args) throws Exception {
        String filePath = "d:\\MySQL_note.sql";
        //创建BufferedReader
        BufferedReader bufReader = new BufferedReader(new FileReader(filePath));
        //读取
        String line;
        //readLine()按行读取，返回字符串，如果已经达到流的末尾，则为null
        while ((line = bufReader.readLine()) != null) {
            System.out.println(line);
        }
        //关闭流，只需要关闭BufferedReader，因为底层会自动关闭节点流FileReader
        bufReader.close();
    }
}
