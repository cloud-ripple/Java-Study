package com.chapter10.file.reader;

/** (1) 节点流是底层流，直接跟踪数据源相接
    (2) 处理流(包装流)包装节点流，既可以消除不同节点流的实现差异，
        也可以提供更方便的方法来完成输入输出。
    (3) 处理流对节点流进行包装，使用了修饰器设计模式，不会直接与数据源相接
 * */
public abstract class Reader_ { //抽象类
    public void readFile(){};

    public void readString(){};
}

//节点流/低级流，只是针对文件操作
class FileReader2 extends Reader_ {
    public void readFile() {
        System.out.println("对文件进行读取.");
    }
}

//节点流，只是针对字符串操作
class StringReader_ extends Reader_ {
    public void readString() {
        System.out.println("读取字符串");
    }
}

//做成处理流/包装流
class BufferedReader_ extends Reader_ {
    private Reader_ reader_; //属性是 Reader_类型

    //接收Reader_子类对象，可以对文件，字符串等多种数据源操作
    public BufferedReader_(Reader_ reader_) { //向上转型，接收一个子类对象
        this.reader_ = reader_;
    }
    //封装一层
    public void readFile() {
        reader_.readFile(); //动态绑定机制
    }

    //扩展，让方法更加灵活，多次读取文件
    public void readFiles(int num) {
        for (int i = 0; i < num; i++) {
            reader_.readFile(); //动态绑定机制
        }
    }

    //扩展 readString,批量处理字符串数据
    public void readStrings(int num) {
        for (int i = 0; i < num; i++) {
            reader_.readString(); //动态绑定机制
        }
    }

}

class Test {
    public static void main(String[] args) {
        //通过BufferedReader_多次读取文件
        BufferedReader_ bufferedReader_ = new BufferedReader_(new FileReader2());
        bufferedReader_.readFile();
        bufferedReader_.readFiles(5); //扩展，读取多次

        //通过BufferedReader_多次读取字符串
        BufferedReader_ bufferedReader_1 = new BufferedReader_(new StringReader_());
        bufferedReader_1.readStrings(10);
    }
}
