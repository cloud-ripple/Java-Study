package com.chapter10.math;

/**
 * 日期：2023/2/20
 * 需求/说明：Math类方法
 */

public class Math01 {
    public static void main(String[] args) {
        //1.abs 绝对值
        int abs = Math.abs(-9);
        //2.pow 求幂
        double pow = Math.pow(2, 4); //2的4次方
        System.out.println(pow);
        //3.ceil 向上取整，返回>=该参数的最小整数
        double ceil = Math.ceil(-3.0002); //-3.0
        //4.floor 向下取整，返回<=该参数的最大整数
        double floor = Math.floor(-4.999); //-5.0
        System.out.println(floor);
        //5.round 四舍五入
        long round = Math.round(-5.001);
        System.out.println(round);
        //6.sqrt 求开方
        double sqrt = Math.sqrt(9.0);

        //7.random 求随机数 默认返回的是 0~1之间的一个随机小数
        //思考：写出获取a~b之间的一个随机整数，比如a = 2, b = 7
        //Math.random() * 6 返回的就是 0 <= x < 6 小数
        //2 + Math.random() * 6 返回的就是 2 <= x < 8 小数 7.99999 取整数7

        //公式：(int)(a + Math.random() * (b-a+1))
        for (int i = 0; i < 10; i++) {
            System.out.println( (int) (2 + Math.random() * (7 - 2 + 1)) );
        }

    }
}
