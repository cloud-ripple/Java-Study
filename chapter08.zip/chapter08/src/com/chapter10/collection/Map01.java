package com.chapter10.collection;

import java.util.HashMap;
import java.util.Map;

/**
 * 日期：2023/2/24
 * 需求/说明：Map接口实现类的特点
 */
@SuppressWarnings({"all"})
public class Map01 {
    public static void main(String[] args) {
        //Map接口常用方法 以实现类 HashMap来讲解
        //(1) 中M ap与Collection并列存在。用于保存具有映射关系的数据：Key-Value
        //(2) Map中的Key和Value可以是任何引用类型的数据，会封装到HashMap$Node对象中
        //(3) Map中的key不允许重复，原因和HashSet一样
        //(4) Map中的Value可以重复
        //(5) Map中的可以为null,value也可以为null,注意key为null，只能有一个，value为空可以有多个
        //(6) 常用String类作为Map的key
        //(7) key和value之间存在单项一对一关系，即通过指定的key总能找到对应的value
        Map hashMap = new HashMap();
        hashMap.put("no1", "bobo"); //k-v
        hashMap.put("no2", "bo"); //k-v
        hashMap.put("no1", "花海"); //当有相同的k ,就等价于替换
        hashMap.put("no3", "花海"); //k-v
        hashMap.put(null, null); //k-v
        hashMap.put(null, "abc"); //等价替换
        hashMap.put("no4", null); //k-v
        hashMap.put("no5", null); //k-v
        hashMap.put(1, "lucy"); //k-v
        hashMap.put(new Object(), "忘语"); //k-v

        //通过get方法，闯入key，返回对应的value
        System.out.println(hashMap.get(1));
        System.out.println(hashMap);

    }
}
