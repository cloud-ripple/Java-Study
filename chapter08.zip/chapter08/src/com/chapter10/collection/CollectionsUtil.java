package com.chapter10.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 日期：2023/3/1
 * 需求/说明：Collections工具类常用方法
 */

public class CollectionsUtil {
    public static void main(String[] args) {
        List list = new ArrayList();
        list.add("tom");
        list.add("smith");
        list.add("king");
        list.add("milan");
        //(1)reverse(List):反转List中元素的顺序
        Collections.reverse(list);
        System.out.println(list); //输出顺序颠倒了

        //(2)shuffle(List):对List集合元素进行随机排序
        Collections.shuffle(list); //打乱之前的顺序，相当于得到一个新list

        //(3)sort(List):根据元素的自然顺序对指定List集合元素按升序排序
        Collections.sort(list);
        System.out.println(list);

        //(4)sort(List, Comparator):根据指定的Comparator产生的顺序对List集合元素进行排序
        //可以自己指定排序规则
        Collections.sort(list, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                return ((String)o1).length() - ((String)o2).length(); //按照字符串大小排序
            }
        });
        //(5)swap(List, int, int):将指定list集合中的i处元素和j处元素进行交换
        Collections.swap(list, 0, 1);

        //(6) Object max(Collection):根据元素的自然顺序，返回给定集合中的最大元素
        System.out.println(Collections.max(list));

        //(7) Object max(Collection, Comparator):根据Comparator指定的顺序，返回给指定集合中的最大元素
        Object maxElement = Collections.max(list, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                return ((String)o1).length() - ((String)o2).length();
            }
        });
        System.out.println("长度最大的元素 = " + maxElement);

        //(8) Object min(Collection):

        //(9) Object min(Collection, Comparator):

        //(10) int frequency(Collection, Object):返回指定集合中指定元素的出现次数
        System.out.println("tom在list中出现的次数：" + Collections.frequency(list,"tom"));

        //(11) void copy(List dest, List src):将src中的内容复制到dest中
        ArrayList dest = new ArrayList();
        for (int i = 0; i < list.size(); i++) {
            dest.add(""); //为了让目标list和原来的list大小一样
        }
        Collections.copy(dest, list);
        System.out.println(dest);
        /* 底层中，如果大小不一样，会直接抛出异常
        if (srcSize > dest.size())
              throw new IndexOutOfBoundsException("Source does not fit in dest");
        */

        //(12) boolean replaceAll(List list, Object oldVal, Object newVal):使用新值替换List对象的所有旧值
        Collections.replaceAll(list, "tom", "汤姆");
        //将list中的所有 tom 替换成 --> 汤姆
    }
}
