package com.chapter10.collection;

import java.util.TreeSet;

/**
 * 日期：2023/3/2
 * 需求/说明：试分析HashSet和TreeSet分别如何实现去重的
 */

public class HomeWork04 {
    public static void main(String[] args) {
        /*
        * (1)HashSet的去重机制：hashCode()+equals()，底层先通过存入对象，进行运算得到一个
        * hash值，通过hash值得到对应的索引，如果发现table索引所在的位置，没有数据，就直接存放
        * 如果有数据，就进行equals比较，如果比较后，不相同，就加入，否则就不加入。
        * (2)TreeSet的去重机制：如果你传入了一个Comparator匿名对象，就使用实现的compare去重
        * 如果方法返回0，就认为是相同元素/数据，就不添加，如果你没有传入一个Comparator匿名对象
        * 则以你添加的对象实现的Comparable接口的compareTo去重，
        *
        * 在没有传入Comparator匿名对象的同时，且添加的对象也没有实现Comparable接口，
        * 此时添加元素会抛出异常
        * */
        //通过TreeSet(Comparator comparator)构造器传入一个Comparator()匿名对象
        TreeSet treeSet = new TreeSet();
        treeSet.add("bobo");
        treeSet.add("jack");
        treeSet.add("tom");
        treeSet.add("jack"); //加入不了
        System.out.println(treeSet);

        TreeSet treeSet2 = new TreeSet();
        treeSet2.add(new Persons()); //如果Person没有实现Comparable接口，会抛出异常
        treeSet2.add(new Persons()); //加入不了，只有一个Person
        System.out.println(treeSet2);

        //底层源码分析：
        /** add方法，因为TreeSet构造器没有传入一个Comparator()匿名对象
        所以底层 (Comparable<? super K>)k1 会把Person转成 Comparable类型
        由于Person并没有实现Comparable接口，不能向下转型，所以报错 */
    }
}
class Persons implements Comparable { //

    @Override
    public int compareTo(Object o) {
        return 0; //返回0，代表是相同元素，则后面继续添加Person对象时，添加不进去，元素重复
        /** 此处没有做任何比较规则，也可以自己定义，
         * 比如按照Person的name,age等属性的长度、大小来比较
         * 如果返回的不是0，则代表套添加的元素与之前的不是相同元素，添加成功 */
    }
}
