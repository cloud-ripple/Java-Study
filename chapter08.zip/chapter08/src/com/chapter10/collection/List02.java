package com.chapter10.collection;

import java.util.*;

/**
 * 日期：2023/2/22
 * 需求/说明：使用List接口的实现类添加图书，并遍历，打印
 * 要求使用ArrayList、LinkedList、Vector三种集合实现
 */

public class List02 {
    public static void main(String[] args) {
        List arrayList = new ArrayList();
        arrayList.add(new Books("书1", 55.6, "bobo"));
        arrayList.add(new Books("书2", 5.6, "qqq"));
        arrayList.add(new Books("书3", 565.6, "ttt"));

        List linkedList = new LinkedList();
        linkedList.add(new Books("书4", 78, "haha"));
        linkedList.add(new Books("书5", 8, "haha"));
        linkedList.add(new Books("书6", 98, "haha"));

        List vectorList = new Vector();
        vectorList.add(new Books("书7", 23, "gai"));
        vectorList.add(new Books("书8", 13, "gai"));
        vectorList.add(new Books("书9", 123, "gai"));

        sort(arrayList); //排序 传入一个实现了List接口的子类 ArrayList、LinkedList、Vector三种集合都可以

        //迭代器遍历
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            Object obj = iterator.next();
            Books book = (Books) obj;
            System.out.println(book);
        }

        //增强for循环 和迭代器效果等价
        for (Object o : arrayList) {
            System.out.println(o); //遍历输出
        }


    }

    //按照价格排序
    public static void sort(List list) {
        //1.先遍历集合
        for (int i = 0; i < list.size() - 1; i++) {
            for (int j = 0; j < list.size() - 1 - i; j++) {
                //取出(得到)元素(对象)Books
                Books book1 = (Books)list.get(j);
                Books book2 = (Books)list.get(j + 1);
                if (book1.getPrice() > book2.getPrice()) { //交换
                    list.set(j, book2);
                    //Object set(int index, Object ele)方法设置指定index位置的元素为ele，相当于是替换
                    list.set(j+1, book1);
                }
            }
        }
    }
}

class Books {
    private String name;
    private double price;
    private String author;

    public Books(String name, double price, String author) {
        this.name = name;
        this.price = price;
        this.author = author;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return "Books{" +
                "name='" + name + '\'' +
                ", price=" + price +
                ", author='" + author + '\'' +
                '}';
    }
}