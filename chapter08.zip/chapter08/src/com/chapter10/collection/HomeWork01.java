package com.chapter10.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * 日期：2023/3/1
 * 需求/说明：
 * (1)封装一个新闻类，包含标题和内容属性，提供get、set方法，重写toString方法，打印对象时只打印标题
 * (2)只提供一个带参数的构造器，实例化对象时，只初始化标题，并且实例化两个对象
 * 新闻1：新冠确证病例超千万，数百万计印度教。。。
 * 新闻2：男子突然想起2个月前钓的鱼还在网兜里
 * (3)将新闻对象添加到ArrayList集合中，并且进行倒序遍历
 * (4)在遍历集合过程中，对新闻标题进行处理，超过15字的只保留前15个，然后在后边加 “..."
 * (5)在控制台打印遍历出经过处理的新闻标题
 */
@SuppressWarnings({"all"})
public class HomeWork01 {
    public static void main(String[] args) {
        List list = new ArrayList();
        list.add(new News("新冠确证病例超千万，数百万计印度教好iv哦加哦i第三方v的"));
        list.add(new News("男子突然想起2个月前钓的鱼还在网兜里,于是想起去放据说利率"));
        //倒序遍历
        Collections.reverse(list); //先进行list反转,颠倒元素
        Iterator iterator = list.iterator(); //使用迭代器遍历
        while (iterator.hasNext()) {
            News news = (News) iterator.next(); //向下转型
            String title = news.getTitle();
            if (title.length() > 15) {
                news.setTitle(title.substring(0, 15) + ".....");
                //substring方法，截取指定索引区间[0,15) ，(注意不包括下标为15的字符) 的字符串内容
            }
            System.out.println(news); //遍历输出对象
        }
    }
}
class News { //新闻类
    private String title; //标题
    private String content; //内容

    public News(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return "News{" +
                "title='" + title + '\'' +
                "}";
    }
}
