package com.chapter10.collection;

/**
 * 日期：2023/2/23
 * 需求/说明：HashSet底层机制说明-模拟简单的数组+链表结构
 */

public class HashSet02 {
    public static void main(String[] args) {
        //模拟一个HashSet的底层
        //1.创建一个数组，数组类型是 Node[]
        //2.有时候，直接把 Node[]数组称为 表
        Node[] table = new Node[16];
        System.out.println("table = " + table);
        //3.创建结点
        Node bobo = new Node("bobo", null);

        table[2] = bobo;
        Node jack = new Node("jack", null);
        bobo.next = jack; //将jack结点挂载到bobo
        Node rose = new Node("Rose", null);
        jack.next = rose; //将rose结点挂载到jack

        Node lucy = new Node("lucy", null);
        table[3] = lucy; //把lucy放到 table表的索引为3的位置
        System.out.println(table);
    }
}
class Node { //结点，存储数据，可以指向下一个节点，从而形成链表
    Object item; //存放数据
    Node next; //指向下一个结点

    public Node(Object item, Node next) {
        this.item = item;
        this.next = next;
    }
}
