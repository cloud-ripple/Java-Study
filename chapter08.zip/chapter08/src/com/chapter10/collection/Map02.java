package com.chapter10.collection;

import java.util.*;

/**
 * 日期：2023/2/27
 * 需求/说明：Map六大遍历方式
 */

public class Map02 {
    public static void main(String[] args) {
        Map map = new HashMap();
        map.put("no1", "bobo"); //k-v
        map.put("no2", "bo"); //k-v
        map.put("no1", "花海"); //当有相同的k ,就等价于替换
        map.put("no3", "花海"); //k-v
        map.put(null, null); //k-v
        map.put(null, "abc"); //等价替换

        //第一组：先取出所有的Key，通过Key取出对应的Value
        Set keySet = map.keySet();  //keySet方法获取所有的键
        //1.增强for
        for (Object key: keySet) {
            System.out.println(key + "-" + map.get(key));  //get方法根据键获取值
        }

        //2.迭代器
        Iterator iterator = keySet.iterator();
        while (iterator.hasNext()) {
            Object key = iterator.next();
            System.out.println(key + "-" + map.get(key));
        }

        //第二组
        //3.把所有的values取出
        Collection values = map.values();  //values方法获取所有的值
        //这里可以使用所有的Collection使用的遍历方法
        //(1)增强for
        System.out.println("-----获取所有的value 增强for----");
        for (Object value : values) {
            System.out.println(value);
        }
        //(2)迭代器
        System.out.println("-----获取所有的value 迭代器----");
        Iterator iterator1 = values.iterator();
        while (iterator1.hasNext()) {
            Object value = iterator1.next();
            System.out.println(value);
        }

        //第三组
        //4.通过EntrySet来获取 k-v
        Set entrySet = map.entrySet();  //entrySet方法获取所有关系k-v
        //(1)增强for
        for (Object entry : entrySet) {
            //将entry 转成 Map.Entry
            Map.Entry m = (Map.Entry) entry;
            System.out.println(m.getKey() + "-" + m.getValue());
        }

        //(2)迭代器
        Iterator iterator2 = entrySet.iterator();
        while (iterator2.hasNext()) {
            Object obj = iterator2.next();
            //System.out.println(entry.getClass()); //HashMap$Node ->实现Map.Entry(getKey, getValue)
            //向下转型
            Map.Entry entry = (Map.Entry) obj;
            System.out.println(entry.getKey() + "-" + entry.getValue());
        }

    }
}
