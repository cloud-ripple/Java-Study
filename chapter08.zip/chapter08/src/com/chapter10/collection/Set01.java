package com.chapter10.collection;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * 日期：2023/2/23
 * 需求/说明：Set接口方法
 */

public class Set01 {
    public static void main(String[] args) {
        //1.以Set接口的实现类HashSet来讲解
        //2.Set接口的实现类的对象，不能存放重复元素，可以添加一个null
        //3.set接口对象存放数据是无序的，添加和取出的顺序不一致
        Set hashSet = new HashSet();
        hashSet.add("john");
        hashSet.add("lucy");
        hashSet.add("jack");
        hashSet.add("bobo");
        hashSet.add("bobo"); //重复元素
        hashSet.add(null);
        System.out.println(hashSet);

        //集合遍历  Set接口对象不能通过索引来获取集合中的元素，即并不能使用get(int index)方法
        //1.方式1 使用迭代器
        Iterator iterator = hashSet.iterator();
        while (iterator.hasNext()) {
            Object obj = iterator.next();
            System.out.println(obj);
        }

        //2.方式2 使用增强for
        for (Object o : hashSet) {
            System.out.println(o);
        }
        //以上两种遍历方式输出效果一样
    }
}
