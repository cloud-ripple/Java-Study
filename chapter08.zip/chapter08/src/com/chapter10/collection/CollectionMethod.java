package com.chapter10.collection;

import java.util.ArrayList;
import java.util.List;

/**
 * 日期：2023/2/22
 * 需求/说明：Collection接口常用方法，以其实现子类ArrayList来演示
 */

public class CollectionMethod {
    @SuppressWarnings({"all"})
    public static void main(String[] args) {
        //(1) add:添加单个元素
        List list = new ArrayList();
        list.add("bobo");
        list.add(10); //会自动装箱 int --> Integer
        list.add(true);
        System.out.println("list = " + list);

        //(2) remove:删除指定索引的元素
        list.remove(0); //根据下标，删除集合中的第一个元素
        list.remove("bobo"); //直接指定删除的元素
        System.out.println(list);

        //(3) contains:查找元素是否存在
        System.out.println(list.contains(true)); //返回true

        //(4) size:获取元素个数
        System.out.println("集合中元素个数 = " + list.size());

        //(5) isEmpty:判断是否为空
        System.out.println(list.isEmpty());
        //(6) clear:清空
        list.clear();
        System.out.println(list); //list=[]

        //(7) addAll:添加多个元素
        ArrayList list2 = new ArrayList();
        list2.add("花海");
        list2.add("忘语");
        //addAll(Collection c)方法 接收实现Collection接口的子类
        list.addAll(list2);
        System.out.println(list);

        //(8) containsAll:查找多个元素是否都存在
        //containsAll(Collection c)方法
        System.out.println(list.containsAll(list2)); //返回true

        //(9) removeAll:删除多个元素
        list.removeAll(list2);
    }
}
