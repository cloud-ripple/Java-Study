package com.chapter10.collection;

import java.util.HashSet;
import java.util.Set;

/**
 * 日期：2023/2/23
 * 需求/说明：Set接口实现类-HashSet
 */

public class HashSet01 {
    public static void main(String[] args) {

        Set hashSet = new HashSet();
        //1. boolean add(Object o) ,如果元素/对象添加成功，返回true，否则返回false
        //2. boolean addAll(Collection c) ,
        // 可以添加多个元素/对象，即可以接受一个实现了Collection接口的集合子类
        System.out.println(hashSet.add("john")); //true
        System.out.println(hashSet.add("lucy")); //t
        System.out.println(hashSet.add("jack")); //t
        System.out.println(hashSet.add("bobo")); //t
        System.out.println(hashSet.add("bobo")); //f

        hashSet.remove("john");
        System.out.println("hashSet = " + hashSet);

        hashSet = new HashSet(); //重置HashSet对象
        System.out.println(hashSet); //输出 [] 没有元素

        /** 3. HashSet不能添加相同的元素/对象 */
        hashSet.add("flower"); //添加成功 返回true
        hashSet.add("flower"); //添加失败
        hashSet.add(new Dogs("小白狗")); //添加成功 ok
        hashSet.add(new Dogs("小白狗")); //添加成功 ok
        System.out.println("集合中的元素情况： " + hashSet);
        /** new 是不同的对象，有不同的地址，即使name属性相同它们也不是同一个对象，只是同名而已
         * 不是同一条狗 */

        hashSet.add(new String("hsp")); //添加成功 ok
        hashSet.add(new String("hsp")); //添加不了


    }
}
class Dogs {
    private String name;

    public Dogs(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Dogs{" +
                "name='" + name + '\'' +
                '}';
    }
}
