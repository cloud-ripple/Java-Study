package com.chapter10.collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 日期：2023/3/1
 * 需求/说明：
 * 使用ArrayList完成对 对象Car{name, price}的各种操作
 * add:添加多个元素
 * remove:删除指定元素
 * contains:查找元素是否存在
 * size:获取元素个数
 * isEmpty:判断是否为空
 * clear:清空
 * addAll:添加多个元素
 * containsAll:查找多个元素是否存在
 * removeAll:删除多个元素
 * 使用增强for和迭代器来遍历所有的Car
 */

public class HomeWork02 {
    public static void main(String[] args) {
        List<Car> carList = new ArrayList();
        Car car1 = new Car("宝马", 400000);
        Car car2 = new Car("宾利", 5000000);
        Car car3 = new Car("奔驰", 7006000);
        Car car4 = new Car("奥迪", 9990000);
        carList.add(car1);
        carList.add(car2);
        carList.add(car3);
        carList.add(car4);

        carList.remove(car1); //删除
        System.out.println(carList);

        System.out.println(carList.contains(car2)); //查找
        //for增强遍历
        for (Object car : carList) {
            System.out.println(car);
        }
        //迭代器遍历
        Iterator<Car> carIterator = carList.iterator();
        while (carIterator.hasNext()) {
            System.out.println(carIterator.next());
        }

    }

}
class Car {
    private String name;
    private double price;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Car(String name, double price) {
        this.name = name;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Car{" +
                "name='" + name + '\'' +
                ", price=" + price +
                '}';
    }
}