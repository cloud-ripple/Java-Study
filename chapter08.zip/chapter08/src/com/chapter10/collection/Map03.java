package com.chapter10.collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * 日期：2023/2/27
 * 需求/说明：
 * 使用HashMap添加3个员工对象，要求：
 * 键：员工id
 * 值：员工对象
 * 并遍历显示工资>8000的员工
 * 员工类：姓名、工资、员工id
 */

public class Map03 {
    public static void main(String[] args) {
        Map map = new HashMap();
        map.put(1, new Employee("忘语", 6700, 1));
        map.put(2, new Employee("韩立", 8700, 2));
        map.put(3, new Employee("南宫婉", 9700, 3));

        Set keys = map.keySet(); //先取出所有的Key，通过Key取出对应的Value
        for (Object key : keys) {
            Object obj = map.get(key);
            Employee employee = (Employee) obj;
            if (employee.salary > 8000) {
                System.out.println(key + "-" + map.get(key));
            }
        }

        System.out.println("------遍历方式2---------");
        //使用迭代器遍历
        Iterator iterator = keys.iterator();
        while (iterator.hasNext()) {
            Object key = iterator.next(); //获取key
            Object obj = map.get(key); //通过key获取value
            Employee employee = (Employee) obj;
            if (employee.salary > 8000) {
                System.out.println(key + "-" + map.get(key));
            }
        }

        System.out.println("------遍历方式3---------");
        //使用EntrySet --> 迭代器遍历
        Set entrySet = map.entrySet();
        Iterator iterator1 = entrySet.iterator();
        while(iterator1.hasNext()) {
            Map.Entry entry = (Map.Entry) iterator1.next();
            //通过entry获取key \ value
            Employee emp = (Employee) entry.getValue();
            if (emp.salary > 8000) {
                System.out.println(entry.getKey() + "-" + emp);
            }
        }

    }
}

class Employee {
    String name;
    double salary;
    int id;

    public Employee(String name, double salary, int id) {
        this.name = name;
        this.salary = salary;
        this.id = id;
    }

    @Override
    public String toString() {
        return "name='" + name + '\'' +
                ", salary=" + salary +
                ", id=" + id;
    }
}