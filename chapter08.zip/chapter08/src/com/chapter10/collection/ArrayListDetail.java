package com.chapter10.collection;

import java.util.ArrayList;

/**
 * 日期：2023/2/22
 * 需求/说明：ArrayList的注意事项
 */

public class ArrayListDetail {
    public static void main(String[] args) {
        //(1) ArrayList可以加入null，并且多个
        //(2) ArrayList是由数组来实现数据存储的
        //(3) ArrayList基本等同于 Vector，除了ArrayList是线程不安全(执行效率高)，在多线程情况下，不建议使用ArrayList.
        ArrayList arrayList = new ArrayList();
        arrayList.add(null);
        arrayList.add("bobo");
        arrayList.add(null);
    }
}
