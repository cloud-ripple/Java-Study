package com.chapter10.collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 日期：2023/2/22
 * 需求/说明：
 * 创建3个Dog{name, age}对象，放入到 ArrayList中，赋给List引用
 * 用迭代器和增强for循环两种方式遍历
 */

public class CollectionExercise {
    public static void main(String[] args) {
        List list = new ArrayList();
        list.add(new Dog("小白", 13));
        list.add(new Dog("小花", 3));
        list.add(new Dog("小黑", 33));

        //所有实现了Collection接口的集合类都有一个 iterator()方法，
        // 用以返回一个实现了Iterator接口的对象 即可以返回一个迭代器。
        //1.获取迭代器
        Iterator iterator = list.iterator();
        //2.使用while遍历
        while (iterator.hasNext()) { //先调用hasNext()方法判断是否还有数据
            Object obj = iterator.next();//后调用next()方法，让指针访问元素，并返回
            System.out.println(obj); //遍历输出元素(对象)
        }

        System.out.println("-----for增强方式-------");
        //for增强遍历
        for (Object dog : list) {
            System.out.println(dog); //遍历输出
        }

    }
}
class Dog {
    private String name;
    private int age;

    public Dog(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}