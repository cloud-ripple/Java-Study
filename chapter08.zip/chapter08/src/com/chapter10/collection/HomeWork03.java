package com.chapter10.collection;

import java.util.*;

/**
 * 日期：2023/3/1
 * 需求/说明：
 * (1)使用HashMap类实例化一个Map类型的对象map,键(String 姓名)和值(int) 分别用于存储员工的姓名和工资
 * 存放数据如下：jack-650元  tom-1200元  smith-2900元
 * (2)将jack的工资更改为2600元
 * (3)为所有员工工资加薪 100元
 * (4)遍历集合中所有的员工
 * (5)遍历集合中所有的工资
 */

public class HomeWork03 {
    public static void main(String[] args) {
        Map<String, Integer> map = new HashMap<>();
        Worker jack = new Worker("员工1 jack", 650);
        Worker tom = new Worker("员工2 tom", 1200);
        Worker smith = new Worker("员工3 smith", 2900);

        map.put(jack.getName(), jack.getSal()); //添加元素 k-v
        map.put(tom.getName(), tom.getSal());
        map.put(smith.getName(), smith.getSal());

        //(2)将jack的工资更改为2600元
        map.put(jack.getName(), 2600); //方式1 k-v 中，键不能重复，如果k相同等于替换
        map.replace(jack.getName(), 2600); //方式2 调用replace方法
        System.out.println("jack的工资 = " + map.get("员工1 jack"));

        Collection<Integer> values = map.values(); //values方法获取所有 值v
        for (Integer salary : values) {
            System.out.println(salary);
        }

        //遍历
        System.out.println("-----使用增强for遍历---");
        Set<String> keys = map.keySet(); //获取所有的 键集
        //方式1 增强for
        for (String name : keys) {
            map.put(name, map.get(name) + 100); //方式1 k-v 中，键不能重复，如果k相同等于替换
            System.out.println(name + "-" + map.get(name)); // V get(Object key);通过键来获取值
        }
        System.out.println("----使用迭代器遍历----");
        //方式2 迭代器
        Set<String> key2 = map.keySet();
        Iterator<String> iterator = key2.iterator();
        while (iterator.hasNext()) {
            String key = iterator.next();
            System.out.println(key + "-" + map.get(key));
        }

        System.out.println("----使用entrySet----");
        //方式3 Map.Entry  通过entrySet来获取 k-v
        Set<Map.Entry<String, Integer>> entrySet = map.entrySet(); //获取键值关系
        for (Object obj : entrySet) {
            Map.Entry entry = (Map.Entry) obj;
            System.out.println(entry.getKey() + "-" + entry.getValue());
        }

        Iterator<Map.Entry<String, Integer>> iterator2 = entrySet.iterator();
        while (iterator2.hasNext()) {
            Map.Entry entry =  iterator2.next();
            System.out.println(entry.getKey() + "-" + entry.getValue());
        }
    }
}
class Worker {
    private String name;
    private int sal;

    public Worker(String name, int sal) {
        this.name = name;
        this.sal = sal;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSal() {
        return sal;
    }

    public void setSal(int sal) {
        this.sal = sal;
    }

    @Override
    public String toString() {
        return "Worker{" +
                "name='" + name + '\'' +
                ", sal=" + sal +
                '}';
    }
}
