package com.chapter10.collection;

import java.util.ArrayList;

/**
 * 日期：2023/2/23
 * 需求/说明：ArrayList扩容机制底层结构源码分析
 */

public class ArrayListSource01 {
    /*
    (1) ArrayList中维护了一个Object类型的数组 elementData.//看源码 transient Object[] elementData;
    (2) 当创建ArrayList对象时，如果使用的是无参构造器，则初始elementData容量为0，
    第一次添加元素，则扩容elementData为10，如需再次扩容，则扩容elementData为1.5倍。
    (3) 如果使用的是指定大小的构造器，则初始elementData容量为指定大小，如果需要扩容
    则直接扩容elementData为1.5倍。*/
    public static void main(String[] args) {

        ArrayList list = new ArrayList(); //使用无参构造器创建
        //给list集合添加1-10数据
        for (int i = 0; i < 10; i++) {
            list.add(i);
        }
        //给list集合添加11-15数据
        for (int i = 11; i < 15; i++) {
            list.add(i);
        }
        list.add(100);
        list.add(200);
        list.add(null);
    }
}
