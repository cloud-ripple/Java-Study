package com.chapter10.collection;


import java.util.ArrayList;
import java.util.HashMap;

/**
 * 日期：2023/2/22
 * 需求/说明：
 */

public class Collection_ {
    public static void main(String[] args) {
        /*1.集合主要是两组，即单列集合、双列集合
        2. Collection接口有两个重要的子接口 List、Set，它们的实现子类都是单列集合
        3. Map接口的实现子类是双列集合，存放的K-V
        * */
        ArrayList arrayList = new ArrayList();
        arrayList.add("jack");
        arrayList.add("tom");

        HashMap hashMap = new HashMap();
        hashMap.put("NO1", "北京");
        hashMap.put("NO2", "上海");
    }
}
