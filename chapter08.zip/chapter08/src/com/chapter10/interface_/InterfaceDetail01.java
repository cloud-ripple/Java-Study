package com.chapter10.interface_;

public class InterfaceDetail01 {
    public static void main(String[] args) {
        /** 1.接口不能被实例化 接口本身就是一个抽象的概念，它希望别的类来实现其中的方法*/
        //new IA();
    }
}

interface IA {
    /** 2.接口中所有方法和属性是public公共的，接口中抽象方法，可以不用abstract关键字来修饰 */
    void say(); //该方法本身默认就是抽象的 --> 等价于 public abstract void say();
    void hi();
}
/** 3.一个普通类实现接口，就必须将该接口的所有方法(全部)都实现,实现就是重写*/
class Cat implements IA {
    @Override
    public void say() {

    }

    @Override
    public void hi() {

    }
}
/** 4.抽象类实现接口，可以不用实现接口中的方法, 即不用重写接口中的方法 */
abstract class Tiger implements IA {

}
