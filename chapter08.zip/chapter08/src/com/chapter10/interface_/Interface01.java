package com.chapter10.interface_;


public class Interface01 {
    public static void main(String[] args) {
        Phone phone = new Phone();
        Computer computer = new Computer();
        computer.work(phone); //把手机接入到计算机
    }
}
interface UsbInterface { //usb接口
    //规定接口的相关方法
    public void start();
    public void stop();
}
//Phone类实现 该接口
class Phone implements UsbInterface {
    @Override
    public void start() {
        System.out.println("手机开始工作...");
    }

    @Override
    public void stop() {
        System.out.println("手机停止工作.");
    }
}
class Computer {
    public void work(UsbInterface usbInterface) {
        usbInterface.start();
        usbInterface.stop();
    }
}
