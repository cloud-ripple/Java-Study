package com.chapter10.interface_;

public class InterfaceExercise02 {
    public static void main(String[] args) {
        new Cc().pX();
        System.out.println("haha");
    }

}
/** 接口中的属性都是 public static final 修饰的
 * 接口中所有方法是public公共方法，接口中抽象方法，可以不用abstract关键字来修饰 */
interface Aaa {
    int x = 0; //等价于 public static final int x = 0;
}
class B {
    int x = 1;
}
class Cc extends B implements Aaa {

    public void pX() {
        //System.out.println(x); 错误 没有指定是那里的变量
        /** 如果访问接口中的x，就使用 接口名.属性名 --> Aa.x
         * 如果访问父类中的x，就使用 super.x */
        System.out.println("接口中的属性 x = " + Aaa.x + " 父类中的属性x = " + super.x);
    }
//
    public static void main(String[] args) {
        new Cc().pX();
    }

}
