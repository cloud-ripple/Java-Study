package com.chapter10.interface_;

public class Interface02 {
    public static void main(String[] args) {
    }
}
//接口
interface AInterface {
    public int n1 = 100; //属性
    /** 在接口中，抽象方法，可以省略 abstract关键字 */
    public abstract void hi(); //(抽象)方法，没有方法体
    /** 在jdk8.0后，接口中可以有默认实现方法，需要使用 default关键字修饰,否则会报错 */
    default public void ok() {
        System.out.println("bobo");
    }
    /** 在jdk8.0后，可以有静态方法 ,如果此处不用static关键字修饰，会报错
     * 静态方法在接口中必须要有方法体 */
    public static void cry() {
        System.out.println("cry....");
    }
}
//类A来实现(implements)接口中的抽象方法
/**1.如果一个类 implements(实现) 接口
 * 2.需要将该接口中的所有抽象方法(是全部)都要实现
 * */
class A implements AInterface {
    @Override
    public void hi() {
        System.out.println("hi...");
    }
}
