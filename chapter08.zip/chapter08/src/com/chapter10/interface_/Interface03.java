package com.chapter10.interface_;

public class Interface03 {
    public static void main(String[] args) {
        MysqlDB mysqlDB = new MysqlDB();
        t(mysqlDB);
        t(new OracleDB());
    }
    //随便定义一个方法，接收一个实现DBInterface接口中方法的类
    /** DBInterface接口看作父类，接收一个子类对象，----> 向上转型，体现多态 */
    public static void t(DBInterface db) {
        db.connect();
        db.close();
    }
}
//接口
interface DBInterface {
    public void connect(); //连接方法
    public void close(); //关闭方法
}
/** implements(实现)可以理解为继承，把接口看作父类 */
//让类MysqlDB去实现接口中的方法。
class MysqlDB implements DBInterface {
    @Override
    public void connect() {
        System.out.println("连接mysql..");
    }

    @Override
    public void close() {
        System.out.println("关闭mysql..");
    }
}

//让OracleDB类去实现接口中的方法
class OracleDB implements DBInterface {
    @Override
    public void connect() {
        System.out.println("连接oracle..");
    }

    @Override
    public void close() {
        System.out.println("关闭oracle..");
    }
}