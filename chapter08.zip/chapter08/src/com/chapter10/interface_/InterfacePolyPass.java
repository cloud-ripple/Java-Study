package com.chapter10.interface_;
/** 接口的多态特性 多态传递现象 */
public class InterfacePolyPass {
    public static void main(String[] args) {
        /** 接口多态 (接口引用可以指向实现了该接口的类的对象实例) */
        IG ig = new Teacher(); /** 向上转型 父类的引用指向了子类对象 */
        //由于接口IG继承了接口IH，而Teacher类实现了 IG 接口
        //那么，实际上就相当于 Teacher类也实现了 IH 接口
        IH ih= new Teacher();
    }
}
//接口 IH
interface IH {
    void ok();
}
//接口 IG继承接口 IH
/** 接口间的继承 */
interface IG extends IH {}
/** 此处让Teacher类去实现接口 IG，则该接口的引用可以指向该类对象的实例
 * 由于接口IG继承了接口 IH，形成了传递，
 * 所以接口IH的引用也可以指向Teacher类的对象实例 */
class Teacher implements IG {
    @Override
    public void ok() { //由于接口继承原因，该类也实现了接口IH，所以也需要实现该接口中的方法
        System.out.println("ok.");
    }
}
