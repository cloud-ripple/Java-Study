package com.chapter10.interface_;

public class InterfaceExercise01 {
    public static void main(String[] args) {
        BB bb = new BB();
        /** 静态成员既可以通过类名直接访问调用，也可以通过创建实例对象去访问调用
         * 接口名.属性名 可以访问接口中的属性 */
        System.out.println(bb.a); //输出 23
        System.out.println(AA.a); //输出 23
        System.out.println(BB.a); //输出 23
    }
}
interface AA { //接口AA
    int a = 23; //等价于 public static final int a = 23;
}
/** implements实现(可以看作是继承)了接口，则该类也拥了有接口中的属性，
 * 且属性是 public static final修饰的 */
class BB implements AA { //让类BB去实现接口AA

}