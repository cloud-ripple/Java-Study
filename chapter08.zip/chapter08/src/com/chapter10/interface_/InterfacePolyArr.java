package com.chapter10.interface_;

public class InterfacePolyArr {
    public static void main(String[] args) {
        /** 接口的多态特性 多态数组 --- > 接口类型数组 */
        Usb[] usbs = new Usb[2];
        usbs[0] = new Phone_(); /** 向上转型 父类的引用指向了子类对象 */
        usbs[1] = new Camera_();
        for (int i = 0; i < usbs.length; i++) {
            usbs[i].work(); //调用方法时，会进行动态绑定机制
            if (usbs[i] instanceof Phone_) {
                /** 判断接口引用指向的对象实例类型是否为 Phone_类型
                 * 并进行向下转型 */
                Phone_ phone_ = (Phone_) usbs[i]; //等价于 ((Phone_) usbs[i]).call();
                phone_.call();
            }
        }
    }
}
interface Usb {
    void work();
}
class Phone_ implements Usb {
    @Override
    public void work() {
        System.out.println("手机工作中..");
    }

    public void call() {
        System.out.println("手机可以打电话..");
    }
}
class Camera_ implements Usb {
    @Override
    public void work() {
        System.out.println("相机工作中...");
    }
}