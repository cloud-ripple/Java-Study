package com.chapter10.interface_;

public class InterfaceAndExtends {
    public static void main(String[] args) {
        LittleMonkey littleMonkey = new LittleMonkey("小金丝猴");
        littleMonkey.climbing(); /** 子类继承得到的能力 */
        test(littleMonkey, littleMonkey);
        /** 小结：
         * 1.当子类继承了父类，就自动拥有了父类的功能
         * 2.如果子类需要扩展功能，可以通过实现接口的方式来扩展
         * 3.可以理解为，实现接口 是对java中单继承机制的一种补充 */
    }
    //静态方法，接收两个实现该接口的类对象
    public static void test(FishInterface fish, BirdInterface bird) {
        /** 由该类去实现接口中的方法所拥有的能力或功能 */
        fish.swimming();
        bird.flying();
    }
}
//父类Monkey
class Monkey {
    private String name;
    public Monkey(String name) {
        //super();
        this.name = name;
    }
    public void climbing() { //爬树方法
        System.out.println("猴子会爬树..");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

interface FishInterface { //接口中定义了一个方法
    public void swimming();
}

interface BirdInterface { //接口中定义了一个方法
    public void flying();
}
//子类 LittleMonkey 去继承父类Monkey，并让它去实现接口中的所有方法
/** 由于单继承机制(子类不能继承多个父类)，虽然子类LittleMonkey继承了父类Monkey
 * ，让子类拥有了父类中的 climbing() 爬树方法
 * 但是如果还想要子类LittleMonkey拥有其它能力或功能，
 * 比如接口中的swimming()、flying()游泳和飞翔方法，那么可以让该类去实现多个接口 */
class LittleMonkey extends Monkey implements FishInterface,BirdInterface {
    public LittleMonkey(String name) {
        super(name);
    }

    @Override
    public void flying() { //实现了接口中的flying()方法
        System.out.println(this.getName() + "通过努力学习会 飞天了..");
    }

    @Override
    public void swimming() { //实现了接口中的swimming()方法
        System.out.println(this.getName() + "通过努力学习会 游泳了..");
    }
}
