package com.chapter10.interface_;
/** 接口的多态特性 多态参数 */
public class InterfacePolyParameter {
    public static void main(String[] args) {
        /** 1.接口多态 (接口引用[即接口名]可以指向实现了该接口的类的对象实例) */
        /** 向上转型 父类的引用指向了子类对象 */
        InterF f1 = new Monster(); //f1的接口类型是InterF
        f1 = new Car();
        /** 2.继承体现的多态
         * 父类类型的引用 可以指向继承AAA的对象实例 */
        AAA a = new BBB();
        a = new CCC();

    }
}
//接口 InterF
interface InterF {}
class Monster implements InterF {}
class Car implements InterF {}

class AAA { }
class BBB extends AAA {}
class CCC extends AAA {}