package com.chapter10.interface_;

public class InterfaceDetail02 {
    public static void main(String[] args) {
        //如何证明接口中的属性是 public公开 static静态 final的
        /** 7.接口中属性的访问形式：接口名.属性名 */
        System.out.println(IB.n1);
        //IB.n1 = 30; //写法错误 final修饰的属性不能被修改
    }
}
//两个接口 IB IC
interface IB {
    /** 6.接口中的属性(都是公开的、静态的、final修饰的),final修饰的属性必须初始化值 */
    int n1 = 10; //等价于 ---> public static final int n1 = 10;
    void hi();
}
interface IC {
    void say();
}

/** 8.一个接口不能继承其他的类，但是可以继承多个别的接口
 * 即接口之间可以是继承，但类与接口之间是 类去实现接口中的方法
 * 9.接口的修饰符只能是 public 和 默认，这点和类的修饰符是一样的 */
interface ID extends IB,IC { //让接口ID去继承其它两个接口

}

/** 5.一个类同时可以实现多个接口 */
class Pig implements IB,IC {
    @Override
    public void say() {

    }

    @Override
    public void hi() {

    }
}
