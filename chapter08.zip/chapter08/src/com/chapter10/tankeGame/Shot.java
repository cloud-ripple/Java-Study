package com.chapter10.tankeGame;

import java.util.Vector;

/**
 分析如何实现当用户按下J键，我们的坦克就发射一颗子弹：
 1.当发射一颗子弹后，就相当于启动一个线程
 2.Hero有子弹的对象，当按下J时，我么就启动一个发射行为(线程)，让子弹不停的移动，形成一个射击效果
 3.我们MyPanel需要不停的重绘子弹，才能出现该效果
 4.当子弹移动到面板的边界时，就应该销毁(把启动的子弹的线程销毁)
 */
//shot 射击
public class Shot implements Runnable {
    int x; //子弹的横坐标
    int y; //子弹的纵坐标
    int direct = 0; //子弹的方向，默认向上
    int speed = 2; //子弹的速度
    boolean isLive = true; //子弹默认是存活的(即飞行中)

    public Shot(int x, int y, int direct) {
        this.x = x;
        this.y = y;
        this.direct = direct;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getDirect() {
        return direct;
    }

    public void setDirect(int direct) {
        this.direct = direct;
    }

    @Override
    public void run() { //射击行为
        while (true) {
            //休眠50毫秒
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            //根据方向来改变横纵坐标
            switch(direct) {
                case 0 : //向上
                    y -= speed;
                    break;
                case 1 : //向下
                    y += speed;
                    break;
                case 2 : //向左
                    x -= speed;
                    break;
                case 3 : //向右
                    x += speed;
                    break;
            }
            //System.out.println("子弹 x坐标 = " + x + ",子弹 y坐标 = " + y);
            //4.当子弹移动到面板的边界时，就应该销毁(把启动的子弹的线程销毁)
            //当子弹碰到敌人坦克时，也应该结束线程
            if (!(x >= 0 && x <= 1000 && y >= 0 && y <= 750 && isLive)) {  //面板边界++++++++++++++++++++++++++++++++的宽高为 1000，750
                isLive = false; //子弹销毁
                System.out.println("子弹出界");
                break; //退出循环，也就退出了线程
            }
        }
    }
}
