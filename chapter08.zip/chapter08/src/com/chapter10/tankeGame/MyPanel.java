package com.chapter10.tankeGame;


import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Vector;

/**
 * 日期：2023/3/4
 * 需求/说明：坦克游戏画面
 */

public class MyPanel extends JPanel implements KeyListener, Runnable {

    //定义我的坦克
    Hero hero = null;

    //定义敌人的坦克，放到Vector
    Vector<EnemyTank> enemyTanks = new Vector<>();

    //定义一个Vector，用于存放炸弹
    //说明，当子弹击中坦克时，加入一个Bomb对象到Vector
    Vector<Bomb> bombs = new Vector<>();

    //定义Node的Vector，用于存放/恢复从文件读取的上一句存活敌人坦克的信息
    Vector<Node> nodes = new Vector<>();

    //定义三张炸弹图片，用于显示爆炸效果
    Image img1 = null;
    Image img2 = null;
    Image img3 = null;

    //定义敌人坦克数量
    static int enemyTankSize = 8;

    //坦克炮筒移动的方向
    private static final int TANK_UP = 0; //坦克向上
    private static final int TANK_DOWN = 1; //坦克向下
    private static final int TANK_LEFT = 2; //坦克向左
    private static final int TANK_RIGHT = 3; //坦克向右

    public MyPanel() {
        Recorder.setEnemyTanks(enemyTanks);
        //初始化自己的坦克，并给出横纵坐标
        hero = new Hero(200, 300);

        //初始化敌人的坦克 添加到集合中
        for (int i = 0; i < enemyTankSize; i++) {
            //每次创建不同的坦克赋给enemyTank，然后添加到集合中
            EnemyTank enemyTank = new EnemyTank((100 * (i + 1)), 0);
            //第一辆坦克的横坐标 100 * 1 = 100 第二辆 100 * 2 = 200 第三辆 100 * 3 = 300
            //将enemyTanks设置给 EnemyTank对象
            enemyTank.setEnemyTanks(enemyTanks);
            enemyTank.setDirect(1); //统一设置敌人坦克方向 向下
            //启动敌人坦克自由移动线程
            Thread thread = new Thread(enemyTank);
            thread.start();
            //给该enemyTank 加入一颗子弹
            Shot shot = new Shot(enemyTank.getX() + 20, enemyTank.getY() + 60, enemyTank.getDirect());
            //加入EnemyTank的Vector<Shot>
            enemyTank.shots.add(shot);
            //启动 shot对象线程
            new Thread(shot).start();
            enemyTanks.add(enemyTank); //添加
        }
        //初始化图片对象
        img1 = Toolkit.getDefaultToolkit().getImage(Panel.class.getResource("/bomb1.png"));
        img2 = Toolkit.getDefaultToolkit().getImage(Panel.class.getResource("/bomb2.png"));
        img3 = Toolkit.getDefaultToolkit().getImage(Panel.class.getResource("/bomb3.png"));
    }

    //编写方法，显示我方击毁敌人坦克的信息
    public void showInfo(Graphics g) {
        //画出玩家的总成绩
        g.setColor(Color.BLACK);
        Font font = new Font("宋体", Font.BOLD, 15);
        g.setFont(font);
        g.drawString("你累计击毁敌方坦克", 1020, 60);
        drawTank(1040, 80, g, 0, 1);
        g.setColor(Color.BLACK);
        g.drawString(Recorder.getAllEnemyTankNum() + "", 1100, 120);
    }

    @Override
    public void paint(Graphics g) { //绘图方法 当组件第一次在屏幕显示的时候，程序会自动的调用paint()方法来绘制组件
        super.paint(g);
        g.fillRect(0, 0, 1000, 750); //面板背景
        showInfo(g);

        //画出自己的坦克
        if (hero != null && hero.isLive) {
            drawTank(hero.getX(), hero.getY(), g, hero.getDirect(), 0);
        }

        //画出敌人的坦克 遍历Vector
        for (int i = 0; i < enemyTanks.size(); i++) {
            //从Vector取出坦克
            EnemyTank enemyTank = enemyTanks.get(i);

            //判断当前坦克是否还存活
            if (enemyTank.isLive) { //当敌人坦克是存活的，才画出坦克
                //画敌人坦克
                drawTank(enemyTank.getX(), enemyTank.getY(), g, enemyTank.getDirect(), 1);

                //画出每一个enemyTank的所有子弹
                for (int j = 0; j < enemyTank.shots.size(); j++) {
                    //取出子弹
                    Shot shot = enemyTank.shots.get(j);
                    //绘制
                    if (shot.isLive) { //isLive == true 子弹存活时
                        g.setColor(Color.red);
                        g.fill3DRect(shot.x, shot.y, 5, 5, false);
                    } else {
                        //从Vector移除 出界、死亡的子弹
                        enemyTank.shots.remove(shot);
                    }
                }
            }
        }

        //画出自己坦克发出的子弹 将hero自己坦克的子弹集合shots，遍历取出绘制
        for (int i = 0; i < hero.shots.size(); i++) {
            Shot shot = hero.shots.get(i);
            if (shot != null && shot.isLive == true) {
                //System.out.println("子弹被重绘1");
                g.setColor(Color.yellow);
                g.fill3DRect(shot.x, shot.y, 5, 5, false); //画子弹
            } else { //如果该Shot子弹对象，已经销毁了，就从子弹集合shots中移除
                hero.shots.remove(shot);
            }
        }

        //如果Vector bombs集合中有对象，就画出炸弹
        for (int i = 0; i < bombs.size(); i++) {
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            //获取炸弹
            Bomb bomb = bombs.get(i);
            //根据当前炸弹bomb对象的life值去画出对应的图片 --> 配合出现图片的爆炸效果
            if (bomb.life > 6) {
                g.drawImage(img1, bomb.x, bomb.y, 60, 60, this);
            } else if (bomb.life > 3) {
                g.drawImage(img2, bomb.x, bomb.y, 60, 60, this);
            } else {
                g.drawImage(img3, bomb.x, bomb.y, 60, 60, this);
            }
            //让炸弹的生命值减少
            bomb.lifeDown();
            //如果bomb 的life为0，就从集合bombs中删除
            if (bomb.life == 0) {
                bombs.remove(bomb);
            }
        }
    }

    //画出坦克 封装方法
    /**
     * @param x 坦克的横坐标
     * @param y
     * @param g 画笔
     * @param direct 坦克方向
     * @param type 坦克类型
     * */
    public void drawTank(int x, int y, Graphics g, int direct, int type) {
        //根据不同类型坦克，设置不同颜色
        switch (type) {
            case 0: //我么自己的坦克
                g.setColor(Color.yellow);
                break;
            case 1: //敌人的坦克
                g.setColor(Color.cyan);
                break;
        }

        //根据坦克方向，来绘制坦克
        switch (direct) {
            case 0: //表示向上
                g.fill3DRect(x, y, 10, 60, false); //画出坦克左边的轮子
                g.fill3DRect(x + 30, y, 10, 60, false); //画出坦克右边的轮子
                g.fill3DRect(x + 10, y + 10, 20, 40, false); //画出坦克盖子
                g.fillOval(x + 10, y + 20, 20, 20); //画出圆形盖子
                g.drawLine(x + 20, y + 30, x + 20, y); //炮筒
                break;
            case 1: //表示向下
                g.fill3DRect(x, y, 10, 60, false); //画出坦克左边的轮子
                g.fill3DRect(x + 30, y, 10, 60, false); //画出坦克右边的轮子
                g.fill3DRect(x + 10, y + 10, 20, 40, false); //画出坦克盖子
                g.fillOval(x + 10, y + 20, 20, 20); //画出圆形盖子
                g.drawLine(x + 20, y + 60, x + 20, y + 30); //炮筒
                break;
            case 2: //表示向左
                g.fill3DRect(x , y , 60, 10, false); //画出坦克左边的轮子
                g.fill3DRect(x , y + 30, 60, 10, false); //画出坦克右边的轮子
                g.fill3DRect(x + 10, y + 10, 40, 20, false); //画出坦克盖子
                g.fillOval(x + 18, y + 8, 20, 20); //画出圆形盖子
                g.drawLine(x , y + 20, x + 30, y + 20); //炮筒
                break;
            case 3: //表示向右
                g.fill3DRect(x , y , 60, 10, false); //画出坦克左边的轮子
                g.fill3DRect(x , y + 30, 60, 10, false); //画出坦克右边的轮子
                g.fill3DRect(x + 10, y + 10, 40, 20, false); //画出坦克盖子
                g.fillOval(x + 18, y + 8, 20, 20); //画出圆形盖子
                g.drawLine(x + 30, y + 20, x + 60, y + 20); //炮筒
                break;
            default:
                System.out.println("暂时没有处理");
        }
    }


    //判断我方子弹是否击中敌人坦克
    public void hitEnemyTank() {
        //多颗子弹击中时爆炸
        for (int i = 0; i < hero.shots.size(); i++) {
            //如果我么的坦克可以发射多颗子弹,需要把我们的子弹集合中，所有的子弹都遍历取出和敌人所有坦克进行判断
            Shot shot = hero.shots.get(i);
            if (shot != null && shot.isLive) {
                for (int j = 0; j < enemyTanks.size(); j++) {
                    EnemyTank enemyTank = enemyTanks.get(j);
                    hitTank(shot, enemyTank);
                }
            }
        }

        //单颗子弹击中时爆炸
//        if (hero.shot != null && hero.shot.isLive) { //当自己的坦克的子弹存活,并且子弹对象不为空，即有子弹
//            //遍历敌人所有的坦克
//            for (int i = 0; i < enemyTanks.size(); i++) {
//                EnemyTank enemyTank = enemyTanks.get(i);
//                hitTank(hero.shot, enemyTank); //
//            }
//        }
    }

    //封装方法，判断是否击中坦克
    //什么时候判断 我方坦克的子弹是否击中敌人 ？ --> 在run方法中循环判断，因为子弹是移动的
    public void hitTank(Shot shot, Tank tank) { //tank可以是自己坦克Hero，也可以是敌人坦克EnemyTank
        switch (tank.getDirect()) {
            case 0 : //上
            case 1 : //下 这两个方向被子弹击中时效果是一样的
                //子弹进入到坦克本体区域
                if (shot.x > tank.getX() && shot.x < tank.getX() + 40
                && shot.y > tank.getY() && shot.y < tank.getY() + 60) {
                    shot.isLive = false; //子弹销毁
                    tank.isLive = false; //坦克销毁
                    //当我的子弹击中对方坦克后，将enemyTank从Vector集合中移除
                    enemyTanks.remove(tank);
                    //创建Bomb对象，加入到Vector集合
                    Bomb bomb = new Bomb(tank.getX(), tank.getY());
                    bombs.add(bomb);
                    if (tank instanceof EnemyTank) { //运行类型是敌人坦克
                        Recorder.addAllEnemyTankNum(); //记录下击毁敌方坦克的数量
                    }
                }
                break;
            case 2 : //左
            case 3 : //右
                if (shot.x > tank.getX() && shot.x < tank.getX() + 60
                && shot.y > tank.getY() && shot.y < tank.getY() + 40) {
                    shot.isLive = false; //子弹销毁
                    tank.isLive = false; //坦克销毁
                    //创建Bomb对象，加入到Vector集合
                    //当我的子弹击中对方坦克后，将enemyTank从Vector集合中移除
                    enemyTanks.remove(tank);
                    Bomb bomb = new Bomb(tank.getX(), tank.getY());
                    bombs.add(bomb);

                    if (tank instanceof EnemyTank) {
                        Recorder.addAllEnemyTankNum(); //记录下击毁敌方坦克的数量
                    }
                }
                break;
        }
    }

    //判断敌人坦克是否击中我的坦克
    public void hitHero() {
        for (int i = 0; i < enemyTanks.size(); i++) {
            //取出敌人坦克
            EnemyTank enemyTank = enemyTanks.get(i);
            //遍历敌人坦克enemyTank对象的所有子弹
            for (int j = 0; j < enemyTank.shots.size(); j++) {
                //取出子弹
                Shot shot = enemyTank.shots.get(j);
                //判断 shot是否击中我的坦克hero
                if (hero.isLive && shot.isLive) {
                    hitTank(shot, hero);
                }
            }
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        //通过按键指定坦克的移动方向
        if ( e.getKeyCode() == KeyEvent.VK_UP) {
            hero.setDirect(TANK_UP); //改变坦克方向
            //控制自己坦克的移动范围
            if (hero.getY() > 0) {  //当自己的坦克在顶部边界之外时，才可以继续向上移动
                System.out.println("向上移动");
                hero.moveUp(); //坦克移动，本质上时修改了坦克的坐标
            }

        } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            hero.setDirect(TANK_DOWN);
            if (hero.getY() + 60 < 750) {
                hero.moveDown();
            }
        } else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            hero.setDirect(TANK_LEFT);
            if (hero.getX() > 0) {
                hero.moveLeft();
            }
        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            hero.setDirect(TANK_RIGHT);
            if (hero.getX() + 60 < 1000) {
                hero.moveRight();
            }
        }

        //如果用户按下J键，就发射子弹
        if (e.getKeyCode() == KeyEvent.VK_J) {
            System.out.println("玩家按下了J键，开始射击！");
            //我方坦克在发射的子弹销毁后，才能发射新的子弹
//            if (hero.shot == null || hero.shot.isLive == false) {   // ---> 只能发射一颗子弹
//                hero.shotEnemyTank();
//            }
            hero.shotEnemyTank(); //发射多颗子弹
        }

        //
        repaint(); //重新绘制，刷新面板
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    @Override
    public void run() {
        while (true) {

            //每隔1秒重绘
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            //我的坦克击中敌方坦克
            hitEnemyTank();
            //敌方坦克击中我的坦克
            hitHero();

            repaint();
        }
    }
}
