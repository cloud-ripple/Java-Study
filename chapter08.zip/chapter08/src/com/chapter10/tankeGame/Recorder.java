package com.chapter10.tankeGame;

import java.io.*;
import java.util.Vector;

/**
 * 日期：2023/3/11
 * 需求/说明：
 */
//该类用于记录相关信息，和文件交互
public class Recorder {
    //定义变量，记录我方击毁敌人坦克数量
    private static int allEnemyTankNum = 0;
    //定义IO对象,准备写数据到文件中
    private static FileWriter fw = null;
    private static BufferedWriter bw = null;
    private static BufferedReader br = null;
    private static String recordFile = "d:\\myRecord.txt";

    //定义Vector，指向MyPanel对象的敌人坦克Vector
    private static Vector<EnemyTank> enemyTanks = null;

    //定义一个Node的Vector，用于保存敌人的信息
    private static Vector<Node> nodes = new Vector<>();

    public static void setEnemyTanks(Vector<EnemyTank> enemyTanks) {
        Recorder.enemyTanks = enemyTanks;
    }

    //增加一个方法，用于读取recordFile，恢复相关信息
    //该方法在继续上局游戏时调用即可
    public static Vector<Node> getNodesAndEnemyTankNum() {
        try {
            br = new BufferedReader(new FileReader(recordFile));
            allEnemyTankNum = Integer.parseInt(br.readLine()); //读取的第一行信息，为击毁敌人坦克的数量

            String line = null;
            while ((line = br.readLine()) != null) { //循环读取
                //System.out.println(line);  每一行坦克的坐标及方向信息 类似 --> 100 196 1
                String[] xyd = line.split(" ");
                Node node = new Node(Integer.parseInt(xyd[0]), Integer.parseInt(xyd[1]), Integer.parseInt(xyd[2]));
                nodes.add(node); //把上局存活的敌人坦克坐标和方向信息封装成一个对象，放到集合中
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }
        return nodes;
    }
    //当游戏退出时，将allEnemyTankNum值保存到 recordFile，记录下击毁数量
    //升级，保存敌人坦克的坐标和方向
    public static void keepRecord() {
        try {
            fw = new FileWriter(recordFile);
            bw = new BufferedWriter(fw);
            bw.write(allEnemyTankNum + "");
            bw.newLine();
            //遍历敌人坦克的Vector,然后根据情况保存即可
            for (int i = 0; i < enemyTanks.size(); i++) {
                //取出敌人坦克
                EnemyTank enemyTank = enemyTanks.get(i);
                if (enemyTank.isLive) { //记录存活坦克的信息，写入文件
                    //保存该enemyTank信息 坐标、方向
                    String record = enemyTank.getX() + " " + enemyTank.getY() + " " + enemyTank.getDirect();
                    //写入到文件
                    bw.write(record);
                    bw.newLine();
                }
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if (bw != null) {
                    bw.close();
                }

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public static int getAllEnemyTankNum() {
        return allEnemyTankNum;
    }

    public static void setAllEnemyTankNum(int allEnemyTankNum) {
        Recorder.allEnemyTankNum = allEnemyTankNum;
    }

    //当我方坦克击毁一个敌人坦克，allEnemyTankNum++
    public static void addAllEnemyTankNum() {
        Recorder.allEnemyTankNum++;
    }
}
