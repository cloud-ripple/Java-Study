package com.chapter10.tankeGame.draw;

import javax.swing.*;
import java.awt.*;

/**
 * 日期：2023/3/4
 * 需求/说明：画圆
 */

public class DrawCircle extends JFrame {

    private MyPanel mp = null; //定义一个面板

    public static void main(String[] args) {
        DrawCircle circle = new DrawCircle();
    }

    public DrawCircle() {
        mp = new MyPanel(); //初始化面板
        this.add(mp); //把面板添加到窗口中
        this.setSize(400, 400);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }
}

class MyPanel extends JPanel {
    //Graphics 可以理解成一致画笔
    @Override
    public void paint(Graphics g) { //绘图方法
        super.paint(g); //调用父类方法完成初始化
        //g.drawOval(10, 10, 100, 100); //画椭圆

        //(6)画图片 drawImage
        //1.获取图片资源
        Image image = Toolkit.getDefaultToolkit().getImage(Panel.class.getResource("/flower.jpg"));
        //g.drawImage(image, 20, 20, 264, 264, this);


        g.drawRect(30, 30, 10, 40);
        g.drawRect(60, 30, 10, 40);
        g.drawRect(40, 38, 19, 25);

        g.drawOval(40, 40, 19, 19);
        g.drawLine(50, 50, 50, 25);
        g.setColor(Color.blue);

        g.fillRect(30, 30, 10, 40);
        g.fillRect(60, 30, 10, 40);
        g.fillRect(40, 38, 19, 25);

        g.setColor(Color.CYAN);
        g.fillOval(40, 40, 19, 19);



    }
}