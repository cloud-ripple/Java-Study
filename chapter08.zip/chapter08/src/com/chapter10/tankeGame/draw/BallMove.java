package com.chapter10.tankeGame.draw;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * 日期：2023/3/4
 * 需求/说明：
 * 演示小球通过键盘控制上下左右的移动 --> 讲解java的事件控制
 */

public class BallMove extends JFrame {
    Panel panel = null;
    public static void main(String[] args) {
        BallMove ballMove = new BallMove();
    }

    public BallMove(){
        panel = new Panel();
        this.add(panel); //把面板添加到窗口中
        this.setSize(400, 300);
        this.addKeyListener(panel); //给窗口添加键盘监听事件，传入面板，集可以监听到面板发生的事件
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }
}
//KeyListener 监听键盘事件
class Panel extends JPanel implements KeyListener {
    //为了让小球可以移动，把它的左上角的坐标设置变量
    int x = 10; //初始化位置
    int y = 10;
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        g.fillOval(x, y, 20, 20); //画笔填充
    }

    @Override
    public void keyTyped(KeyEvent e) { //有字符输出时，该方法就会触发

    }

    @Override
    public void keyPressed(KeyEvent e) { //当某个键按下，该方法会触发
        //System.out.println((char)e.getKeyCode() + "键被按下了");
        //根据用户按下的不同键，来处理小球的移动，上下左右键
        if (e.getKeyCode() == KeyEvent.VK_DOWN) { //VK_DOWN 向下的键
            y += 5; //每次按下键，就改变小球的纵坐标,向下移动5个偏移量
        } else if (e.getKeyCode() == KeyEvent.VK_UP) { //上
            y -= 5;
        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) { //右
            x += 5;
        } else if (e.getKeyCode() == KeyEvent.VK_LEFT) { //左
            x -= 5;
        }

        //让面板重新绘制，即刷新面板
        this.repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) { //当某个键释放/松开，该方法会触发

    }
}