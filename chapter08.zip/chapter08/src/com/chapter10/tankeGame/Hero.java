package com.chapter10.tankeGame;


import java.util.Vector;

/**
 * 日期：2023/3/4
 * 需求/说明：自己的坦克
 */

public class Hero extends Tank {

    //创建Shot对象,表示一个子弹射击(线程)
    public Shot shot = null;
    //可以发射多颗子弹
    Vector<Shot> shots = new Vector<>();

    public Hero(int x, int y) {
        super(x, y);
    }

    //射击方法
    public void shotEnemyTank() {

        //控制面板上自己的坦克一次性最多只能发射5颗子弹 //集合中达到5颗时，下面不再创建添加，
        if (shots.size() == 5) { //只有等到子弹出界或击中销毁时，从集合中移除，集合中的子弹数量减少，才会继续创建添加
            return;
        }

        //创建Shot 此时子弹的位置和方向应该是和当前坦克Hero相关联的，因为是从坦克本身发出的子弹 --> 炮筒口
        switch (getDirect()) { //得到Hero对象的方向
            case 0 : //上
               shot = new Shot(getX() + 20, getY(), 0); //根据Hero对象的位置来创建子弹,即炮筒口的位置
               break;
            case 1 : //下
                shot = new Shot(getX() + 20, getY() + 60, 1);
                break;
            case 2 : //左
                shot = new Shot(getX(), getY() + 20, 2);
                break;
            case 3 : //右
                shot = new Shot(getX() + 60, getY() + 20, 3);
                break;
        }
        //把新创建的shot放到集合Vector中
        shots.add(shot);
        //启动Shot线程
        Thread thread = new Thread(shot);
        thread.start();
    }
}
