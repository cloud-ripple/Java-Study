package com.chapter10.tankeGame;

import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * 日期：2023/3/4
 * 需求/说明：坦克游戏窗口
 */

public class TankGame extends JFrame { //坦克游戏窗口
    MyPanel mp = null;
    public static void main(String[] args) {
        TankGame tankGame01 = new TankGame();
    }

    public TankGame() {
        mp = new MyPanel();

        this.add(mp); //把面板添加到窗口中
        Thread thread = new Thread(mp);
        thread.start();
        this.setSize(1300, 950);
        this.addKeyListener(mp);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        this.setVisible(true);

        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                Recorder.keepRecord();
                System.out.println("数据保存成功");
                System.exit(0);
            }
        });
    }
}
