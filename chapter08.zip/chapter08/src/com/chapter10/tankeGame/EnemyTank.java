package com.chapter10.tankeGame;

import java.util.Vector;

/**
 * 日期：2023/3/5
 * 需求/说明：敌人的坦克
 */

public class EnemyTank extends Tank implements Runnable {
    //在敌人坦克类，使用Vector保存多个Shot
    Vector<Shot> shots = new Vector<>();
    //增加成员，EnemyTank可以得到敌人坦克的Vector
    //分析
    //1.
    Vector<EnemyTank> enemyTanks = new Vector<>();
    public EnemyTank(int x, int y) {
        super(x, y);
    }

    //这里提供一个方法，可以将MyPanel类中的成员 Vector<EnemyTank> enemyTanks = new Vector<>();
    //设置到当前类EnemyTank的成员enemyTanks
    public void setEnemyTanks(Vector<EnemyTank> enemyTanks) {
        this.enemyTanks = enemyTanks;
    }

    //编写方法，判断当前的这个敌人坦克，是否和 enemyTanks中的其它坦克发射重叠或者碰撞
    public boolean isTouchEnemyTank() {
        //判断当前敌人坦克方向
        switch (getDirect()) {
            case 0: //上
                //让当前敌人坦克和其它所有的敌人坦克比较
                for (int i = 0; i < enemyTanks.size(); i++) {
                    //从Vector中取出一个敌人坦克
                    EnemyTank enemyTank = enemyTanks.get(i);
                    if (enemyTank != this) { //不和自己比较
                        //如果敌人坦克是 上下方向
                        //1. 如果敌人坦克是上下 x的范围 [enemyTank.getX(), enemyTank.getX() + 40]之间
                        //                   y的范围 [enemyTank.getY(), enemyTank.getY() + 60]之间
                        if (enemyTank.getDirect() == 0 || enemyTank.getDirect() == 1) {
                            //2. 当前坦克 左上角的坐标 [this.getX(), this.getY()]
                            if (this.getX() >= enemyTank.getX()
                                && this.getX() <= enemyTank.getX() + 40
                                && this.getY() >= enemyTank.getY()
                                && this.getY() <= enemyTank.getY() + 60) {
                                return true; //发生了碰撞
                            }
                            //3. 当前坦克 右上角的坐标 [this.getX() + 40, this.getY()]
                            if (this.getX() + 40 >= enemyTank.getX()
                                    && this.getX() + 40 <= enemyTank.getX() + 40
                                    && this.getY() >= enemyTank.getY()
                                    && this.getY() <= enemyTank.getY() + 60) {
                                return true; //发生了碰撞
                            }
                        }

                        //如果敌人坦克是 左右方向
                        //1. 如果敌人坦克是左右 x的范围 [enemyTank.getX(), enemyTank.getX() + 60]之间
                        //                   y的范围 [enemyTank.getY(), enemyTank.getY() + 40]之间
                        if (enemyTank.getDirect() == 2 || enemyTank.getDirect() == 3) {
                            //2. 当前坦克 左上角的坐标 [this.getX(), this.getY()]
                            if (this.getX() >= enemyTank.getX()
                                    && this.getX() <= enemyTank.getX() + 60
                                    && this.getY() >= enemyTank.getY()
                                    && this.getY() <= enemyTank.getY() + 40) {
                                return true; //发生了碰撞
                            }
                            //3. 当前坦克 右上角的坐标 [this.getX() + 40, this.getY()]
                            if (this.getX() + 40 >= enemyTank.getX()
                                    && this.getX() + 40 <= enemyTank.getX() + 60
                                    && this.getY() >= enemyTank.getY()
                                    && this.getY() <= enemyTank.getY() + 40) {
                                return true; //发生了碰撞
                            }
                        }
                    }
                }
                break;
            case 1: //下
                //让当前敌人坦克和其它所有的敌人坦克比较
                for (int i = 0; i < enemyTanks.size(); i++) {
                    //从Vector中取出一个敌人坦克
                    EnemyTank enemyTank = enemyTanks.get(i);
                    if (enemyTank != this) { //不和自己比较
                        //如果敌人坦克是 上下方向
                        //1. 如果敌人坦克是上下 x的范围 [enemyTank.getX(), enemyTank.getX() + 40]之间
                        //                   y的范围 [enemyTank.getY(), enemyTank.getY() + 60]之间
                        if (enemyTank.getDirect() == 0 || enemyTank.getDirect() == 1) {
                            //2. 当前坦克 右上角的坐标 [this.getX() + 60, this.getY()]
                            if (this.getX() + 60 >= enemyTank.getX()
                                    && this.getX() + 60 <= enemyTank.getX() + 40
                                    && this.getY() >= enemyTank.getY()
                                    && this.getY() <= enemyTank.getY() + 60) {
                                return true; //发生了碰撞
                            }
                            //3. 当前坦克 右下角的坐标 [this.getX() + 60, this.getY() + 40]
                            if (this.getX() + 60 >= enemyTank.getX()
                                    && this.getX() + 60 <= enemyTank.getX() + 40
                                    && this.getY() + 40 >= enemyTank.getY()
                                    && this.getY() + 40 <= enemyTank.getY() + 60) {
                                return true; //发生了碰撞
                            }
                        }

                        //如果敌人坦克是 左右方向
                        //1. 如果敌人坦克是左右 x的范围 [enemyTank.getX(), enemyTank.getX() + 60]之间
                        //                   y的范围 [enemyTank.getY(), enemyTank.getY() + 40]之间
                        if (enemyTank.getDirect() == 2 || enemyTank.getDirect() == 3) {
                            //2. 当前坦克 右上角的坐标 [this.getX() + 60, this.getY()]
                            if (this.getX() + 60 >= enemyTank.getX()
                                    && this.getX() + 60 <= enemyTank.getX() + 60
                                    && this.getY() >= enemyTank.getY()
                                    && this.getY() <= enemyTank.getY() + 40) {
                                return true; //发生了碰撞
                            }
                            //3. 当前坦克 右下角的坐标 [this.getX() + 60, this.getY() + 40]
                            if (this.getX() + 60 >= enemyTank.getX()
                                    && this.getX() + 60 <= enemyTank.getX() + 60
                                    && this.getY() + 40 >= enemyTank.getY()
                                    && this.getY() + 40 <= enemyTank.getY() + 40) {
                                return true; //发生了碰撞
                            }
                        }
                    }
                }
                break;
            case 2: //左
                //让当前敌人坦克和其它所有的敌人坦克比较
                for (int i = 0; i < enemyTanks.size(); i++) {
                    //从Vector中取出一个敌人坦克
                    EnemyTank enemyTank = enemyTanks.get(i);
                    if (enemyTank != this) { //不和自己比较
                        //如果敌人坦克是 上下方向
                        //1. 如果敌人坦克是上下 x的范围 [enemyTank.getX(), enemyTank.getX() + 40]之间
                        //                   y的范围 [enemyTank.getY(), enemyTank.getY() + 60]之间
                        if (enemyTank.getDirect() == 0 || enemyTank.getDirect() == 1) {
                            //2. 当前坦克 左下角的坐标 [this.getX(), this.getY() + 60]
                            if (this.getX() >= enemyTank.getX()
                                    && this.getX() <= enemyTank.getX() + 40
                                    && this.getY() + 60 >= enemyTank.getY()
                                    && this.getY() + 60 <= enemyTank.getY() + 60) {
                                return true; //发生了碰撞
                            }
                            //3. 当前坦克 右下角的坐标 [this.getX() + 40, this.getY() + 60]
                            if (this.getX() + 40 >= enemyTank.getX()
                                    && this.getX() + 40 <= enemyTank.getX() + 40
                                    && this.getY() + 60 >= enemyTank.getY()
                                    && this.getY() + 60 <= enemyTank.getY() + 60) {
                                return true; //发生了碰撞
                            }
                        }

                        //如果敌人坦克是 左右方向
                        //1. 如果敌人坦克是左右 x的范围 [enemyTank.getX(), enemyTank.getX() + 60]之间
                        //                   y的范围 [enemyTank.getY(), enemyTank.getY() + 40]之间
                        if (enemyTank.getDirect() == 2 || enemyTank.getDirect() == 3) {
                            //2. 当前坦克 左下角的坐标 [this.getX(), this.getY() + 60]
                            if (this.getX() + 60 >= enemyTank.getX()
                                    && this.getX() <= enemyTank.getX() + 60
                                    && this.getY() + 60 >= enemyTank.getY()
                                    && this.getY() + 60 <= enemyTank.getY() + 40) {
                                return true; //发生了碰撞
                            }
                            //3. 当前坦克 右下角的坐标 [this.getX() + 40, this.getY() + 60]
                            if (this.getX() + 40 >= enemyTank.getX()
                                    && this.getX() + 40 <= enemyTank.getX() + 60
                                    && this.getY() + 60 >= enemyTank.getY()
                                    && this.getY() + 60 <= enemyTank.getY() + 40) {
                                return true; //发生了碰撞
                            }
                        }
                    }
                }
                break;
            case 3: //右
                //让当前敌人坦克和其它所有的敌人坦克比较
                for (int i = 0; i < enemyTanks.size(); i++) {
                    //从Vector中取出一个敌人坦克
                    EnemyTank enemyTank = enemyTanks.get(i);
                    if (enemyTank != this) { //不和自己比较
                        //如果敌人坦克是 上下方向
                        //1. 如果敌人坦克是上下 x的范围 [enemyTank.getX(), enemyTank.getX() + 40]之间
                        //                   y的范围 [enemyTank.getY(), enemyTank.getY() + 60]之间
                        if (enemyTank.getDirect() == 0 || enemyTank.getDirect() == 1) {
                            //2. 当前坦克 左上角的坐标 [this.getX(), this.getY()]
                            if (this.getX() >= enemyTank.getX()
                                    && this.getX() <= enemyTank.getX() + 40
                                    && this.getY() >= enemyTank.getY()
                                    && this.getY() <= enemyTank.getY() + 60) {
                                return true; //发生了碰撞
                            }
                            //3. 当前坦克 左下角的坐标 [this.getX(), this.getY() + 40]
                            if (this.getX() >= enemyTank.getX()
                                    && this.getX() <= enemyTank.getX() + 40
                                    && this.getY() + 40 >= enemyTank.getY()
                                    && this.getY() + 40 <= enemyTank.getY() + 60) {
                                return true; //发生了碰撞
                            }
                        }

                        //如果敌人坦克是 左右方向
                        //1. 如果敌人坦克是左右 x的范围 [enemyTank.getX(), enemyTank.getX() + 60]之间
                        //                   y的范围 [enemyTank.getY(), enemyTank.getY() + 40]之间
                        if (enemyTank.getDirect() == 2 || enemyTank.getDirect() == 3) {
                            //2. 当前坦克 左上角的坐标 [this.getX(), this.getY()]
                            if (this.getX() + 60 >= enemyTank.getX()
                                    && this.getX() <= enemyTank.getX() + 60
                                    && this.getY() >= enemyTank.getY()
                                    && this.getY() <= enemyTank.getY() + 40) {
                                return true; //发生了碰撞
                            }
                            //3. 当前坦克 左下角的坐标 [this.getX(), this.getY() + 40]
                            if (this.getX() >= enemyTank.getX()
                                    && this.getX() <= enemyTank.getX() + 60
                                    && this.getY() + 40 >= enemyTank.getY()
                                    && this.getY() + 40 <= enemyTank.getY() + 40) {
                                return true; //发生了碰撞
                            }
                        }
                    }
                }
                break;
        }
        return false;

    }
    @Override
    public void run() {
        while (true) {
            //因为在画出每一个enemyTank的所有子弹时，一旦子弹出界就会销毁，从集合中移除
            //这里判断如果敌人坦克的子弹集合shots.size() == 0，就创建一颗子弹，放入到集合中，让敌方坦克持续移动发射
            if (isLive && shots.size() == 0) { //还要保证敌人坦克是否存活，如果是被击中爆了，也就没必要添加了
                Shot shot = null;
                //判断坦克的方向，创建对应的子弹
                switch (getDirect()) {
                    case 0: //向上
                        shot = new Shot(getX() + 20, getY(), 0);
                        break;
                    case 1: //下
                        shot = new Shot(getX() + 20, getY() + 60, 1);
                        break;
                    case 2: //左
                        shot = new Shot(getX(), getY() + 20, 2);
                        break;
                    case 3: //右
                        shot = new Shot(getX() + 60, getY() + 20, 3);
                        break;
                }
                shots.add(shot);
                new Thread(shot).start();
            }

            //根据方向来改变坦克横纵坐标
            switch(getDirect()) {
                case 0 : //向上
                    for (int i = 0; i < 50; i++) { //让坦克保持一个方向走 30步
                        //控制敌人坦克的移动范围
                        if (getY() > 0 && !isTouchEnemyTank()) {
                            //向上移动时，没有碰到边界(x:1000, y:750), 并且没有与其它坦克发生碰撞，才移动
                            moveUp();
                        }
                        try { //移动过程中休眠一下，否则一闪而过，看不到坦克移动的过程
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                    break;
                case 1 : //向下
                    for (int i = 0; i < 50; i++) {
                        if (getY() + 60 < 750 && !isTouchEnemyTank()) { //注意坦克自身的长度
                            moveDown();
                        }
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                    break;
                case 2 : //向左
                    for (int i = 0; i < 50; i++) {
                        if (getX() > 0 && !isTouchEnemyTank()) {
                            moveLeft();
                        }
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                    break;
                case 3 : //向右
                    for (int i = 0; i < 50; i++) {
                        if (getX() + 60 < 1000 && !isTouchEnemyTank()) { //注意坦克自身的长度
                            moveRight();
                        }
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                    break;
            }
            //随机改变坦克方向 0,1,2,3
            setDirect((int) (Math.random() * 4)); // [0, 4) 左闭右开
            System.out.println("当前坦克方向 = " + getDirect());
            //写并发程序，一定要考虑清楚，该线程什么时候退出
            if (!isLive) { //当isLive为false,取反为true，退出循环，也就退出run方法
                break;
            }

        }
    }
}
