package com.chapter10.tankeGame;

/**
 * 日期：2023/3/4
 * 需求/说明：
 */

public class Tank {
    private int x; //坦克的横坐标
    private int y; //坦克的纵坐标
    private int direct; //坦克的方向 默认向上
    private int speed = 1; //坦克的速度 初始化1
    boolean isLive = true; //默认存活


    //坦克上下左右移动方法
    public void moveUp() {
        //y -= 5;  //移动5个偏移量
        y -= speed;
    }

    public void moveDown() {
        y += speed;
    }

    public void moveLeft() {
        x -= speed;
    }

    public void moveRight() {
        x += speed;
    }

    public Tank(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getDirect() {
        return direct;
    }

    public void setDirect(int direct) {
        this.direct = direct;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }
}
