package com.chapter10.homework;

/**
 * 日期：2023/2/3
 * 需求/说明：
 */

public class Homework04 {
    public static void main(String[] args) {
        Cellphone cellphone = new Cellphone();
        cellphone.testWork(new ICal() {
            @Override
            public void work(double n1, double n2) {
                System.out.println(n1 + n2);
            }
        }, 100, 200);
    }
}
interface ICal {
    public abstract void work(double n1, double n2);
}

class Cellphone {
    public void testWork(ICal iCal, double n1, double n2) {
        iCal.work(n1, n2);
    }
}