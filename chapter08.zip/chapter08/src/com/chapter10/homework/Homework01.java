package com.chapter10.homework;

/**
 * 日期：2023/2/3
 * 需求/说明：
 */

public class Homework01 {
    public static void main(String[] args) {
        Car c = new Car();
        Car c1 = new Car(100);
        System.out.println(c); //输出 9.0  red
        System.out.println(c1); //输出 100.0  red
    }
}
class Car {
    double price = 10;
    static String color = "white";

    @Override
    public String toString() {
        return price + "\t" + color;
    }
    public Car() {
        this.price = 9;
        this.color = "red";
    }
    public Car(double price) {
        this.price = price;
    }
}