package com.chapter10.homework;

/**
 * 日期：2023/2/3
 * 需求/说明：
 */

public class Homework06 {
    public static void main(String[] args) {
        Person person = new Person("唐僧", CarUtils.getHorse());
        person.passRiver();
        person.common();
        person.fly();
    }
}
interface IVehicles {
    void work();
}

class Horse implements IVehicles {
    @Override
    public void work() {
        System.out.println("使用Horse作为工具");
    }
}

class Boat implements IVehicles {
    @Override
    public void work() {
        System.out.println("使用Boat作为工具");
    }
}
class FlyBird implements IVehicles {
    @Override
    public void work() {
        System.out.println("使用飞机");
    }
}

class CarUtils {
    public static Horse getHorse() {
        return new Horse();
    }
    public static Boat getBoat() {
        return new Boat();
    }
    public static FlyBird getFlyBird() {
        return new FlyBird();
    }
}

class Person {
    String name;
    IVehicles vehicles;

    public Person(String name, IVehicles vehicles) {
        this.name = name;
        this.vehicles = vehicles;
    }

    public void passRiver() {
        if (!(vehicles instanceof Boat)) {
            vehicles = CarUtils.getBoat();
        }
        vehicles.work();
    }

    public void common() {
        if (!(vehicles instanceof Horse)) {
            vehicles = CarUtils.getHorse();
        }
        vehicles.work();
    }

    public void fly() {
        if (!(vehicles instanceof FlyBird)) {
            vehicles = CarUtils.getFlyBird();
        }
        vehicles.work();
    }
}