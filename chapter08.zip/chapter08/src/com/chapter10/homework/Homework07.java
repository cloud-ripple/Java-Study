package com.chapter10.homework;

/**
 * 日期：2023/2/3
 * 需求/说明：
 */

public class Homework07 {
    public static void main(String[] args) {
        Cars car = new Cars(-39.2);
        car.work();
    }
}
class Cars {
    private double temperature;

    public Cars(double temperature) {
        this.temperature = temperature;
    }
    class Air {
        public void flow() {
            if (temperature > 40) {
                System.out.println("空调正在吹冷气..");
            } else if (temperature < 0) {
                System.out.println("空调正在吹暖气..");
            } else {
                System.out.println("空调已关闭..");
            }
        }
    }
    public void work() {
        Air air = new Air();
        air.flow();
    }
}
