package com.chapter10.homework;

/**
 * 日期：2023/2/3
 * 需求/说明：
 */

public class Homework05 {
    public static void main(String[] args) {
        new A().f1();
    }
}

class A {
    private String name = "啵啵";

    public void f1() {
        class B {
            private final static String name = "bobo";

            public void show() {
                System.out.println(name + A.this.name);
            }
        }
        B b = new B();
        b.show();
    }
}
