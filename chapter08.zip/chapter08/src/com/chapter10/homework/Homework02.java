package com.chapter10.homework;

/**
 * 日期：2023/2/3
 * 需求/说明：
 */

public class Homework02 {
    public static void main(String[] args) {
        System.out.println(Frock.getNextNum());
        System.out.println(Frock.getNextNum());

        Frock frock1 = new Frock();
        System.out.println(frock1.getSerialNumber());
        Frock frock2 = new Frock();
        System.out.println(frock2.getSerialNumber());
        Frock frock3 = new Frock();
        System.out.println(frock3.getSerialNumber());
    }
}
class Frock {
    private static int currentNum = 100000;
    private static int serialNumber; //序列号

    public static int getNextNum() {
        currentNum += 100;
        return currentNum;
    }

    public static int getSerialNumber() {
        return serialNumber;
    }

    public Frock() {
        serialNumber = getNextNum();
    }
}
