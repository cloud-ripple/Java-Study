package com.chapter10.reflection;

import java.lang.reflect.Field;

/**
 * 日期：2023/3/28
 * 需求/说明：通过反射访问类中的属性
 */

public class ReflectionAccessProperty {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchFieldException {
        //1.得到Student类对应的 Class对象
        Class<?> stuClass = Class.forName("com.chapter10.reflection.Student");
        //2.创建对象实例, 向上转型
        Object obj = stuClass.newInstance(); //obj 的运行类型就是Student 等价于 Student student = (Student) stuClass.newInstance();
        System.out.println(obj.getClass()); //class com.chapter10.reflection.Student

        //3.使用反射得到 age属性对象  getField方法只能获取public修饰的成员
        Field age = stuClass.getField("age");  //得到 age属性对应的Field对象
        age.set(obj, 99); //通过反射操作属性  set(Object obj, Object value)方法 第一个参数是对应类的Class对象创建的实例
        System.out.println(obj.toString()); //输出对象信息
        System.out.println(age.get(obj)); //直接返回该对象对应的属性  输出 99

        //4.使用反射操作name 私有属性(需要使用爆破)   Class类中 带有Declared的方法可以获取到用private修饰的私有成员，即所有成员都可以获取
        Field name = stuClass.getDeclaredField("name"); //得到 name属性对应的Field对象
        name.setAccessible(true); //注意操作私有成员时，一定要先修改访问权限(即爆破)，否则会报错
        name.set(obj, "bobo"); //对于静态成员，这里的obj实例对象也可以用 null替换，因为静态成员和类相关，和对象没关系
        System.out.println(name.get(obj)); //输出 bobo
        name.set(null, "啵啵"); //和上面等价(使用null 前提name是静态成员)
        System.out.println(name.get(null)); //(使用null 前提name是静态成员) 输出 啵啵
        System.out.println(name.get(obj)); //输出 啵啵


    }
}
class Student {
    public int age;
    private static String name; //私有的 静态成员
    public Student() {

    }

    @Override
    public String toString() {
        return "Student{" +
                "age=" + age +
                '}';
    }
}