package com.chapter10.reflection;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Properties;

/**
 * 日期：2023/3/23
 * 需求/说明：反射问题的引入
 */

public class ReflectionQuestion {
    public static void main(String[] args) throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException, NoSuchFieldException {
        //根据配置文件 re.properties 指定信息，创建对象并调用方法

        //1.传统方式 new 对象
        Cat cat = new Cat();
        cat.hi();

        //2.通过读取配置文件 Properties类，可以读写配置文件
        Properties properties = new Properties();
        properties.load(new FileInputStream("src\\re.properties"));
        String classpath = properties.get("classpath").toString();
        String methodName = properties.get("method").toString(); //指定的key=value

        System.out.println(classpath); //根据key读取的类
        //创建对象，传统方法行不通
        //new classpath;

        //3.使用反射机制解决
        //(1) 加载类，返回Class类型的对象
        Class<?> aClass = Class.forName(classpath); //Class对象表示某个类加载后在堆中的对象
        //(2) 通过aClass 得到你加载的类 Cat的对象实例
        Object obj = aClass.newInstance(); //等价于 ---> Cat cat = (Cat) aClass.newInstance();
        System.out.println(obj.getClass().getSimpleName()); //运行类型 Cat
        //(3)通过Class类的getMethod方法，得到你加载的类 Cat的 method=hi 的方法对象
        //在反射中可以把方法视为对象

        Method hi = aClass.getMethod(methodName); //指定的key=value,即得到key为 method对应的 hi 方法对象
        //Method hi = aClass.getMethod("hi");
        //(4) 通过method对象来调用Cat类的 hi方法
        /** 传统方法 对象名.方法 ，反射机制  方法对象名.invoke(加载类的对象实例) */
        hi.invoke(obj);
        //(5) 假如要调用Cat类的 cry()方法，只需修改配置文件中 method=cry 的key=value即可

        Method[] methods = aClass.getMethods(); //得到加载类的所有方法的对象
        methods[0].invoke(obj);
        methods[1].invoke(obj);

        //getField方法，不能得到私有的属性
        Field name = aClass.getField("name"); //得到加载类的成员变量对象
        System.out.println(name.get(obj)); //得到 对应Cat类的name属性
        //传统写法 对象名.成员变量   ，反射： 成员变量对象.get(加载类的对象实例)

        //getConstructor方法， ()中可以指定构造器参数类型，
        Constructor<?> constructor = aClass.getConstructor(); //返回的是无参构造器
        System.out.println(constructor); //输出无参构造方法 public Cat()
        //这里传入的 String.class就是String类的Class对象
        Constructor<?> constructor2 = aClass.getConstructor(String.class);
        System.out.println(constructor2); //输出有参构造方法 public Cat(java.lang.String)

    }
}
