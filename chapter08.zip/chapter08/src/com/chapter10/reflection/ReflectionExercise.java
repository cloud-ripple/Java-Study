package com.chapter10.reflection;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * 日期：2023/3/28
 * 需求/说明：反射练习-通过反射修改私有成员变量
 * 1.定义PrivateTest类，有私有name属性，并且属性值为 hello-kitty
 * 2.提供getName的共有方法
 * 3.创建PrivateTest类，利用Class类得到私有的name属性，修改属性值
 * 并调用getName()的方法打印
 */

public class ReflectionExercise {
    public static void main(String[] args) throws Exception {
        //1.先得到对应的Class类对象
        Class<?> cls = Class.forName("com.chapter10.reflection.PrivateTest");
        //2.通过Class对象，创建其对应的实例
        PrivateTest privateTest = (PrivateTest) cls.newInstance(); //默认通过无参构造器
        //3.通过Class对象得到对应的属性对象
        Field name = cls.getDeclaredField("name"); //得到PrivateTest类中的name属性

        name.setAccessible(true); //因为name属性是私有的，需要修改访问权限(爆破)，否则下面代码会报错

        //4.修改属性
        name.set(privateTest, "hello-bobo");
        //5.调用PrivateTest类中的 getName()方法
        //5.1 先通过反射得到 方法对象Method
        Method getName = cls.getMethod("getName"); //得到PrivateTest类中的getName()方法
        //因为getName()方法，没有参数列表。所以对于getMethod(String name, Class<?>... parameterTypes)方法，
        // 第二个参数可以不用指明其Class类型的变量类型
        //5.2 通过invoke()方法调用
        //invoke(Object obj, Object... args)方法，第一个参数为实例对象，第二个参数为调用该方法时传入的实参
        Object returnValue = getName.invoke(privateTest);
        System.out.println("PrivateTest类中 name属性的值 = " + returnValue);
    }
}

class PrivateTest {
    private String name = "hello-kitty"; //私有属性

    public String getName() {
        return name;
    }
}