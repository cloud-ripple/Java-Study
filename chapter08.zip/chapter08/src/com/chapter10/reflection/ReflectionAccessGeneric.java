package com.chapter10.reflection;

import java.lang.reflect.Method;
import java.util.ArrayList;

/**
 * 日期：2023/3/29
 * 需求/说明：反射方法的其它使用之-通过反射越过泛型检查
 * 泛型用在编译期，编译过后泛型擦除（消失掉）。所以是可以通过反射越过泛型检查的
 */

public class ReflectionAccessGeneric {
    public static void main(String[] args) throws Exception {
        /** 例如：有一个String泛型的集合，怎样能向这个集合中添加一个其它类型的值？*/
        //创建一个集合，泛型为String，并添加数据
        ArrayList<String> strList = new ArrayList<>();
        strList.add("jack");
        strList.add("tom");

        //1.获取strList的Class类对象
        Class<? extends ArrayList> strListClass = strList.getClass();
        //2.通过反射获取该类的add()方法
        Method add = strListClass.getMethod("add", Object.class);
        //3.通过反射调用add方法，可以向ArrayList<String> 集合中添加非String类型的数据
        add.invoke(strList, 678); //添加整型
        add.invoke(strList, '男'); //字符型

        //4.遍历集合输出
        for (Object o : strList) {
            System.out.println(o); //输出 jack tom 678 男
        }
    }
}
