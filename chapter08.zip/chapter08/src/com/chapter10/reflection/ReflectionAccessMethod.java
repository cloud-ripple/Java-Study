package com.chapter10.reflection;

import java.lang.reflect.Method;

/**
 * 日期：2023/3/28
 * 需求/说明：通过反射访问调用类中的方法
 */

public class ReflectionAccessMethod {
    public static void main(String[] args) throws Exception {
        //1.得到Boss类对应的 Class对象
        Class<?> bossClass = Class.forName("com.chapter10.reflection.Boss");
        //2.创建Boss的实例对象
        Object obj = bossClass.newInstance(); //等价于 Boss boss = (Boss) bossClass.newInstance();
        //3.调用public修饰的hi方法  invoke(Object obj, Object... args)方法
        Method hi = bossClass.getMethod("hi", String.class); //getMethod只能获取public修饰的方法
        //Method hi = bossClass.getDeclaredMethod("hi"); //这两种写法都可以 后者Declared可以获取到所有的方法，包括私有的

        hi.invoke(obj,  "bobo hello"); //第二个参数为调用该方法时传入的实参
        /* 对于getMethod(String name, Class<?>... parameterTypes)方法，第二个参数为Class类型的可变参数
        如果调用的方法需要传入实参列表，则必须指明 变量类型，如Boss类中的hi()方法，调用时需要传入String类型的参数
        所以通过反射得到对应的方法Method对象时，也要指定其Class参数类型 String.class可以得到String类的Class对象
            public void hi(String s) { //普通方法
                System.out.println("hi: " + s);
            }
        */

        //调用私有方法 invoke
        //先得到Method对应的方法对象
        Method say = bossClass.getDeclaredMethod("say", int.class, String.class, char.class);
        say.setAccessible(true); //因为say()方法是私有的，需要爆破，修改访问权限
        Object returnValue = say.invoke(obj, 66, "你好啊", 'Q'); //如果调用的是静态方法，这里的obj可以用null替换
        Object returnValue2 = say.invoke(null, 66, "你好啊", '男'); //还可以这样调用，如果不是静态的会报错
        System.out.println(returnValue); //returnValue的运行类型由方法返回类型决定
    }
}
class Boss {
    public int age;
    private static String name; //私有静态属性

    public Boss() {

    }

    private static String say(int n, String s, char c) { //私有静态方法
        return n + " " + s + " " + c;
    }

    public void hi(String s) { //普通方法
        System.out.println("hi: " + s);
    }
}
