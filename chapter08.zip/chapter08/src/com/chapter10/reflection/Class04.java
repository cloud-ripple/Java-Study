package com.chapter10.reflection;

/**
 * 日期：2023/3/28
 * 需求/说明：类加载5个阶段-链接阶段准备
 */

public class Class04 {
    public static void main(String[] args) {
        /** 初始化阶段-解析 */
        //new B();  //类加载  new对象时构造器会被执行
        //System.out.println(B.num); //100  直接使用静态成员时类也会被加载，但不会调用构造器
        //1. 加载B类，并生成B的 class对象
        //2. 链接 num = 0;
        //3. 初始化阶段
        /* 依次自动收集类中的所有静态变量的赋值动作和静态代码块中的语句，并合并
            clinit() {
                System.out.println("B 静态代码块被执行");
                //num = 300;
                num = 100;
            }
            合并：num = 100;
        */
        //Debug一下看看加载类的时候，是否有同步机制
        /* 底层源码：
            protected Class<?> loadClass(String name, boolean resolve)
            throws ClassNotFoundException
            {
            //正因为有这个线程同步机制，才能保证某个类在内存中，只有一份Class对象，因为类只加载一次
                synchronized (getClassLoadingLock(name)) {
                    // First, check if the class has already been loaded
                    ......
                    }
            }
         */
        B b = new B();
    }
}
class A {
    /** 链接阶段-准备 */
    //1. n1是实例属性，不是静态变量，因此在准备阶段，是不会分配内存
    //2. n2是静态变量，分配内存 n2是默认初始化0，而不是20
    //3. n3是static final 是常量，它和静态变量不一样，因为一旦赋值就不变 n3 = 30
    public int n1 = 10;
    public static int n2 = 20;
    public static final int n3 = 30;
}


class B {
    static {
        System.out.println("B 静态代码块被执行");
        num = 300;
    }

    static int num = 100;
//    public B() {
//        System.out.println("B 构造器被执行");
//    }
}