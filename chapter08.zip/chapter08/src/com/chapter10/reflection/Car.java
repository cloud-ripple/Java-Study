package com.chapter10.reflection;

/**
 * 日期：2023/3/26
 * 需求/说明：
 */

public class Car {
    public String brand = "bo";
    public int price = 90000;
    public String color = "blue";

    @Override
    public String toString() {
        return "Car{" +
                "brand='" + brand + '\'' +
                ", price=" + price +
                ", color='" + color + '\'' +
                '}';
    }
}
