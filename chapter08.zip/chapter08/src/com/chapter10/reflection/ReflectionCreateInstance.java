package com.chapter10.reflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * 日期：2023/3/28
 * 需求/说明：通过反射创建实例
 */

public class ReflectionCreateInstance {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        //1.先获取到User类的Class对象
        Class<?> userClass = Class.forName("com.chapter10.reflection.User");

        //2.通过public无参构造器创建实例
        User user = (User) userClass.newInstance(); //Object --> User向下转型
        System.out.println(user.toString());

        //3.通过public有参构造器创建实例
        //3.1 先得到对应构造器
        Constructor<?> constructor = userClass.getConstructor(String.class);
        //3.2 创建实例，并传入实参
        //Object bobo = constructor.newInstance("bobo"); //Object --> User向下转型
        User user2 = (User) constructor.newInstance("bobo"); //给构造器传入一个参数，并创建实例对象
        System.out.println(user2.toString());
        /* constructor对象就代表：
            public User(String name) { //public修饰的有参构造器
                this.name = name;
            }
        */

        //4.通过非public有参构造器创建实例
        //4.1 得到私有的private构造器对象
        Constructor<?> constructor2 = userClass.getDeclaredConstructor(int.class, String.class);
        //4.2 创建实例，并传入可变参数实参
        /** 4.3 爆破 ，使用反射可以访问私有的private修饰的 构造器、方法、属性 --> 暴力破解 */
        constructor2.setAccessible(true); /** 如果没有这句话，下面的私有构造器创建实例会报错，非法访问异常 */
        Object user3 = constructor2.newInstance(22, "jack");
        System.out.println(user3);
        /* 这里的 constructor2对象 其实就是：
            private User(int age, String name) { //私有的
                this.age = age;
                this.name = name;
            }
        */
    }
}
class User {
    private int age = 10;
    private String name = "hua";

    public User() {

    }
    public User(String name) { //public修饰的有参构造器
        this.name = name;
    }

    private User(int age, String name) { //私有的
        this.age = age;
        this.name = name;
    }

    @Override
    public String toString() {
        return "User{" +
                "age=" + age +
                ", name='" + name + '\'' +
                '}';
    }
}