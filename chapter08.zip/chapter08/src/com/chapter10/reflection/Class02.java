package com.chapter10.reflection;

/**
 * 日期：2023/3/27
 * 需求/说明：获取Class类对象的6种方式
 */

public class Class02 {
    public static void main(String[] args) throws ClassNotFoundException {
        //1. Class.forName()
        Class<?> cls1 = Class.forName("com.chapter10.reflection.Car");

        //2. 类名.class ,应用场景:用于参数传递
        Class cls2 = Car.class;

        //3. 对象.getClass(), 应用场景：有对象实例
        Car car = new Car();
        Class<? extends Car> cls3 = car.getClass();
        System.out.println(cls3);

        //4. 通过类加载器【4种】来获取到类的Class对象
        //(1)先得到类加载器 car
        ClassLoader classLoader = car.getClass().getClassLoader();
        //(2)通过类加载器得到Class对象
        Class<?> cls4 = classLoader.loadClass("com.chapter10.reflection.Car");
        System.out.println(cls4);

        /** cls1 cls2 cls3 cls4 其实是同一个对象，他么的hashcode值相同  */
        System.out.println(cls1.hashCode());
        System.out.println(cls2.hashCode());
        System.out.println(cls3.hashCode());
        System.out.println(cls4.hashCode());

        //5. 基本数据类型基本数据类型(int,char.......)按照如下方式得到Class类对象：
        //Class cls5 = 基本数据类型.class
        Class<Integer> integerClass = int.class;
        Class<Boolean> booleanClass = boolean.class;
        System.out.println(integerClass); //int

        //6. 基本数据类型对应的包装类，可以通过 .TYPE得到Class类对象
        //Class cls6 = 包装类.TYPE
        Class<Integer> type = Integer.TYPE;
        System.out.println(type);

        //二者hashcode值相同
        System.out.println(integerClass.hashCode());
        System.out.println(type.hashCode());
    }
}
