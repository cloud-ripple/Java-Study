package com.chapter10.reflection;

import org.junit.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * 日期：2023/3/28
 * 需求/说明：通过反射获取类的节后信息-Class类常用方法
 */

public class ReflectionUtils {
    public static void main(String[] args) {

    }
    //第一组方法API
    @Test
    public void api01() throws ClassNotFoundException {
        //得到Person类的Class对象
        Class<?> personCls = Class.forName("com.chapter10.reflection.Person");
        //(1) getName:获取全类名
        System.out.println(personCls.getName()); //输出 com.chapter10.reflection.Person
        //(2) getSimpleName:获取简单类名
        System.out.println(personCls.getSimpleName()); //输出 Person

        //(3) getFields:获取所有public修饰的属性，包含本类以及父类的
        Field[] fields = personCls.getFields();
        for (Field field : fields) { //遍历输出属性名
            System.out.println("本类或父类的public属性：" + field.getName()); //输出 name hobby
        }

        //(4) getDeclaredFields:获取本类中所有属性 包括私有的
        Field[] declaredFields = personCls.getDeclaredFields();
        for (Field declaredField : declaredFields) {
            System.out.println("本类中所有属性：" + declaredField.getName()); //name age job salary
        }


        //(5) getMethods:获取所有public修饰的方法，包含本类以及父类的
        Method[] methods = personCls.getMethods();
        for (Method method : methods) {
            System.out.println("本类以及父类的public方法" + method.getName()); //包括Object类的public方法
        }
        //(6) getDeclaredMethods:获取本类中所有方法

        //(7) getConstructors:获取所有public修饰的构造器，包含本类以及父类的
        Constructor<?>[] constructors = personCls.getConstructors();
        for (Constructor<?> constructor : constructors) {
            System.out.println("public修饰的构造器，包含本类以及父类的:" + constructor.getName());
        }

        //(8) getDeclaredConstructors:获取本类中所有构造器
        //(9) getPackage:以Package形式返回包信息
        //(10) getSuperClass: 以Class形式返回父类信息
        //(11) getInterfaces: 以Class[]形式返回接口信息
        //(12) getAnnotations: 以Annotation[]形式返回注解信息
        //(13) getModifiers: 以int形式返回修饰符
        //说明：默认修饰符 是0，public是1，private是2，protected是4，static是8，final是16
        //(17) getType:返回类型
        //(14) getReturnType:以Class形式获取返回类型
        //(15) getName:返回方法名、属性名...
        //(16) getParameterTypes:以Class[]形式返回参数类型数组
    }
}

class P {
    public String hobby;

}

class Person extends P {
    //属性
    public String name;
    protected int age;
    String job;
    private double salary;

    public Person(String name) {

    }
    Person(String name, int age) {

    }

    //方法
    public void m1() {

    }
    protected void m2() {

    }
    void m3() {

    }
    private void m4() {

    }
}