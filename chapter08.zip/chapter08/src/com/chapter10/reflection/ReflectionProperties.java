package com.chapter10.reflection;

import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Properties;

/**
 * 日期：2023/3/29
 * 需求/说明：反射与配置文件的妙用
 * 当我们升级这个系统时，不要该配置文件(key = value)中的Cat类，而需要新写一个其它的类时，
 * 这时只需要更改配置文件的内容就可以了。代码就一点不用改动
 * 只需修改value即可
 * classpath = com.chapter10.reflection.Cat
 * method = cry
 * method2 = hi
 */

public class ReflectionProperties {
    public static void main(String[] args) throws Exception {
        //得到配置文件中classpath的value，对应的Class对象
        Class<?> cls = Class.forName(getValue("classpath"));
        //创建实例对象
        Object obj = cls.newInstance(); //等价于 Cat cat = (Cat) cls.newInstance();
        //通过反射得到该类中的方法
        Method cry = cls.getMethod(getValue("method"));
        //通过反射类中的 invoke()方法来调用 Cat类中的 hi()方法
        cry.invoke(obj);

    }
    //根据配置文件的key得到对应的value
    public static String getValue(String key) throws IOException {
        //1.创建一个配置文件对象
        Properties properties = new Properties();
        //2.创建一个文件字符输入流
        FileReader fileReader = new FileReader("src\\reflection.txt");
        //3.把输入流加载到配置文件对象中
        properties.load(fileReader);
        fileReader.close(); //关闭流

        return properties.getProperty(key); //根据key返回对应的value
    }
}
