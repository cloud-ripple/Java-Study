package com.chapter10.reflection;

/**
 * 日期：2023/3/23
 * 需求/说明：
 */

public class Cat {
    public String name = "招财猫";

    public Cat() {
        this.name = name;
    }
    public Cat(String name) {
        this.name = name;
    }
    public void hi() {
        System.out.println("hi " + name);
    }
    public void cry() {
        System.out.println("cry 喵喵叫");
    }
}
