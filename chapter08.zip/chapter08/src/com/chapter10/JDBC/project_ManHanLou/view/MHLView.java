package com.chapter10.JDBC.project_ManHanLou.view;

import com.chapter10.JDBC.project_ManHanLou.domain.*;
import com.chapter10.JDBC.project_ManHanLou.service.BillService;
import com.chapter10.JDBC.project_ManHanLou.service.DiningTableService;
import com.chapter10.JDBC.project_ManHanLou.service.EmployeeService;
import com.chapter10.JDBC.project_ManHanLou.service.MenuService;
import com.chapter10.JDBC.project_ManHanLou.utils.Utility;

import java.util.List;

/**
 * @author BoBoKing
 * @date 2023/5/3
 * @description 满汉楼主界面
 */

public class MHLView {
    public static void main(String[] args) {
        mainMenu();
    }

    /**
     * 控制是否退出
     */
    private static boolean loop = true;

    /**
     * 显示主菜单
     */
    public static void mainMenu() {
        while (loop) {
            System.out.println("============满汉楼===========");
            System.out.println("\t\t 1 登录满汉楼");
            System.out.println("\t\t 2 退出满汉楼");
            System.out.print("请输入你的选择：");
            //接收用户选择
            String key = Utility.readString(1);
            switch (key) {
                case "1":
                    //System.out.println("登录满汉楼");
                    System.out.print("输入员工号：");
                    String empId = Utility.readString(50);
                    System.out.print("输入密码：");
                    String pwd = Utility.readString(50);
                    //接收用户输入的数据后，到数据库去判断
                    Employee employee = EmployeeService.check(empId, pwd);
                    if (employee != null) {
                        System.out.println("---------登录成功，欢迎用户[" + employee.getName() + "]-----------");
                        //显示二级菜单,使用循环
                        while (loop) {
                            System.out.println("=================满汉楼二级菜单==============");
                            System.out.println("\t\t 1 显示餐桌状态");
                            System.out.println("\t\t 2 预定餐桌");
                            System.out.println("\t\t 3 显示所有菜品");
                            System.out.println("\t\t 4 点餐服务");
                            System.out.println("\t\t 5 查看账单");
                            System.out.println("\t\t 6 结账");
                            System.out.println("\t\t 7 退出满汉楼");
                            System.out.print("请输入你的选择：");
                            key = Utility.readString(1);
                            switch (key) {
                                case "1":
                                    showDiningTables(); //封装到一个方法里
                                    break;
                                case "2":
//                                    System.out.print("请选择餐桌编号id：");
//                                    int id = Utility.readInt();
//                                    System.out.print("\n请输入预定人姓名：");
//                                    String orderName = Utility.readString(30);
//                                    System.out.print("\n请输入预定人电话：");
//                                    String orderTel = Utility.readString(30);
//                                    if (DiningTableService.isCanBook(id, orderName, orderTel)) {
//                                        System.out.println("编号为 " + id + " 的餐桌预定成功！");
//                                    } else {
//                                        System.out.println("餐桌编号 " + id + " 不存在，预定失败！");
//                                    }
                                    //以上可以封装成一个方法
                                    orderDiningTable();
                                    break;
                                case "3":
                                    //System.out.println("显示所有菜品");
                                    List<Menu> list = MenuService.getAllMenu();
                                    System.out.println("-----------菜品信息如下-----------");
                                    System.out.println("菜品编号\t\t菜品名称\t\t菜品种类\t\t价格");
                                    for (Menu menu : list) {
                                        System.out.println(menu);
                                    }
                                    break;
                                case "4":
                                    //System.out.println("点餐服务");
                                    orderMenu();
                                    break;
                                case "5":
                                    //System.out.println("查看账单");
                                    //showBills();
                                    showBills2();
                                    break;
                                case "6":
                                    //System.out.println("结账");
                                    pay();
                                    break;
                                case "7":
                                    loop = false;
                                    break;
                            }
                        }
                    } else {
                        System.out.println("登录失败");
                    }
                    break;
                case "2":
                    loop = false;
                    break;
                default:
                    System.out.println("你输入有误，请重新选择！");
            }
        }

        System.out.println("你已退出满汉楼系统.");
    }

    /**
     * 显示餐桌
     */
    public static void showDiningTables() {
        System.out.println("------------------当前所有餐桌状态如下------------------");
        System.out.println("餐桌编号\t\t餐桌状态");
        //从业务类得到所有餐桌
        List<DiningTable> list = DiningTableService.getAllDiningTable();
        for (DiningTable diningTable : list) {
            System.out.println(diningTable); //输出的信息，由DiningTable类中的toString方法决定
        }
    }

    /**
     * 预定餐桌
     */
    public static void orderDiningTable() {
        System.out.print("请选择要预定的餐桌编号id, (-1 退出)：");
        int id = Utility.readInt();
        if (id == -1) {
            System.out.println("------你已取消餐桌预定------");
            return;
        }
        System.out.print("\n请输入预定人姓名：");
        String orderName = Utility.readString(30);
        System.out.print("\n请输入预定人电话：");
        String orderTel = Utility.readString(30);
        if (DiningTableService.isCanBook(id, orderName, orderTel)) {
            System.out.println("编号为 " + id + " 的餐桌预定成功！");
        } else {
            System.out.println("预定失败，编号为 " + id + " 的餐桌不存在或已被其他客户预定了！");
        }
    }

    /**
     * 点餐
     * 思路分析
     * 1.餐桌号，菜品编号需要校验
     * 2.下单成功，需要修改餐桌状态
     * 3.点餐之后，生成账单
     */
    public static void orderMenu() {
        System.out.println("----------点餐服务(-1取消)------------");
        System.out.print("请输入点餐的桌号：");
        int orderDiningTableId = Utility.readInt();
        if (orderDiningTableId == -1) {
            System.out.println("你已取消点餐");
            return;
        }

        System.out.print("请选择菜品编号：");
        int menuId = Utility.readInt();
        if (menuId == -1) {
            System.out.println("你已取消点餐");
            return;
        }
        System.out.print("请输入菜品份数：");
        int nums = Utility.readInt();
        if (nums == -1) {
            System.out.println("你已取消点餐");
            return;
        }
        //如果上面都没有输入 -1 ，继续下一步，
        // 1.验证餐桌号是否存在，根据输入的餐桌编号，先得到餐桌
        DiningTable diningTable2 = DiningTableService.getDiningTableById(orderDiningTableId);
        if (diningTable2 == null) {
            System.out.println("所选餐桌号不存在，无法点餐！");
            return;
        }
        // 2.验证菜品编号是否正确，根据输入的菜品编号，得到一个菜品
        Menu menu = MenuService.getMenuById(menuId);
        if (menu == null) {
            System.out.println("所点菜品不存在或已售光！");
            return;
        }
        // 3.如果上面都验证通过，即餐桌存在、菜品存在，就可以点餐下单了
        if (BillService.orderBill(menuId, nums, orderDiningTableId)) {
            System.out.println("---------点餐成功-----------");
        } else {
            System.out.println("---------点餐失败-----------");
        }
    }

    /**
     * 查看账单
     */
    public static void showBills() {
        //List<Bill> list = BillService.getAllBill();
        System.out.println("-----------当前账单信息如下---------------");
        System.out.println("id\t\t菜品编号\t\t菜品数量\t\t账单金额\t\t餐桌编号\t\t账单日期\t\t\t\t\t\t\t账单状态\t\t账单编号[UUID]");
        for (Bill bill : BillService.getAllBill()) {
            System.out.println(bill);
        }
    }

    /**
     * 查看账单 基于多表查询 bill表 和 menu表
     */
    public static void showBills2() {
        System.out.println("-----------当前账单信息如下---------------");
        System.out.println("id\t\t菜品编号\t\t菜品数量\t\t账单金额\t\t餐桌编号\t\t账单日期\t\t\t\t\t\t\t账单状态\t\t账单编号[UUID]\t\t\t\t菜品名");
        for (MultiTableBean multiTableBean : BillService.getAllBills()) {
            System.out.println(multiTableBean);
        }
    }

    /**
     * 结账
     */
    public static void pay() {
        System.out.print("请输入结账的餐桌编号(-1取消)：");
        int id = Utility.readInt();
        if (id == -1) {
            System.out.println("----------你已取消结账----------");
            return;
        }
        //验证餐桌是否存在
        DiningTable diningTable = DiningTableService.getDiningTableById(id);
        if (diningTable == null) {
            System.out.println("编号为 " + id + "的餐桌不存在！");
            return;
        }

        //验证该餐桌是否有需要支付的账单
        if (!BillService.hasPayBillByDiningTableId(id)) {
            System.out.println("编号为 " + id + "的餐桌没有未支付的账单！");
            return;
        }
        //以上验证通过，继续
        System.out.println("--------------------该餐桌待支付账单信息如下------------------");
        System.out.println("id\t\t菜品编号\t\t菜品数量\t\t账单金额\t\t餐桌编号\t\t账单日期\t\t\t\t\t\t\t账单状态\t\t账单编号[UUID]");
        double totalMoney = 0;
        for (Bill bill : BillService.getBills(id)) {
            totalMoney += bill.getMoney();
            System.out.println(bill);
        }
        System.out.println("---------------你一共消费了：" + totalMoney + " 元！----------------");
        System.out.print("请选择支付方式[现金|微信|支付宝|银行卡]：");
        String payWay = Utility.readString(20);
        if (BillService.payBill(payWay, id)) {
            System.out.println("结账成功，欢迎下次光临！");
        } else {
            System.out.println("结账失败！");
        }
    }
}
