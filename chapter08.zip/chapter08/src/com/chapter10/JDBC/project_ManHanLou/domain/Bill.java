package com.chapter10.JDBC.project_ManHanLou.domain;

import java.time.LocalDateTime;

/**
 * @author BoBoKing
 * @date 2023/5/4
 * @description 这是一个javabean，和满汉楼数据表bill对应，bill(账单)
 */

public class Bill {

    /**
     * id自增
     */
    private Integer id;

    /**
     * 账单编号
     */
    private String billId;

    /**
     * 菜品编号
     */
    private Integer menuId;

    /**
     * 账单数量 份数
     */
    private Integer nums;

    /**
     * 账单金额
     */
    private Double money;

    /**
     * 餐桌编号
     */
    private Integer diningTableId;

    /**
     * 账单日期
     */
    private LocalDateTime billDate;

    /**
     * 账单状态 未结账、已经结账、挂单、霸王餐
     */
    private String billState;

    public Bill() {
    }

    public Bill(Integer id, String billId, Integer menuId, Integer nums, Double money, Integer diningTableId, LocalDateTime billDate, String billState) {
        this.id = id;
        this.billId = billId;
        this.menuId = menuId;
        this.nums = nums;
        this.money = money;
        this.diningTableId = diningTableId;
        this.billDate = billDate;
        this.billState = billState;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBillId() {
        return billId;
    }

    public void setBillId(String billId) {
        this.billId = billId;
    }

    public Integer getMenuId() {
        return menuId;
    }

    public void setMenuId(Integer menuId) {
        this.menuId = menuId;
    }

    public Integer getNums() {
        return nums;
    }

    public void setNums(Integer nums) {
        this.nums = nums;
    }

    public Double getMoney() {
        return money;
    }

    public void setMoney(Double money) {
        this.money = money;
    }

    public Integer getDiningTableId() {
        return diningTableId;
    }

    public void setDiningTableId(Integer diningTableId) {
        this.diningTableId = diningTableId;
    }

    public LocalDateTime getBillDate() {
        return billDate;
    }

    public void setBillDate(LocalDateTime billDate) {
        this.billDate = billDate;
    }

    public String getBillState() {
        return billState;
    }

    public void setBillState(String billState) {
        this.billState = billState;
    }

    @Override
    public String toString() {
        return  id +
                "\t\t" + menuId +
                "\t\t\t" + nums +
                "\t\t\t" + money +
                "\t\t\t" + diningTableId +
                "\t\t\t" + billDate +
                "\t\t\t" + billState +
                "\t\t" + billId ;
    }
}
