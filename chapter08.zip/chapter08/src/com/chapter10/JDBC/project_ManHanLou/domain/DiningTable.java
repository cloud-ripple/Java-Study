package com.chapter10.JDBC.project_ManHanLou.domain;

/**
 * @author BoBoKing
 * @date 2023/5/4
 * @description 这是一个javabean，和满汉楼数据表diningTable对应
 */

public class DiningTable {

    /**
     * 餐桌编号，自增
     */
    private Integer id;

    /**
     * 餐桌状态
     */
    private String state;

    /**
     * 预定人名字
     */
    private String orderName;

    /**
     * 预定人电话
     */
    private String orderTel;

    /**
     * 需要提供无参构造器，底层apache-utils反射机制需要
     */
    public DiningTable() {
    }

    public DiningTable(Integer id, String state, String orderName, String orderTel) {
        this.id = id;
        this.state = state;
        this.orderName = orderName;
        this.orderTel = orderTel;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getOrderName() {
        return orderName;
    }

    public void setOrderName(String orderName) {
        this.orderName = orderName;
    }

    public String getOrderTel() {
        return orderTel;
    }

    public void setOrderTel(String orderTel) {
        this.orderTel = orderTel;
    }

    @Override
    public String toString() {
        return id + "\t\t\t" + state;
    }
}
