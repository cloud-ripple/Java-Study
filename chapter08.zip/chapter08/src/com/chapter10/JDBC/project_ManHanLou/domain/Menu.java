package com.chapter10.JDBC.project_ManHanLou.domain;

/**
 * @author BoBoKing
 * @date 2023/5/4
 * @description 这是一个javabean，和满汉楼数据表menu对应
 */

public class Menu {

    /**
     * 菜品编号，自增长
     */
    private Integer id;

    /**
     * 菜品名
     */
    private String foodName;

    /**
     * 菜品类型
     */
    private String foodType;

    /**
     * 菜品价格
     */
    private Double price;

    public Menu() {
    }

    public Menu(Integer id, String foodName, String foodType, Double price) {
        this.id = id;
        this.foodName = foodName;
        this.foodType = foodType;
        this.price = price;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public String getFoodType() {
        return foodType;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "\t" + id + "\t\t" + foodName + "\t\t" + foodType + "\t\t" + price;
    }
}
