package com.chapter10.JDBC.project_ManHanLou.domain;

/**
 * @author BoBoKing
 * @date 2023/5/4
 * @description 这是一个javabean，和满汉楼数据表employee对应
 */

public class Employee {
    /**
     * id 自增长
     */
    private Integer id;

    /**
     * 员工号
     */
    private String empId;

    /**
     * 密码 在创建表时，经过 MD5()函数加密，并不是明文
     */
    private String pwd;

    /**
     * 用户名
     */
    private String name;

    /**
     * 岗位
     */
    private String job;

    /**
     * 需要提供无参构造器，底层apache-utils反射机制需要
     */
    public Employee() {
    }

    public Employee(Integer id, String empId, String pwd, String name, String job) {
        this.id = id;
        this.empId = empId;
        this.pwd = pwd;
        this.name = name;
        this.job = job;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", empId='" + empId + '\'' +
                ", pwd='" + pwd + '\'' +
                ", name='" + name + '\'' +
                ", job='" + job + '\'' +
                '}';
    }
}
