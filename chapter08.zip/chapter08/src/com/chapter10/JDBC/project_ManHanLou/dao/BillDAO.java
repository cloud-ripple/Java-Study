package com.chapter10.JDBC.project_ManHanLou.dao;

import com.chapter10.JDBC.project_ManHanLou.domain.Bill;

/**
 * @author BoBoKing
 * @date 2023/5/4
 * @description
 */

public class BillDAO extends BasicDAO<Bill> {
}
