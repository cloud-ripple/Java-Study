package com.chapter10.JDBC.project_ManHanLou.dao;

import com.chapter10.JDBC.project_ManHanLou.domain.Employee;

/**
 * @author BoBoKing
 * @date 2023/5/4
 * @description DAO数据访问对象，继承后，拥有BasicDAO的方法
 */

public class EmployeeDAO extends BasicDAO<Employee> {
    //这里也可以定义自己的方法
}
