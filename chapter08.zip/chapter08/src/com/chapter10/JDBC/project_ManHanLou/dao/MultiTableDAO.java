package com.chapter10.JDBC.project_ManHanLou.dao;

import com.chapter10.JDBC.project_ManHanLou.domain.MultiTableBean;

/**
 * @author BoBoKing
 * @date 2023/5/9
 * @description DAO数据访问对象，继承后，拥有BasicDAO的方法
 */

public class MultiTableDAO extends BasicDAO<MultiTableBean> {

}
