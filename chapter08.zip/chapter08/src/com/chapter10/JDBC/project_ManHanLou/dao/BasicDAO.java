package com.chapter10.JDBC.project_ManHanLou.dao;

import com.chapter10.JDBC.project_ManHanLou.utils.JDBCDruidUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * @author BoBoKing
 * @date 2023/5/3
 * @description 其它DAO类的父类

DAO和增删改查通用方法
    * 分析问题
    * apache-dbutils + Druid简化了JDBC开发，但又不足
    * 1.SQL语句是固定的，不能通过参数传入，通用性不好，需要进行改进更方便执行
    * 2.对于select操作，如果有返回值，返回类型不能固定，需要使用泛型
    * 3.将来的表更多，业务需求更加复杂，不可能只靠一个Java类完成
    *
    * 引出DAO data access object 数据访问对象
    * BasicDAO通用类，是专门和数据库交互的，完成对数据库表的crud操作
    *
    * 一个数据中有多个表，actor, goods, order...
    * 每个表对应每个java类，两者之间存在映射关系
    * Actor类 【称为 javabean, domain, pojo】
    * Goods类
    * Order类
    *
    * ActorDAO完成对actor表的增删改查操作，也可以有特有操作
    * GoodsDAO完成对goods表的增删改查..
    * BasicDAO 让其它DAO类继承，将各个DAO共同的部分提取出来，简化代码。提高可读性和维护性，比如获取连接connection,释放资源..
    * TestDAO 测试DAO，如果想对哪个表操作，直接使用DAO类即可
    */

public class BasicDAO<T> {
    private QueryRunner qr = new QueryRunner();

    //开发通用的dml方法，针对任意的表
    public int update(String sql, Object... params) {
        Connection connection = null;
        try {
            connection = JDBCDruidUtils.getConnection();
            int rows = qr.update(connection, sql, params);
            //可变参数params可以给sql语句中的？参数占位符指定不同的值
            return rows; //返回受影响的行数
        } catch (SQLException e) {
            throw new RuntimeException(e);  //将编译异常转为运行异常抛出去
        } finally {
            JDBCDruidUtils.close(null, null, connection);
            //这里的resultSet, PreparedStatement在QueryRunner类的update方法中，底层会自动关闭，只需要传入connection连接关闭即可
        }
    }

    //返回多个对象(即查询的结果是多行)，针对任意表, Multiply返回多个
    /**
     *
     * @param sql 要执行的SQL语句
     * @param clazz 传入一个类的Class对象
     * @param params 可变形参，给sql语句中的？赋给具体的值
     * @return 根据传入的Class对象，返回相对应的 ArrayList集合
     */
    public List<T> queryMultiply(String sql, Class<T> clazz, Object... params) {
        Connection connection = null;
        try {
            connection = JDBCDruidUtils.getConnection();
            List<T> list = qr.query(connection, sql, new BeanListHandler<T>(clazz), params);
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            JDBCDruidUtils.close(null, null, connection);
            //这里的resultSet, PreparedStatement在QueryRunner类的update方法中，底层会自动关闭，只需要传入connection连接关闭即可
        }
    }

    //查询单行结果的通用方法,结果集中的每一行就代表一个类对象
    public T querySingle(String sql, Class<T> clazz, Object... params) {
        Connection connection = null;
        try {
            connection = JDBCDruidUtils.getConnection();
            T obj = qr.query(connection, sql, new BeanHandler<T>(clazz), params);
            return obj;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            JDBCDruidUtils.close(null, null, connection);
        }
    }

    //查询单行单列的通用方法，即表中单元格具体的一个值,应该是 Object对象
    public Object queryScalar(String sql, Object... params) {
        Connection connection = null;
        try {
            connection = JDBCDruidUtils.getConnection();
            Object obj = qr.query(connection, sql, new ScalarHandler(), params);
            return obj;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            JDBCDruidUtils.close(null, null, connection);
        }
    }
}
