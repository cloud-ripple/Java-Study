package com.chapter10.JDBC.project_ManHanLou.service;

import com.chapter10.JDBC.project_ManHanLou.dao.BillDAO;
import com.chapter10.JDBC.project_ManHanLou.dao.MultiTableDAO;
import com.chapter10.JDBC.project_ManHanLou.domain.Bill;
import com.chapter10.JDBC.project_ManHanLou.domain.MultiTableBean;

import java.util.List;
import java.util.UUID;

/**
 * @author BoBoKing
 * @date 2023/5/4
 * @description 该类通过BillDAO对象，完成对数据库中 bill账单表的业务操作
 */

public class BillService {

    private static BillDAO billDAO = new BillDAO();
    private static MultiTableDAO multiTableDAO = new MultiTableDAO();

    /**
     * 下单
     * 1.生成账单
     * 2.需要更新对应餐桌的状态
     * 3.如果成功返回true
     * @param menuId 菜品编号，对应具体的菜品
     * @param nums 菜品数量，即点了多少份菜品
     * @param diningTableId 餐桌编号
     * @return 返回true代表下单成功，此时账单生成、餐桌状态更新
     */
    /* 数据库中账单表 bill 如下：
        CREATE TABLE bill (
            id INT PRIMARY KEY AUTO_INCREMENT,
            billId VARCHAR(50) NOT NULL DEFAULT '' COMMENT '账单编号',
            menuId INT NOT NULL DEFAULT 0 COMMENT '菜品编号', -- 也可以使用外键
            nums INT NOT NULL DEFAULT 0 COMMENT '菜品数量',
            money DOUBLE NOT NULL DEFAULT 0 COMMENT '金额',
            diningTableId INT NOT NULL DEFAULT 0 COMMENT '餐桌编号',
            billDate DATETIME NOT NULL COMMENT '订单日期',
            -- 未结账、已经结账、挂单、霸王餐
            billState VARCHAR(50) NOT NULL DEFAULT '' COMMENT '订单状态') CHARSET utf8 COMMENT '账单表';
     */
    //点餐下单时，需要知道 菜品编号(即点那个菜)、账单份数(每个菜点几份)、餐桌编号(那一桌点的)
    public static boolean orderBill(int menuId, int nums, int diningTableId) {
        //调用类库API生成一个账单号，UUID对象
        String billId = UUID.randomUUID().toString(); //产生一个随机字符串

        //1.将账单生成到bill表 --> 把点餐的数据插入到表中，SQL语句中 now()函数，生成当前时间
        int rows = billDAO.update(
                "insert into bill values (null, ?, ?, ?, ?, ?, now(), '未结账')",
                billId, menuId, nums, MenuService.getMenuById(menuId).getPrice() * nums, diningTableId);
        //其中sql语句中的第4个？参数 对应 bill表 money -> 账单金额 = 菜品单价 * 数量，根据menuId从MenuService类业务层的方法中得到对应的菜品 Menu对象
        //然后得到其菜品价格
        //执行sql语句后，返回受影响的行数，如果行数大于0 ，代表数据插入成功(即账单生成，点餐成功),返回true，否则返回false
        if (rows <= 0) {
            return false;
        }

        //2.更新对应餐桌的状态
        return DiningTableService.updateDiningTableState(diningTableId, "就餐中");
    }

    /**
     * 加单，加菜
     */
    public static void addMenu(int menuId, int nums, int diningTableId) {
        billDAO.update(
                "update bill set money = money + ? where diningTableId = ?",
                MenuService.getMenuById(menuId).getPrice() * nums, diningTableId);
    }

    /**
     * 得到所有账单
     */
    public static List<Bill> getAllBill() {
        return billDAO.queryMultiply("select * from bill", Bill.class);
    }

    /**
     * 得到所有账单，多表的
     * 多表查询，sql语句可以返回 账单表中的所有字段信息 菜品表中的菜品名
     */
    public static List<MultiTableBean> getAllBills() {
        return multiTableDAO.queryMultiply("select bill.*, foodName from bill, menu where bill.menuId = menu.id", MultiTableBean.class);
    }

    /**
     * 根据餐桌编号得到其对应，且未支付的所有账单(包括加单的)
     */
    public static List<Bill> getBills(int diningTableId) {
        return billDAO.queryMultiply("select * from bill where diningTableId = ? and billState = '未结账' ", Bill.class, diningTableId);
    }

    /**
     * 根据餐桌编号判断是否有未支付的账单
     * 结账思路分析：
     * 1.对餐桌号进行校验，并判断该餐桌是否有未结账单
     * 2.修改bill表的state
     * 3.修改diningTable餐桌信息，包括餐桌状态、预定人、预定人电话
     * @param diningTableId 餐桌编号
     * @return 返回true代表该餐桌有未结账的账单
     */
    public static boolean hasPayBillByDiningTableId(int diningTableId) {
        //1.根据餐桌编号判断某个餐桌是否有未结账的账单
        return billDAO.querySingle(
                "select * from bill where diningTableId = ? and billState = '未结账' limit 0,1",
                Bill.class,
                diningTableId) != null; //如果查询到账单，不为空，返回true
    }

    /**
     * 修改未结账餐桌的账单状态
     * @param state 账单状态
     * @param diningTableId 餐桌编号
     * @return 返回值大于0,代表账单状态更新成功(sql语句执行成功，返回受影响的行数)
     */
    public static int updateBillState(String state, int diningTableId) {
        return billDAO.update("update bill set billState = ? where diningTableId = ? and billState = '未结账'", state, diningTableId);
    }

    /**
     * 结账
     * @param payWay 支付方式
     * @param diningTableId 餐桌编号
     * @return true代表结账成功
     */
    public static boolean payBill(String payWay, int diningTableId) {
        //2.修改未结账的账单状态
        if (updateBillState(payWay, diningTableId) <= 0) {
            return false; //如果更新受影响行数小于等于0.代表sql语句没有执行成功，结账失败
        }
        //3.修改diningTable餐桌信息，包括餐桌状态、预定人、预定人电话
        if (!DiningTableService.updateDiningTable(diningTableId)) {
            return false; //餐桌信息没有重置成功，返回
        }

        return true; //以上并未进入，结账成功
    }
}
