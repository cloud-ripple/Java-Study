package com.chapter10.JDBC.project_ManHanLou.service;

import com.chapter10.JDBC.project_ManHanLou.dao.EmployeeDAO;
import com.chapter10.JDBC.project_ManHanLou.domain.Employee;

/**
 * @author BoBoKing
 * @date 2023/5/4
 * @description 该类通过EmployeeDAO对象完成对表employee的业务操作
 */

public class EmployeeService {

    /**
     * EmployeeDAO完成对 employee表的各种操作
     */
    private static EmployeeDAO employeeDAO = new EmployeeDAO();

    /**
     * 登录验证
     * @param empId 员工号
     * @param pwd 密码
     * @return 根据用户输入的empId 和 pwd查询，并返回一行记录(即 Employee对象)
     */
    public static Employee check(String empId, String pwd) {
        String sql = "select * from employee where empId = ? and pwd = MD5(?)";
        Employee employee = employeeDAO.querySingle(sql, Employee.class, empId, pwd);

        return employee; //如果在数据库中查询到一条记录，employee不为空
    }
}
