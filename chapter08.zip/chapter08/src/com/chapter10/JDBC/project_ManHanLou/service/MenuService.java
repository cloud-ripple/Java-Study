package com.chapter10.JDBC.project_ManHanLou.service;

import com.chapter10.JDBC.project_ManHanLou.dao.MenuDAO;
import com.chapter10.JDBC.project_ManHanLou.domain.Menu;

import java.util.List;

/**
 * @author BoBoKing
 * @date 2023/5/4
 * @description 该类通过MenuDAO对象完成对表menu的业务操作
 */

public class MenuService {

    private static MenuDAO menuDAO = new MenuDAO();

    /**
     * 得到所有的菜品信息
     */
    public static List<Menu> getAllMenu() {
        return menuDAO.queryMultiply("select * from menu order by price desc", Menu.class);
    }

    /**
     * 得到单个菜品信息
     * 根据id返回Menu对象，即单行记录查询
     * @param id 菜品编号
     */
    public static Menu getMenuById(int id) {
        return menuDAO.querySingle("select * from menu where id = ?", Menu.class, id);
    }
}
