package com.chapter10.JDBC.project_ManHanLou.service;

import com.chapter10.JDBC.project_ManHanLou.dao.DiningTableDAO;
import com.chapter10.JDBC.project_ManHanLou.domain.DiningTable;

import java.util.List;

/**
 * @author BoBoKing
 * @date 2023/5/4
 * @description 该类通过DiningTableDAO对象，完成对数据库中 diningTable表的业务操作
 */

public class DiningTableService {

    private static DiningTableDAO diningTableDAO = new DiningTableDAO();

    /**
     * 得到多个餐桌
     * @return 返回一个list集合，集合中存放着 DiningTable类对象，每一个对象代表一行数据记录
     */
    public static List<DiningTable> getAllDiningTable() {
        //queryMultiply(String sql, Class<T> clazz, Object... params)方法，返回表中多行记录
        List<DiningTable> diningTables = diningTableDAO.queryMultiply("select id, state from diningTable", DiningTable.class);
        return diningTables;
    }

    /**
     * 得到一个餐桌
     * 根据id，查询对应的餐桌 DiningTable对象
     * 如果 DiningTable返回null，表示id编号对应的餐桌不存在，即没有查询到根据id的行记录
     * 反之，应修改餐桌的状态，只有当餐桌存在(即查询到一行记录，DiningTable不为null)，并且是空闲状态才可以预定
     * @param diningTableId 餐桌编号
     */
    public static DiningTable getDiningTableById(int diningTableId) {
        //querySingle 查询单行结果的通用方法,结果集中的每一行就代表一个类对象
        DiningTable diningTable = diningTableDAO.querySingle("select * from diningTable where id = ?", DiningTable.class, diningTableId);
        return diningTable;
    }

    /**
     * 如果餐桌可以预定就返回true，调用set方法，并对其状态进行更新，包括预定人的名字和电话
     * @param id 餐桌编号
     * @param orderName 预定人名字
     * @param orderTel 预定人电话
     * @return true代表预定成功
     */
    public static boolean isCanBook(int id, String orderName, String orderTel) {
//        //先根据id得到对应的餐桌对象
//        DiningTable diningTable = getDiningTableById(id);
//        //不为空，代表餐桌存在，即在数据库中查询到一行对应记录，并且当前查询到的餐桌状态为 空闲 时才可以进行下面的操作
//        if (diningTable != null && diningTable.getState().equals("空闲")) {
//            //对该餐桌进行信息更新，注意不能通过diningTable.setXxx()方法来修改，这样并没有真修改数据库中的信息
//            String sql = "update diningTable set state = '已预定', orderName = ?, orderTel = ? where id = ?";
//            int rows = diningTableDAO.update(sql, orderName, orderTel, id);
//            if (rows > 0) {
//                return true; //此时，预定成功
//            }
//        }
//        //反之，餐桌不存在，直接返回false，表示餐桌编号为 id 的当前餐桌不可以预定
//        return false;

        //这样写更简便，如果数据库更新成功，意味着餐桌编号为 id 存在
        DiningTable diningTable = getDiningTableById(id);
        //餐桌存在，并且当前查询到的餐桌状态为 空闲 时才可以预定，并更新数据库信息
        if (diningTable.getState().equals("空闲")) {
            int row = diningTableDAO.update(
                    "update diningTable set state = '已预定', orderName = ?, orderTel = ? where id = ?",
                    orderName, orderTel, id);
            return row > 0;
        }
        //不是空闲状态，直接返回false
        return false;
    }

    /**
     * 更新餐桌状态的方法
     * @param id 餐桌编号
     * @param state 餐桌状态
     * @return 状态更新成功返回true
     */
    public static boolean updateDiningTableState(int id, String state) {
        return diningTableDAO.update("update diningTable set state = ? where id = ?", state, id) > 0;
    }

    /**
     * 更新餐桌信息
     * @param id 餐桌编号
     * @return 返回true代表餐桌信息重置成功
     */
    public static boolean updateDiningTable(int id) {
        return diningTableDAO.update(
                "update diningTable set state = '空闲', orderName = '', orderTel = '' where id  = ? ", id) > 0;
    }
}
