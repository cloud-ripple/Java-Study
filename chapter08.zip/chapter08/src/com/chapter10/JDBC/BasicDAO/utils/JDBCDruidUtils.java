package com.chapter10.JDBC.BasicDAO.utils;

import com.alibaba.druid.pool.DruidDataSourceFactory;

import javax.sql.DataSource;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

/**
 * @author BoBoKing
 * @date 2023/5/2
 * @description 使用德鲁伊数据库连接池 编写一个JDBC工具类
 */

public class JDBCDruidUtils {
    /**
     * @ds 数据源，即数据库连接池
     */
    private static DataSource ds = null;

    //在静态代码块完成初始化
    static {
        try {
            Properties properties = new Properties();
            //1.把配置文件的数据加载到properties对象中
            properties.load(new FileInputStream("src/com/chapter10/JDBC/druid.properties"));
            //2.通过德鲁伊数据源工厂创建一个指定参数的数据库连接池
            ds = DruidDataSourceFactory.createDataSource(properties);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    //通过数据库连接池得到连接
    public static Connection getConnection() throws SQLException {
        return ds.getConnection();
    }

    //关闭连接
    /** 注意：在数据库连接池技术中，close()方法不是真的断掉连接
    而是把使用的Connection对象放回连接池
     */
    public static void close(ResultSet resultSet, PreparedStatement statement, Connection connection) {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
