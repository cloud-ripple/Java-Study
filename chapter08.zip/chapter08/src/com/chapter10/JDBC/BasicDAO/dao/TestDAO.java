package com.chapter10.JDBC.BasicDAO.dao;

import com.chapter10.JDBC.BasicDAO.domain.Actor;
import org.junit.Test;

import java.util.List;

/**
 * @author BoBoKing
 * @date 2023/5/3
 * @description 测试DAO类对各种表的crud操作
 */

public class TestDAO {

    //测试ActorDAO对actor表的操作
    @Test
    public void testActorDAO() {
        ActorDAO actorDAO = new ActorDAO();
        //1.查询多行记录
        List<Actor> actors = actorDAO.queryMultiply("select * from actor where id >= ?", Actor.class, 1);
        //2.输出查询结果
        for (Actor actor : actors) {
            System.out.println(actor);
        }

        //查询单行记录
        Actor actor = actorDAO.querySingle("select * from actor where id = ?", Actor.class, 29);
        System.out.println(actor);
    }
}
