package com.chapter10.JDBC.BasicDAO.dao;

import com.chapter10.JDBC.BasicDAO.domain.Actor;

/**
 * @author BoBoKing
 * @date 2023/5/3
 * @description 该类完成对数据库中 actor表的操作
 */

public class ActorDAO extends BasicDAO<Actor> {
    //1.继承 BasicDAO后就有了其父类的public方法
    //2.根据业务需求，可以编写自己特有的方法

}
