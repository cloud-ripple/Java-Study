package com.chapter10.JDBC;

import org.junit.Test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @author BoBoKing
 * @date 2023/4/27
 * @description 批处理应用
 * 1.当需要成批插入或更新记录时，可以采用Java的批量更新机制，
 * 这一机制允许多条语句一次性提交给数据库批量处理，通常情况下比单独提交处理更有效率
 * 2.JDBC的批处理语句包括下面方法：
 *   addBatch(): 添加需要批量处理的SQL语句或参数
 *   executeBatch(): 执行批量处理语句
 *   clearBatch(): 清空批处理包的语句
 *
 * 3.JDBC连接MySQL时，如果要使用批处理功能，请在url中加参数 ？rewriteBatchedStatements=true
 * 4.批处理往往和PreparedStatement一起搭配使用，可以减少编译次数，减少运行次数，因此效率提高
 */

public class JDBC06 {
    /** 演示Java的批处理
         应用案例：
         1.演示向 数据库hsp_db02的 admin表中添加5000条数据，看看使用批处理耗时多久
         2.注意：需要修改配置文件 jdbc.properties 中的
         url=jdbc:mysql://localhost:3306/数据库名?rewriteBatchedStatements=true
     */
    //1.传统方式
    @Test
    public void noBatch() throws SQLException {
        Connection connection = JDBCUtils.getConnection();
        String sql = "insert into admin values (null, ?, ?)"; //插入数据
        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        System.out.println("开始执行sql语句..");
        long start = System.currentTimeMillis(); //开始时间
        for (int i = 0; i < 5000; i++) {
            //给？占位符参数赋值
            preparedStatement.setString(1, "bobo" + i); //第一个？，给出不同的值
            preparedStatement.setString(2, "4436520" + i); //第二个？，也给出不同的值
            //执行sql语句
            preparedStatement.executeUpdate();
        }
        long end = System.currentTimeMillis(); //结束时间
        System.out.println("传统方式执行5000条sql语句，一共耗时：" + (end - start) + " ms");

        //关闭连接
        JDBCUtils.close(null, preparedStatement, connection);
    }

    //2.使用批处理方式
    @Test
    public void useBatch() throws SQLException {
        Connection connection = JDBCUtils.getConnection();
        String sql = "insert into admin values (null, ?, ?)"; //插入数据
        //得到PreparedStatement对象，根据指定的sql，进行预处理操作
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        System.out.println("开始执行sql语句..");
        long start = System.currentTimeMillis(); //开始时间

        for (int i = 0; i < 5000; i++) {
            //每次执行sql语句，都给？占位符参数赋值
            preparedStatement.setString(1, "bobo" + i); //第一个？，给出不同的值
            preparedStatement.setString(2, "4436520" + i); //第二个？，也给出不同的值
            //把要执行并且已经通过PreparedStatement对象预处理过，的sql语句加入到批处理包中
            preparedStatement.addBatch();

            //每当批处理包中累积到1000条记录时，再批量执行
            if ((i + 1) % 1000 == 0) { //满1000条sql
                preparedStatement.executeBatch();//批量执行
                //然后，清空包
                preparedStatement.clearBatch();
            }
        }
        long end = System.currentTimeMillis(); //结束时间
        System.out.println("批处理方式，执行5000条sql语句，一共耗时：" + (end - start) + " ms");
        //关闭连接
        JDBCUtils.close(null, preparedStatement, connection);
    }
}
