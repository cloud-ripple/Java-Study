package com.chapter10.JDBC;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.junit.Test;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

/**
 * @author BoBoKing
 * @date 2023/4/27
 * @description 演示C3P0的使用
 * 记得导入相关的jar包
 * c3p0-0.9.5.5.jar
 * mchange-commons-java-0.2.19.jar
 * mysql-connector-j-8.0.31.jar
 * 并添加到项目依赖
 *
 */

public class JDBC08 {
    //方式1：相关参数，在程序中指定user, url, password等
    @Test
    public void C3P0_01() throws Exception {
        //1.创建一个数据源对象
        ComboPooledDataSource comboPooledDataSource = new ComboPooledDataSource();

        //2. 通过Properties对象获取配置文件信息
        Properties properties = new Properties();
        properties.load(new FileInputStream("src/com/chapter10/JDBC/mysql.properties"));
        // 文件路径也可以这样写 src\\com\\chapter10\\JDBC\\mysql.properties
        //获取相关的值
        String user = properties.getProperty("user");
        String password = properties.getProperty("password");
        String driver = properties.getProperty("driver");
        String url = properties.getProperty("url");

        //3.给数据源 comboPooledDataSource设置相关的参数
        //注意：连接管理是由comboPooledDataSource来管理
        comboPooledDataSource.setDriverClass(driver);
        comboPooledDataSource.setJdbcUrl(url);
        comboPooledDataSource.setUser(user);
        comboPooledDataSource.setPassword(password);

        //4.设置初始化连接数
        comboPooledDataSource.setInitialPoolSize(10);
        //5.设置最大连接数  如果刚开始的连接数不够，则进行扩容，最大只能有根据设置的数量50
        comboPooledDataSource.setMaxPoolSize(50);

        //测试连接池的效率，连接MySQL数据库 5000次操作
        long start = System.currentTimeMillis();
        for (int i = 0; i < 5000; i++) {
            //6.得到连接
            Connection connection = comboPooledDataSource.getConnection(); //这个方法就是从 DataSource 接口实现的
            //7.关闭连接
            connection.close();
        }
        long end = System.currentTimeMillis();
        System.out.println("使用C3P0数据库连接池 连接5000次数据，耗时：" + (end - start) + "ms");

    }

    //方式2: 使用配置文件模板来完成
    /** 使用C3P0提供的配置文件 c3p0-config.xml 放在 src目录下，注意文件名不要搞错
     * 该文件指定了连接数据库和*/
    @Test
    public void C3P0_02() throws SQLException {
        ComboPooledDataSource comboPooledDataSource = new ComboPooledDataSource("hsp_edu"); //写入数据源的名称

        //测试5000次连接mysql
        long start = System.currentTimeMillis();
        System.out.println("开始执行..");
        for (int i = 0; i < 5000; i++) {
            Connection connection = comboPooledDataSource.getConnection();
            connection.close(); //得到连接之后，关闭
        }
        long end = System.currentTimeMillis();
        System.out.println("c3p0 使用配置文件 c3p0-config连接5000次mysql数据库 耗时：" + (end - start) + "ms");

    }

}
