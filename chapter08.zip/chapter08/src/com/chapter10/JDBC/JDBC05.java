package com.chapter10.JDBC;

import org.junit.Test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @author BoBoKing
 * @date 2023/4/27
 * @description 演示JDBC中如何使用事务
 基本介绍
  1.JDBC程序中当一个Connection对象创建时，默认情况下是自动提交事务：
 每次执行一个SQL语句时，如果执行成功，就会向数据库自动提交，而不能回滚。

  2.JDBC程序中为了让多个SQL语句作为一个整体执行，需要使用事务。
  3.调用Connection的setAutoCommit(false)可以取消自动提交事务
  4.在所有的SQL语句都成功执行后，调用commit()方法提交事务
  5.在其中某个操作失败或出现异常时，调用rollback()方法回滚事务

 */

public class JDBC05 {

    /** 实例：经典的转账业务
     * 没有使用事务情况
     * */
    @Test
    public void noTransaction() throws SQLException {
        //1.得到连接
        Connection connection = null;
        //2.组织SQL语句  让id为1的给 id为2转账 100元
        String sql = "update account set money = money - 100 where id = 1";
        String sql2 = "update account set money = money + 100 where id = 2";
        //3.创建PreparedStatement对象
        PreparedStatement preparedStatement = null;

        /** Connection对象创建时，默认情况下是自动提交事务
         * 每次执行一个SQL语句时，如果执行成功，就会向数据库自动提交，而不能回滚。*/
        connection = JDBCUtils.getConnection();

        preparedStatement = connection.prepareStatement(sql);
        preparedStatement.executeUpdate(); //执行第一条sql语句

        int i = 1 / 0;   /** 此处会抛出算术异常，下面的代码不会再执行 */
        //此时第一条SQL语句执行成功，而第二条没有执行，导致转账失败
        preparedStatement = connection.prepareStatement(sql2);
        preparedStatement.executeUpdate(); //执行第二条sql语句

        //4.关闭资源
        JDBCUtils.close(null, preparedStatement, connection);
    }

    /** 使用事务来解决 */
    @Test
    public void useTransaction() throws SQLException {
        //1.得到连接
        Connection connection = null;
        //2.组织SQL语句  让id为1的给 id为2转账 100元
        String sql = "update account set money = money - 100 where id = 1";
        String sql2 = "update account set money = money + 100 where id = 2";
        //3.创建PreparedStatement对象
        PreparedStatement preparedStatement = null;

        try {
            /** Connection对象创建时，默认情况下是自动提交事务
             * 每次执行一个SQL语句时，如果执行成功，就会向数据库自动提交，而不能回滚。*/
            connection = JDBCUtils.getConnection();
            /** 这里相当于开始了事务 */
            connection.setAutoCommit(false); //取消自动提交

            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.executeUpdate(); //执行第一条sql语句

            //int i = 1 / 0;   /** 运行时，此处会抛出算术异常，下面的代码不会再执行 */

            //此时第一条SQL语句执行成功，而第二条没有执行，导致转账失败
            preparedStatement = connection.prepareStatement(sql2);
            preparedStatement.executeUpdate(); //执行第二条sql语句

            //这里提交事务,如果上面代码在执行过程中没有发生异常，就把事务提交，该怎么执行就怎么执行
            //反之，在catch中进行回滚
            connection.commit();

        } catch (SQLException e) {  //当捕获到异常时
            //这里可以进行回滚，即撤销执行的sql语句
            System.out.println("执行过程中发生了异常，回滚到事务开始状态，撤销执行的sql语句");
            connection.rollback();
            /** rollback()方法 默认回滚到事务开始的地方 */
            /** rollback(Savepoint savepoint)方法 回滚到保存点处 */
            throw new RuntimeException(e);
        } finally {
            //4.关闭资源
            JDBCUtils.close(null, preparedStatement, connection);
        }


    }
}
