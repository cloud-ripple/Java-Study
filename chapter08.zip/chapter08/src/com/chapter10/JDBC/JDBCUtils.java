package com.chapter10.JDBC;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

/**
 * @author BoBoKing
 * @date 2023/4/26
 * @description JDBC工具类
 */

public class JDBCUtils {
    //定义相关的属性
    private static String user;
    private static String password;
    private static String url;
    private static String driver;

    //代码块初始化
    static {
        try {
            Properties properties = new Properties();
            properties.load(new FileInputStream("src/com/chapter10/JDBC/mysql.properties"));
             //读取相关的属性
            user = properties.getProperty("user");
            password = properties.getProperty("password");
            url = properties.getProperty("url");
            driver = properties.getProperty("driver");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    //dml 增删改操作
    public static int update(String sql) {
        try {
            return getConnection().prepareStatement(sql).executeUpdate(); //返回受影响的行数
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //查询操作
    public static ResultSet query(String sql) {
        try {
            return getConnection().prepareStatement(sql).executeQuery(); //返回结果集
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //多个参数查询
    public static ResultSet query(String sql, Object[] parameters) throws SQLException {
        PreparedStatement preparedStatement = getConnection().prepareStatement(sql);
        //根据给定的参数数量，给对应的？占位符赋值，sql语句中有多少个？占位符，调用方法时就应该传入多少个实际参数
        for (int i = 0; i < parameters.length; i++) {  //setObject(int parameterIndex, Object x)方法  ？参数索引从1开始，第二个参数是值
            preparedStatement.setObject(i + 1, parameters[i]);
        }

        return preparedStatement.executeQuery(); //执行查询，并返回结果集
    }

    //多个sql语句dml
    public static int update(String[] sql) throws SQLException {
        int rows = 0;
        for (int i = 0; i < sql.length; i++) {
            PreparedStatement statement = getConnection().prepareStatement(sql[i]);
            if (statement.executeUpdate() > 0) {
                rows++;
            }
        }

        return rows;
    }

    //连接数据库，返回连接
    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //关闭资源
    public static void close(ResultSet set, PreparedStatement statement, Connection connection) {
        //判断是否为空
        try {
            if (set != null) {
                set.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
