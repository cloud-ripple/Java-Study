package com.chapter10.JDBC;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.Properties;

/**
 * @author BoBoKing
 * @date 2023/4/25
 * @description ResultSet结果集
 */

public class Jdbc03 {
    //ResultSet 结果集
    //1.表示数据库结果集的数据表，通常通过执行查询数据库的语句生成
    //2.ResultSet对象保持一个光标指向其当前的数据行，最初，光标位于第一行之前
    //3. next()方法将光标移动到下一行，并且由于在ResultSet对象中没有更多行返回时返回false，
    //因此可以在while循环中来遍历结果集。

    //4. previous()方法向上移动一行
    public static void main(String[] args) throws Exception {
        //通过Properties对象获取配置文件信息
        Properties properties = new Properties();
        properties.load(new FileInputStream("src/com/chapter10/JDBC/mysql.properties"));
        // 文件路径也可以这样写 src\\com\\chapter10\\JDBC\\mysql.properties
        //获取相关的值
        String user = properties.getProperty("user");
        String password = properties.getProperty("password");
        String driver = properties.getProperty("driver");
        String url = properties.getProperty("url");

        //1.注册驱动
        Class.forName(driver);
        //2.得到连接
        Connection connection = DriverManager.getConnection(url, user, password);
        System.out.println("方式5 数据库连接成功 connect = " + connection);

        /** 演示使用select 语句返回 ResultSet结果集，并得到表中数据 */
        //3.得到Statement
        Statement statement = connection.createStatement();
        //4.组织sql语句
        String sql = "select * from actor";
        //5.执行sql语句  ResultSet executeQuery(String sql)方法，执行给定的sql，并返回单个的 ResultSet对象
        ResultSet resultSet = statement.executeQuery(sql);
        //6.使用循环遍历，取出数据
        while (resultSet.next()) { //让光标向后移动，如果没有更多行，则返回false
            int id = resultSet.getInt(1); //获取当前行的第一列
            String name = resultSet.getString(2); //获取当前行的第2列
            String sex = resultSet.getString(3); //获取当前行的第3列
            Date date = resultSet.getDate(4); //获取当前行的第4列
            String phone = resultSet.getString(5); //获取当前行的第5列
            //输出每一行的数据
            System.out.println(id + "\t" + name + "\t" + sex + "\t" + date + "\t" + phone);
        }

        //7.关闭连接
        resultSet.close();
        statement.close();
        connection.close();

    }
}
