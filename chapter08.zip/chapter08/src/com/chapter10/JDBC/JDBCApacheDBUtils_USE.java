package com.chapter10.JDBC;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;
import org.junit.Test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author BoBoKing
 * @date 2023/5/2
 * @description ApDBUtils引出
 * 分析问题：
 * 1.关闭connection连接后，resultSet结果集无法使用
 * 2.resultSet不利于数据的管理，只能使用一次
 * 3.使用返回信息也不方便
 *
 * 基本介绍：
 * 1.commons-dbutils是Apache组织提供的一个开源JDBC工具类库，它是对JDBC的封装
 * 使用dbutils能极大简化jdbc编码的工作量
 * 2.QueryRunner类：该类封装了SQL的执行，是线程安全的，可以是西安增删改查，以及批处理
 * 3.ResultSetHandler接口：该接口用于处理 java.sql.ResultSet，将数据按要求转换为另一种形式
 *
 * 相关方法API：
 * ArrayHandler:把结果集中的第一行数据转成对象数组
 * ArrayListHandler:把结果集中的每一行数据都转成一个数组，再存放到 List中
 * BeanHandler:将结果集中的第一行数据封装到一个对应的 JavaBean实体对象中
 * BeanListHandler:将结果集中的每一行数据都封装到一个对应的 JavaBean实体对象中，存放到List中
 * ColumnListHandler:将结果集中某一列的数据存放到List中
 * KeyedHandler(name):将结果集中的每行数据都封装到Map里，再把这些map再次存放到一个 Map里，其key为指定的key
 * MapHandler；将结果集中的第一行数据封装到一个Map里，key是列名，value是对应的值
 * MapListHandler:将结果集中的每一行数据都封装到一个Map里，然后再存放到List
 */

public class JDBCApacheDBUtils_USE {

    //使用土方法来解决ResultSet  ---封装---> ArrayList
    /**
     * @actorsList 把结果集封装到集合列表中，list中存放着 Actor实体对象
     * 调用此方法得到一个集合，集合中存放在Actor实体类对象
     */
    @Test
    public void resultSetToArrayList() throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet rs = null;
        String sql = "select * from actor where id >= ?";
        ArrayList<Actor> actorsList = new ArrayList<>();

        try {
            //1.通过工具类得到connection连接对象
            connection = JDBCDruidUtils.getConnection();
            //2.创建PreparedStatement对象,并指定sql语句进行预处理查询
            statement = connection.prepareStatement(sql);
            //3.给？参数占位符赋值
            statement.setInt(1, 1);  //在sql语句中相当于 where id >= 1
            //4.执行，得到结果集
            rs = statement.executeQuery();

            //5. 遍历该结果集(即查询到的表记录)
            while (rs.next()) {
                int id = rs.getInt("id"); //这里的字段名一定要跟结果集表中对应
                String name = rs.getString("name");
                String sex = rs.getString("sex");
                Date born = rs.getDate("borndate");
                String phone = rs.getString("phone");
                //把得到的记录，封装到 Actor实体类对象中，并放入list集合
                /** next()方法方指针光标向下移动，结果集的每一行记录就相当于每一个 不同的Actor对象，它的属性和表中的字段相对应 */
                actorsList.add(new Actor(id, name, sex, born, phone));
            }
            //此时把结果集的每一行记录都封装到了集合中
            System.out.println("list集合数据 = " + actorsList);
            //从集合中得到Actor对象，根据get set方法得到相对应的内容
            for (Actor actor : actorsList) {
                System.out.println("id = " + actor.getId());
                //...
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            //6.关闭资源
            JDBCDruidUtils.close(rs, statement, connection);
            connection.close();
        }

        //return actorsList; //返回集合
    }

    //使用apache-dbutils 工具类 + druid德鲁伊数据库连接池完成对表的crud操作
    @Test
    public void testQuery() throws SQLException {
        //1.得到连接
        Connection connection = JDBCDruidUtils.getConnection();
        //2.使用 DBUtils 类和接口，先引入相关的jar包 commons-dbutils-1.7.jar
        //3.创建 QueryRunner
        QueryRunner queryRunner = new QueryRunner();
        //4.就可以执行相关方法，返回ArrayList 结果集
        String sql = "select * from actor where id >= ?";
        /*解读 query(Connection conn, String sql, ResultSetHandler<T> rsh, Object... params)方法
            (1)query 方法就是执行sql语句，得到resultSet ---封装到---> ArrayList集合中
            (2)返回集合
            (3)connection:连接
            (4)new BeanListHandler<>(Actor.class):在将resultSet -> Actor对象 -> 封装到ArrayList
            底层使用反射机制，去获取Actor类的属性，然后进行封装
            (5) 1 代表给sql语句中的？参数占位符赋值，可以有多个值，因为是可变参数Object... params
            (6)底层得到的 resultSet，PreparedStatement 会在query方法关闭，只需要传入connection关闭即可
        */
        List<Actor> actorList =
                queryRunner.query(connection, sql, new BeanListHandler<>(Actor.class), 1);
        System.out.println("输出集合的信息");
        for (Actor actor : actorList) {
            System.out.println(actor);
        }

        //5.释放资源
        JDBCDruidUtils.close(null, null, connection);

    }

    //演示 apache-dbutils + druid 完成返回的结果是单行记录(单个对象)
    @Test
    public void testQuerySingle() throws SQLException {
        //1.得到连接
        Connection connection = JDBCDruidUtils.getConnection();
        //2.使用 DBUtils 类和接口，先引入相关的jar包 commons-dbutils-1.7.jar
        //3.创建 QueryRunner
        QueryRunner queryRunner = new QueryRunner();
        //4.就可以执行相关方法，返回单个对象
        String sql = "select * from actor where id = ?"; //一条记录
        /*解读
            因为返回的单行记录--->单个对象，使用的Handler 是 BeanHandler
        */
        Actor actor = queryRunner.query(connection, sql, new BeanHandler<>(Actor.class), 28);
        if (actor != null) { //判断是否查询到记录，然后做相应的逻辑处理
            System.out.println(actor);
            //...
        }
        //释放资源
        JDBCDruidUtils.close(null, null, connection);
    }

    //演示 apache-dbutils + druid 完成返回的结果是单行单列(具体的一个值)-返回的就是Object
    @Test
    public void testScalar() throws SQLException {  //Scalar 单一值
        //1.得到连接
        Connection connection = JDBCDruidUtils.getConnection();
        //2.使用 DBUtils 类和接口，先引入相关的jar包 commons-dbutils-1.7.jar
        //3.创建 QueryRunner
        QueryRunner queryRunner = new QueryRunner();
        //4.可以执行相关方法，返回单行单列,返回的就是Object
        String sql = "select name from actor where id = ?";
        Object obj = queryRunner.query(connection, sql, new ScalarHandler<>(), 28);
        if (obj != null) {
            System.out.println(obj);
        }

        //释放资源
        JDBCDruidUtils.close(null, null, connection);
    }

    //演示 apache-dbutils + druid完成 dml操作 update, insert, delete
    @Test
    public void testDML() throws SQLException {
        //1.得到连接
        Connection connection = JDBCDruidUtils.getConnection();
        //2.使用 DBUtils 类和接口，先引入相关的jar包 commons-dbutils-1.7.jar
        //3.创建 QueryRunner
        QueryRunner queryRunner = new QueryRunner();

        //4.可以执行相关方法，返回单行单列,返回的就是Object
        String sql = "update actor set name = ? where id = ?";
        String sql2 = "insert into actor values (null, ?, ?, ?, ?)";
        int rows = queryRunner.update(connection, sql, "腾薇薇", 29); //执行后，返回受影响的行数
        if (rows > 0) {
            System.out.println("数据更新成功");
        }

        int i = queryRunner.update(connection, sql2, "云韵", "女", "2001-6-8", "4436520");
        System.out.println(i > 0 ? "数据插入成功": "没有影响到表，插入失败");
        //释放资源
        JDBCDruidUtils.close(null, null, connection);
    }
}
