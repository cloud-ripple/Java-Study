package com.chapter10.JDBC;

import com.mysql.cj.jdbc.Driver;

import java.sql.Connection;
import java.sql.Statement;
import java.util.Properties;

/**
 * @author BoBoKing
 * @date 2023/4/25
 * @description JDBC快速入门案例
 */

public class Jdbc01 {

    public static void main(String[] args) throws Exception {
        //1.注册驱动 创建对象
        Driver driver = new Driver();

        //2.得到连接
        //(1)jdbc:mysql://  规定好表示协议，通过JDBC的方式连接mysql
        //(2)localhost 主机，可以是IP地址
        //(3)3306 表示mysql监听的端口
        //(4)hsp_db02 连接到mysql dbms的哪个数据库
        //(5)mysql连接的本质就是socket连接
        String url = "jdbc:mysql://localhost:3306/hsp_db02";

        //将用户名和密码放入到Properties中
        Properties properties = new Properties();
        //说明：user password是规定好的
        properties.setProperty("user", "root");  // 也可以是普通用户，但是能操作的数据库和权限就不相同了
        properties.setProperty("password", "twb");

        //connect(String url, Properties info)方法  根据指定的URL连接到数据库
        Connection connect = driver.connect(url, properties);
        System.out.println("数据库连接成功 connect = " + connect);

        //3.执行sql
        String sql = "insert into actor values (null, '田维波', '男', '2000-08-13', '4436520')";
        //用于执行SQL语句并返回其生成的结果的对象
        Statement statement = connect.createStatement();
        int rows = statement.executeUpdate(sql);  //如果是dml语句，返回的是影响行数
        System.out.println(rows > 0 ? "记录插入成功":"插入失败");

        //4.关闭连接资源
        statement.close();
        connect.close();

    }
}
