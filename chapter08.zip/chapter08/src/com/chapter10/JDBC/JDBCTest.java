package com.chapter10.JDBC;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 * @author BoBoKing
 * @date 2023/4/26
 * @description 测试JDBC工具类
 */

public class JDBCTest {
    public static void main(String[] args) throws SQLException {

        int rows = JDBCUtils.update(new String[] {
                "insert into actor values (null, 'bobo', '男', '2000-08-13', '4436')",
                "insert into actor values (null, 'jack', '男', '2002-06-13', '7789')",
                "insert into actor values (null, '韩立', '女', '2010-08-13', '6678')",
                "insert into actor values (null, '忘语', '男', '2000-08-13', '3456')"
        });

        System.out.println(rows > 0 ? "一共插入了" + rows + "条记录" : "数据插入失败");

        ResultSet rs = JDBCUtils.query(
                "select * from actor where name = ? or sex = ?",
                new Object[]{
                        "bobo", "女"
                });

        while (rs.next()) {
            int id = rs.getInt("id");
            String name = rs.getString("name");
            String sex = rs.getString("sex");
            Date birthday = rs.getDate("borndate");
            System.out.println(id + "\t" + name + "\t"  + sex + "\t" + birthday);
        }
    }
}
