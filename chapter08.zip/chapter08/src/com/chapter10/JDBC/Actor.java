package com.chapter10.JDBC;

import java.util.Date;

/**
 * @author BoBoKing
 * @date 2023/5/2
 * @description Actor对象和数据库中的 actor表的记录相对应
 */

public class Actor {

    private Integer id;
    private String name;
    private String sex;
    private Date born;
    private String phone;

    //一定要给一个无参构造器，因为使用反射的时候需要
    public Actor() {

    }

    public Actor(Integer id, String name, String sex, Date born, String phone) {
        this.id = id;
        this.name = name;
        this.sex = sex;
        this.born = born;
        this.phone = phone;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Date getBorn() {
        return born;
    }

    public void setBorn(Date born) {
        this.born = born;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "Actor{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", sex='" + sex + '\'' +
                ", born=" + born +
                ", phone='" + phone + '\'' +
                '}';
    }
}
