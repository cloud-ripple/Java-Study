package com.chapter10.JDBC;

import java.io.FileInputStream;
import java.sql.*;
import java.util.Properties;

/**
 * @author BoBoKing
 * @date 2023/4/25
 * @description 预处理查询 PreparedStatement 可以防止SQL注入问题
 */

public class Jdbc04 {
    //1.PreparedStatement执行的SQL语句中的参数用问号 ？ 来表示，调用PreparedStatement对象
    //的setXxx()方法来设置这些参数，setXxx()方法有两个参数，第一个参数是要设置的SQL语句中的参数
    //的索引(从1开始)，第二个参数是设置的SQL语句中的参数的值

    //2.调用executeQuery()方法，返回结果集ResultSet对象
    //3.调用executeUpdate()方法，执行增删改操作

    /* 预处理好处：
        1.不再使用 + 拼接sql语句，减少语法错误
        2.有效的解决了sql注入问题
        3.减少了编译次数，效率较高
    */
    public static void main(String[] args) throws Exception {
        //通过Properties对象获取配置文件信息
        Properties properties = new Properties();
        properties.load(new FileInputStream("src/com/chapter10/JDBC/mysql.properties"));
        // 文件路径也可以这样写 src\\com\\chapter10\\JDBC\\mysql.properties
        //获取相关的值
        String user = properties.getProperty("user");
        String password = properties.getProperty("password");
        String driver = properties.getProperty("driver");
        String url = properties.getProperty("url");

        //1.注册驱动
        Class.forName(driver);
        //2.得到连接
        Connection connection = DriverManager.getConnection(url, user, password);
        System.out.println("数据库连接成功 connect = " + connection);

        //3.组织sql语句
        /** sql语句中的 ？ 就相当于参数占位符 */
        //查询
        String sql = "select `name`, sex from actor where id = ?";
        //添加
        String sql2 = "insert into actor values (?,?,?,?,?)";

        //4.根据sql语句，得到对应的PreparedStatement对象
        PreparedStatement statement = connection.prepareStatement(sql);
        PreparedStatement statement2 = connection.prepareStatement(sql2);

        //sql语句中  ？参数赋值，设置sql语句中的第一个 ? 参数，并设置参数值为 4  ,相当于 where id = 4
        statement.setObject(1, 4); /** sql语句中有多少个 ？ ,就可以设置多少个参数，问号？索引从1开始 */

        //sql2语句中  ？参数赋值
        statement2.setObject(1, null); //第一个？
        statement2.setObject(2, "wei"); //第二个？
        statement2.setObject(3, "女");
        statement2.setObject(4, "2002-12-12");
        statement2.setObject(5, "123456");

        //5.执行sql语句  ResultSet executeQuery()方法,并返回单个的 ResultSet对象
        int rows = 0;
        for (int i = 0; i < 10; i++) {  //插入多条记录
            rows += statement2.executeUpdate(); //把返回的受影响的行数，累加起来
        }
        System.out.println(rows > 0 ? "数据插入成功，一共插入了" + rows + "条记录":"插入失败");

        ResultSet resultSet = statement.executeQuery();  //这里执行 executeQuery，不要再次传入参数sql,
        //否则这里的sql默认还是上面的 select `name`,sex from actor where id = ? ，产生sql语法错误
        //6.使用循环遍历，取出数据
        while (resultSet.next()) { //让光标向后移动，如果没有更多行，则返回false
            String name = resultSet.getString(1); //获取当前行的第1列
            String sex = resultSet.getString(2); //获取当前行的第2列
            //输出每一行的数据
            System.out.println(name + "\t" + sex);
        }

        //7.关闭连接
        resultSet.close();
        statement.close();
        connection.close();
    }
}
