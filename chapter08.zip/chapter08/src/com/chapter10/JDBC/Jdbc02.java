package com.chapter10.JDBC;

import com.mysql.cj.jdbc.Driver;
import org.junit.Test;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * @author BoBoKing
 * @date 2023/4/25
 * @description java连接mysql的5种方式
 */

public class Jdbc02 {

    //方式1
    @Test
    public void connect01() throws SQLException {
        //静态加载，依赖性强
        Driver driver = new Driver();
        String url = "jdbc:mysql://localhost:3306/hsp_db02";
        //将用户名和密码放入到Properties对象中
        Properties properties = new Properties();
        properties.setProperty("user", "root");  // 也可以是普通用户，但是能操作的数据库和权限就不相同了
        properties.setProperty("password", "twb");

        //connect(String url, Properties info)方法  根据指定的URL连接到数据库
        Connection connect = driver.connect(url, properties);
        System.out.println("方式1 数据库连接成功 connect = " + connect);
    }

    //方式2
    @Test
    public void connect02() throws Exception {
        //使用反射加载Driver类，动态加载，更加的灵活，减少依赖性
        Class<?> aClass = Class.forName("com.mysql.cj.jdbc.Driver");
        Driver driver = (Driver) aClass.newInstance();
        String url = "jdbc:mysql://localhost:3306/hsp_db02";
        //将用户名和密码放入到Properties对象中
        Properties properties = new Properties();
        properties.setProperty("user", "root");  // 也可以是普通用户，但是能操作的数据库和权限就不相同了
        properties.setProperty("password", "twb");

        //connect(String url, Properties info)方法  根据指定的URL连接到数据库
        Connection connect = driver.connect(url, properties);
        System.out.println("方式2 数据库连接成功 connect = " + connect);
    }

    //方式3  使用DriverManager 替代 Driver进行统一管理
    @Test
    public void connect03() throws Exception {
        //使用反射加载Driver
        Class<?> aClass = Class.forName("com.mysql.cj.jdbc.Driver");
        Driver driver = (Driver) aClass.newInstance();

        String url = "jdbc:mysql://localhost:3306/hsp_db02";
        String user = "root";
        String password = "twb";

        DriverManager.registerDriver(driver); //注册Driver驱动

        Connection connection = DriverManager.getConnection(url, user, password);
        System.out.println("方式3 数据库连接成功 connect = " + connection);

    }

    //方式4 使用Class.forName 自动完成注册驱动  -->该方式推荐使用
    @Test
    public void connect04() throws Exception {
        //使用反射加载类
        //在加载Driver类时，底层自动完成注册
        /* 静态代码块，类加载时，会执行一次
            static {
                try {
                    DriverManager.registerDriver(new Driver());
                } catch (SQLException var1) {
                    throw new RuntimeException("Can't register driver!");
                }
            }
        */

        Class.forName("com.mysql.cj.jdbc.Driver");

        String url = "jdbc:mysql://localhost:3306/hsp_db02";
        String user = "root";
        String password = "twb";

        Connection connection = DriverManager.getConnection(url, user, password);
        System.out.println("方式4 数据库连接成功 connect = " + connection);
    }

    //方式5 在方式4的基础上，使用配置文件，连接数据库更加灵活
    @Test
    public void connect05() throws Exception {
        //通过Properties对象获取配置文件信息
        Properties properties = new Properties();
        properties.load(new FileInputStream("src/com/chapter10/JDBC/mysql.properties"));
                // 文件路径也可以这样写 src\\com\\chapter10\\JDBC\\mysql.properties
        //获取相关的值
        String user = properties.getProperty("user");
        String password = properties.getProperty("password");
        String driver = properties.getProperty("driver");
        String url = properties.getProperty("url");

        Class.forName(driver);
        Connection connection = DriverManager.getConnection(url, user, password);

        System.out.println("方式5 数据库连接成功 connect = " + connection);
    }

    //ResultSet 结果集
    //1.表示数据库结果集的数据表，通常通过执行查询数据库的语句生成
    //2.ResultSet对象保持一个光标指向其当前的数据行，最初，光标位于第一行之前
    //3. next()方法将光标移动到下一行，并且由于在ResultSet对象中没有更多行返回时返回false，
    //因此可以在while循环中来遍历结果集。
}
