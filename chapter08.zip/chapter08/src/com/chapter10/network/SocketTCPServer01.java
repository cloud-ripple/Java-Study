package com.chapter10.network;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 日期：2023/3/12
 * 需求/说明：TCP字节流编程
 * 服务端
 * 1.编写一个服务器端和一个客户端
 * 2.服务器端在9999端口监听
 * 3.客户端连接到服务器端，发送 “hello, server"，并接收服务器端回发的"hello,client"，再退出
 * 4.服务器端接收到 客户端发送的信息，输出，并发送 "hello,client"，再退出
 */

public class SocketTCPServer01 {
    public static void main(String[] args) throws IOException {
        //1. 在本机的9999端口监听，等待连接
        //注意：要求在本机没有其它服务在监听9999
        //ServerSocket对象可以吗通过 accept()方法返回多个Socket对象[多个客户端服务器的并发]
        ServerSocket serverSocket = new ServerSocket(9999);
        System.out.println("服务端，在" + serverSocket.getLocalPort() + " 端口监听，等待连接");
        //2. 当没有客户端连接9999端口时，程序会阻塞，等待连接

        Socket socket = serverSocket.accept();
        //如果有客户端连接，则会返回Socket对象，程序继续
        System.out.println("服务端 socket = " + socket.getClass());

        //3. 通过socket.getInputStream()读取客户端写入到数据通道的数据，控制台显示
        InputStream inputStream = socket.getInputStream();

        //4.读取
        byte[] buf = new byte[1024];
        int readLen = 0;
        while ((readLen = inputStream.read(buf)) != -1) {
            System.out.println(new String(buf, 0, readLen));
        }

        //写入数据到数据通道
        OutputStream outputStream = socket.getOutputStream();
        outputStream.write("hello, client".getBytes());
        socket.shutdownOutput(); //设置写入结束标记

        //5.关闭输入流和socket
        inputStream.close();
        outputStream.close();
        socket.close();
        serverSocket.close();
    }
}
