package com.chapter10.network;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * 日期：2023/3/12
 * 需求/说明：InetAddress类相关方法
 * (1)获取本机InetAddress对象，getLocalHost
 * (2)根据指定主机名/域名获取ip地址对象 getByName
 * (3)获取InetAddress对象的主机名 getHostName
 * (4)获取InetAddress对象的地址 getHostAddress
 */

public class InetAddress01 {
    public static void main(String[] args) throws UnknownHostException {
        //1.获取本机InetAddress ip地址对象
        InetAddress localHost = InetAddress.getLocalHost();
        System.out.println(localHost); //LAPTOP-OQA935GA/169.254.128.225

        //2.根据指定 主机名/域名 获取ip地址对象 getByName
        InetAddress host1 = InetAddress.getByName("LAPTOP-OQA935GA");
        System.out.println(host1); //LAPTOP-OQA935GA/169.254.128.225

        //3.根据域名返回InetAddress对象，
        InetAddress host2 = InetAddress.getByName("www.baidu.com");
        System.out.println(host2); //www.baidu.com/110.242.68.4

        //4.通过InetAddress对象，获取对应的地址
        String hostAddress = host2.getHostAddress();
        System.out.println(hostAddress); //110.242.68.4

        //5.通过InetAddress对象，获取对应的主机名/或者域名
        String hostName = host2.getHostName();
        System.out.println("host2对应的主机名/域名 " + hostName);
    }
}
