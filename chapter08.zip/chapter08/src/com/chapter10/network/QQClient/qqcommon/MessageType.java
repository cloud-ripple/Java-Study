package com.chapter10.network.QQClient.qqcommon;

/**
 * 日期：2023/3/14
 * 需求/说明：
 */

public interface MessageType {
    //1.在接口中定义了一些常量
    //2.不同的常量的值，表示不同的消息类型
    public static final String MESSAGE_LOGIN_SUCCEED = "1"; //登录成功
    String MESSAGE_LOGIN_FAIL = "2"; //登录失败
    String MESSAGE_COMM_MES = "3"; //普通信息，在线聊天
    String MESSAGE_GET_ONLINE_FRIEND = "4"; //要求返回在线用户列表
    String MESSAGE_RET_ONLINE_FRIEND = "5"; //返回在线用户列表
    String MESSAGE_CLIENT_EXIT = "6"; //客户端请求退出
    String MESSAGE_TO_ALL_MES = "7"; //群发消息
    String MESSAGE_FILE_MES = "8"; //文件相关的消息
    String MESSAGE_OFFLINE_MES = "9"; //离线消息
}
