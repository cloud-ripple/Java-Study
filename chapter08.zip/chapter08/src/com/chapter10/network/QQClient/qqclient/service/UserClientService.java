package com.chapter10.network.QQClient.qqclient.service;

import com.chapter10.network.QQClient.qqcommon.Message;
import com.chapter10.network.QQClient.qqcommon.MessageType;
import com.chapter10.network.QQClient.qqcommon.User;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;

/**
 * 日期：2023/3/19
 * 需求/说明：该类完成用户登录验证和用户注册等功能
 */

public class UserClientService {

    private User user = new User(); //用户属性。因为我们肯在其他地方使用user信息
    private Socket socket = null; //因为Socket在其他敌方也肯使用，当作属性

    //根据用户见键盘输入的userId 和 pwd到服务器验证用户是否合法
    public boolean checkUser(String userId, String pwd) {
        boolean bool = false;
        //User对象初始化
        user.setUserId(userId);
        user.setPassword(pwd);
        try {
            //连接到服务端，发送user对象
            socket = new Socket(InetAddress.getByName("127.0.0.1"), 9999);
            //得到ObjectOutputStream对象
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream()); //通过数据通道获取的输出流来构建对象输出流
            oos.writeObject(user); //通过数据通道写入对象，--> 发送

            //读取从服务器端回复的Message对象
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream()); //对象输入流
            Message message = (Message) ois.readObject();

            if (message.getMessageType().equals(MessageType.MESSAGE_LOGIN_SUCCEED)) { //登录OK
                //创建一个和服务端保持通信的线程 --> 创建一个类 ClientConnectServerThread
                ClientConnectServerThread connectServerThread = new ClientConnectServerThread(socket);
                connectServerThread.start(); //启动客户端的线程，让它在哪里不停的读取服务端发送过来的消息
                //这里为了后面客户端的扩展，将线程放入到集合管理
                ManageClientConnectServerThread.addClientConnectServerThread(userId, connectServerThread);
                bool = true;
                user.setOnline(true);
            } else {
                //如果登录失败，线程是没有创建的，就不能启动和服务器通信的线程，关闭Socket
                socket.close();
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return bool;
    }

    //向服务器请求在线用户列表
    public void onlineFriendList() {
        //发送一个Message，类型MESSAGE_GET_ONLINE_FRIEND = "4"; //要求返回在线用户列表
        Message message = new Message();
        message.setMessageType(MessageType.MESSAGE_GET_ONLINE_FRIEND);
        message.setSender(user.getUserId());
        //发送给服务器
        try {
            //先得到当前线程的Socket对应的 ObjectOutputStream
            //从管理客户端线程的类调用方法得到与userId对应的线程，再从此线程得到它持有的Socket对象，再通过Socket得到输出流
            ObjectOutputStream oos = new ObjectOutputStream(ManageClientConnectServerThread.getClientConnectServerThread(user.getUserId()).getSocket().getOutputStream());
            oos.writeObject(message); //通过数据通道写入，让服务端去读取
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //编写方法，退出客户端，并给服务端发送一个退出系统的message对象
    public void logout() {
        //发送一个message，类型为MESSAGE_CLIENT_EXIT = "6"; //客户端请求退出
        Message message = new Message();
        message.setMessageType(MessageType.MESSAGE_CLIENT_EXIT);
        message.setSender(user.getUserId()); //需要指定是哪个客户端的用户需要退出，因为有多个用户
        //发送给服务器
        try {
            ObjectOutputStream oos = new ObjectOutputStream(ManageClientConnectServerThread.getClientConnectServerThread(user.getUserId()).getSocket().getOutputStream());
            oos.writeObject(message); //通过数据通道写入(发送)，让服务端去读取
            System.out.println("你已退出了系统");
            user.setOnline(false);
            System.exit(0); //结束进程
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
