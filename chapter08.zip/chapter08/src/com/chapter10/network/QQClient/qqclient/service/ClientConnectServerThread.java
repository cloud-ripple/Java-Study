package com.chapter10.network.QQClient.qqclient.service;

import com.chapter10.network.QQClient.qqclient.view.QQView;
import com.chapter10.network.QQClient.qqcommon.Message;
import com.chapter10.network.QQClient.qqcommon.MessageType;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.net.Socket;

/**
 * 日期：2023/3/19
 * 需求/说明：客户端连接服务端的线程-该类的对象和某个服务端保持通信
 */

public class ClientConnectServerThread extends Thread {
    //该线程需要持有 Socket
    private Socket socket = null;

    //构造器初始化socket对象
    public ClientConnectServerThread(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        //因为Thread需要在后台和服务器保持通信
        while (true) {
                try {
                    System.out.println("客户端线程，等待读取从服务器端发送的消息");
                    ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                    //启动线程后，会一直读取从服务端发送(写入)的消息，如果数据通道没有消息，线程会阻塞在此处
                    Message message = (Message) ois.readObject();
                    //判断这个message类型，然后做相应的业务处理
                    if (message.getMessageType().equals(MessageType.MESSAGE_RET_ONLINE_FRIEND)) {
                        //如果读取到的是 服务端返回的在线用户列表，取出在线列表信息，并显示
                        String[] onlineUsers = message.getContent().split(" ");
                        System.out.println("=====当前在线用户列表如下=====");
                        for (int i = 0; i < onlineUsers.length; i++) {
                            System.out.println("用户：" + onlineUsers[i]);
                        }
                    } else if (message.getMessageType().equals(MessageType.MESSAGE_COMM_MES)) { //普通的聊天消息
                        //把服务端转发的消息，显示到控制台即可
                        System.out.println("\n用户" + message.getSender() +
                                " 对用户" + message.getGetter() +
                                " 说：" + message.getContent() +
                                " " + message.getSendTime());
                    } else if (message.getMessageType().equals(MessageType.MESSAGE_TO_ALL_MES)) { //群发消息
                        //把服务端转发的消息，显示到客户端控制台即可
                        System.out.println("\n来自用户 " + message.getSender() +
                                " 的群发消息：" + message.getContent() +
                                " 发送于" + message.getSendTime());
                    } else if (message.getMessageType().equals(MessageType.MESSAGE_FILE_MES)) { //文件消息
                        //把服务端转发的消息，保存到自己目录下
                        FileOutputStream fileOutputStream = new FileOutputStream(message.getDest());
                        fileOutputStream.write(message.getFileBytes());
                        fileOutputStream.close(); //记得关闭或刷新，否则文件写不进去

                        System.out.println("\n用户 " + message.getSender() +
                                " 给你发送了一个文件："
                                + message.getSrc() + " 到你的 " + message.getDest() + " 目录下(文件保存成功！)");
                    } else {
                        System.out.println("是其它类型的message,暂时不处理..");
                    }
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
    }

    public Socket getSocket() {
        return socket;
    }

    public void setSocket(Socket socket) {
        this.socket = socket;
    }
}
