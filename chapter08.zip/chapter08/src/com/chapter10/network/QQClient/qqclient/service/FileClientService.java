package com.chapter10.network.QQClient.qqclient.service;

import com.chapter10.network.QQClient.qqcommon.Message;
import com.chapter10.network.QQClient.qqcommon.MessageType;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * 日期：2023/3/22
 * 需求/说明：该类完成文件相关的传输服务
 */

public class FileClientService {

    /**
     * 发送文件给某人
     * @param srcFile 源文件
     * @param destFile 文件传输到哪里
     * @param senderId 文件发送者
     * @param getterId 文件接收者
     */
    public void sendFileToOne(String srcFile, String destFile, String senderId, String getterId) {
        //读取src文件，要校验文件是否存在
        Message message = new Message();
        message.setMessageType(MessageType.MESSAGE_FILE_MES);
        message.setSrc(srcFile);
        message.setDest(destFile);
        message.setSender(senderId);
        message.setGetter(getterId);
        LocalDateTime dateTime = LocalDateTime.now();
        String formatDateTime = dateTime.format(DateTimeFormatter.ofPattern("YYYY/MM/dd hh:mm:ss"));
        message.setSendTime(formatDateTime);

        //将文件读取
        byte[] bytes = new byte[(int) new File(srcFile).length()]; //根据源文件的大小指定字节数组的空间
        FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(srcFile);
            fileInputStream.read(bytes); //把src源文件读到字节数组里，一次性读取文件大小的字节长度
            message.setFileBytes(bytes); //设置message对象的字节数组
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                fileInputStream.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        //提示信息
        System.out.println("\n" + "你给用户 " + getterId +
                " 发送了一个文件【" + srcFile + "】到对方的电脑目录 " + destFile);
        //发送 从管理客户端连接服务端的线程中拿到对应用户ID的线程对象，得到其持有的socket关联的输出流，来构建对象输出流
        try {
            ObjectOutputStream oos =
                    new ObjectOutputStream(ManageClientConnectServerThread.getClientConnectServerThread(senderId).getSocket().getOutputStream());
                oos.writeObject(message); //把该消息对象通过数据通道写入，让服务端读取
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
