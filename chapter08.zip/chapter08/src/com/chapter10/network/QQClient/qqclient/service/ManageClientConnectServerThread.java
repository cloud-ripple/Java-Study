package com.chapter10.network.QQClient.qqclient.service;

import java.util.HashMap;

/**
 * 日期：2023/3/19
 * 需求/说明：该类管理客户端连接到服务器端的线程
 */

public class ManageClientConnectServerThread {
    //将多个线程放入到一个HashMap集合，key是用户ID，value是线程
    private static HashMap<String, ClientConnectServerThread> map = new HashMap<>();

    //将某个线程加入到集合中
    public static void addClientConnectServerThread(String userId, ClientConnectServerThread connectServerThread) {
        map.put(userId, connectServerThread);
    }

    //通过userId，可以得到一个对应的线程(value)
    public static ClientConnectServerThread getClientConnectServerThread(String userId) {
        return map.get(userId);
    }

}
