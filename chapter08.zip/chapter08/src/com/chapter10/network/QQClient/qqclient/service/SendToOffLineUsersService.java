package com.chapter10.network.QQClient.qqclient.service;

import com.chapter10.network.QQClient.qqcommon.Message;
import com.chapter10.network.QQClient.qqcommon.MessageType;
import com.chapter10.network.QQClient.qqcommon.User;
import com.chapter10.network.QQServer.qqserver.service.ManageClientThreads;
import com.chapter10.network.QQServer.qqserver.service.QQServer;
import com.chapter10.network.QQServer.qqserver.service.ServerConnectClientThread;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 日期：2023/3/22
 * 需求/说明：
 */

public class SendToOffLineUsersService implements Runnable {
    @Override
    public void run() {
        ConcurrentHashMap<String, ArrayList<Message>> offLineUsers = QQServer.getOffLineUsers();

        Collection<ArrayList<Message>> values = offLineUsers.values();

    }
}
