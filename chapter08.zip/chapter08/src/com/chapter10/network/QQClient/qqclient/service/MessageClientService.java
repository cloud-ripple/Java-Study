package com.chapter10.network.QQClient.qqclient.service;

import com.chapter10.network.QQClient.qqcommon.Message;
import com.chapter10.network.QQClient.qqcommon.MessageType;
import com.chapter10.network.QQClient.qqcommon.User;
import com.chapter10.network.QQServer.qqserver.service.QQServer;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 日期：2023/3/21
 * 需求/说明：该类/对象，提供和消息相关的服务方法
 */

public class MessageClientService {

    //私聊
    /**
     * @param content 内容
     * @param senderId 发送用户id
     * @param getterId 接收用户id
     * */
    public static void sendMessageToOne(String content, String senderId, String getterId) {
        //构建message
        Message message = new Message();
        message.setMessageType(MessageType.MESSAGE_COMM_MES); //普通的聊天消息
        message.setSender(senderId);
        message.setGetter(getterId);
        message.setContent(content);
        LocalDateTime dateTime = LocalDateTime.now();
        String formatDateTime = dateTime.format(DateTimeFormatter.ofPattern("YYYY/MM/dd hh:mm:ss"));
        message.setSendTime(formatDateTime);
        System.out.println(senderId + " 对 " + getterId + " 说：" + content + ",私聊信息发送成功");

        User user = new User();
        ConcurrentHashMap<String, ArrayList<Message>> offLineUsers = QQServer.getOffLineUsers();
        ArrayList<Message> list = new ArrayList<>();
        if (!user.isOnline()) {
            list.add(message);
            offLineUsers.put(getterId, list);
        } else {
            //发送给服务端
            try {
                ObjectOutputStream oos = new ObjectOutputStream(ManageClientConnectServerThread.getClientConnectServerThread(senderId).getSocket().getOutputStream());
                oos.writeObject(message);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    //群发消息
    /**
     * @param content 内容
     * @param senderId 发送者 */
    public void sendMessageToAll(String content, String senderId) {
        Message message = new Message();
        message.setMessageType(MessageType.MESSAGE_TO_ALL_MES); //群发消息类型
        message.setSender(senderId);
        message.setContent(content);
        LocalDateTime dateTime = LocalDateTime.now();
        String formatDateTime = dateTime.format(DateTimeFormatter.ofPattern("YYYY/MM/dd hh:mm:ss"));
        message.setSendTime(formatDateTime);
        System.out.println(senderId + " 对所有人说：" + content);
        //发送给服务端
        try {
            ObjectOutputStream oos = new ObjectOutputStream(ManageClientConnectServerThread.getClientConnectServerThread(senderId).getSocket().getOutputStream());
            oos.writeObject(message);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
