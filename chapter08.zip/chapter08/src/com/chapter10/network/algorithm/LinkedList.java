package com.chapter10.network.algorithm;

/**
 * 日期：2023/3/14
 * 需求/说明：
 */

public class LinkedList {
    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();
        linkedList.insert(3, 0);
        linkedList.insert(7, 1);
        linkedList.insert(9, 2);
        linkedList.insert(5, 3);
        linkedList.insert(6, 1);
        linkedList.remove(0);
        linkedList.output();
    }
    /**
     * 链表节点
     * */

    //头节点指针
    private Node head;  //每个节点Node对象中都有 数据域data和指针next属性
    //尾节点指针
    private Node last;
    //链表实际长度
    private int size;

    private static class Node { //节点
        int data; //数据域
        Node next; //指针
        Node(int data) { //构造器初始化数据域
            this.data = data;
        }
    }

    /**
     * 链表插入元素
     * @param data 插入元素
     * @param index 插入位置
     * */
    public void insert(int data, int index) {
        if (index < 0 || index > size) { //插入元素的下标小于0或者超过链表实际长度
            throw new IndexOutOfBoundsException("超出链表节点范围！");
        }
        //如果上面没有超出节点范围，就创建新的插入节点，并把插入元素初始化
        Node insertNode = new Node(data);

        if (size == 0) { //空链表
        //即一个节点都没有，就把插入的节点作为第一个节点，(仅此一个)此时该节点既是头节点，也是尾节点
            head = insertNode;
            last = insertNode;
        } else if (index == 0) { //插入头部 即插入的位置是头节点(第一个节点)
            insertNode.next = head; //头节点赋给插入节点的指针，此时插入节点的指针next指向了头节点
            head = insertNode; //把插入的新节点变成链表头节点
        } else if (size == index) { //插入尾部
            last.next = insertNode; //让尾节点的next指针指向新的插入节点
            last = insertNode; //然后把插入的新节点变成尾节点
        } else { //插入中间
            Node prevNode = get(index - 1); //得到插入位置的前置节点
            insertNode.next = prevNode.next; //原本前置节点的next指针是紧接着指向下一个节点(即插入位置的后置节点)
            //突然在中间加入一个新节点，把前置节点的next指针赋给了新插入节点的next指针，导致新节点指针直接指向原先的后置节点
            prevNode.next = insertNode; //此时又把前置节点的指针重新指向新的插入节点
        }
        size++;
    }

    /**
     * 链表删除元素
     * @param index 删除位置
     * */
    public Node remove(int index) {
        if (index < 0 || index >= size) { //index索引从0开始 到 size-1
            throw new IndexOutOfBoundsException("超出链表节点范围！");
        }
        Node removeNode = null;
        if (index == 0) { //删除头节点
            removeNode = head; //把头节点变成删除节点
            head = head.next; //原先头节点的next指针是继续指向下一个节点的，而把该节点设为链表新的头节点
            //此时的链表头节点就是原先头节点的next指针所指向的节点对象
        } else if (index == size - 1) { //删除尾节点
            Node prevNode = get(index - 1); //先得到尾节点(最后指向null)的前置节点，而该前置节点的next指针是指向尾节点的
            removeNode = prevNode.next; //把尾节点赋给删除节点
            prevNode.next = null; //此时把前置节点指向null
            last = prevNode; //把该前置节点变成尾节点
        } else {
            //删除中间节点
            Node prevNode = get(index - 1); //得到删除位置的前置节点
            Node nextNode = prevNode.next.next; //prevNode.next代表要删除的节点，prevNode.next.next代表要删除节点的后置节点
            //前置节点 --> 删除的节点 --> 后置节点
            removeNode = prevNode.next; //得到要删除的节点
            prevNode.next = nextNode; //把后置节点变成原先的删除节点位，此时前置节点直接指向原先的后置节点，不再指向删除节点
        }
        size--;
        return removeNode; //返回删除的节点
    }

    /**
     * 链表查找元素
     * @param index 查找的位置
     * */
    public Node get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("超出链表节点范围！");
        }
        Node temp = head; //先拿到头节点  只能从头节点开始一个一个逐一查找
        for (int i = 0; i < index; i++) { //在0~查找位置之间遍历
            temp = temp.next; //1. 根据头节点的指针定位到第二个节点
            //2. 根据第二个节点的指针定位到第三个节点...依次类推
        }
        return temp;
    }

    /**
     * 输出链表*/
    public void output() {
        Node temp = head;
        while (temp != null) {
            System.out.println(temp.data);
            temp = temp.next;
        }
    }
}
