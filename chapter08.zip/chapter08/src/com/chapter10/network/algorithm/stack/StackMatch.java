package com.chapter10.network.algorithm.stack;

import java.util.Stack;

/**
 * 日期：2023/4/12
 * 需求/说明：栈应用-括号匹配
 *栈在括号匹配中的算法思想
 * 出现的凡是“左括号”，则进栈；出现的是“右括号”，则首先检查栈是否为空，
 * 若栈空，则表明该“右括号”多余，否则和栈顶元素比较，若相匹配，则栈顶“左括号出栈”，否则表明不匹配；
 * 表达式检验结束时，若栈空，则表明表达式中匹配正确，否则表明“左括号”有余。
 *
 * 假设表达式中包含三种括号：圆括号、方括号和花括号，并且它们可以任意嵌套。
 * 例如{[()]()[{}]}或[{()}([])]等为正确格式，而{[}()]或[({)]为不正确的格式。
 * 那么怎么检测表达式是否正确呢？
 * 这个问题可以用“期待的急迫程度”这个概念来描述。
 * 对表达式中的每一个左括号都期待一个相应的右括号与之匹配，
 * 表达式中越迟出现并且没有得到匹配的左括号期待匹配的程度越高。
 * 不是期待出现的右括号则是不正确的。它具有天然的后进先出的特点。
 * 于是我们可以设计算法：
 * 算法需要一个栈，在读入字符的过程中，如果是左括号，则直接入栈，等待相匹配的同类右括号；
 * 如果是右括号，且与当前栈顶左括号匹配，则将栈顶左括号出栈，如果不匹配则属于不合法的情况。
 * 另外，如果碰到一个右括号，而堆栈为空，说明没有左括号与之匹配，则非法。
 * 那么，当字符读完的时候，如果是表达式合法，栈应该是空的，如果栈非空，
 * 那么则说明存在左括号没有相应的右括号与之匹配，也是非法的情况。
 * 下述算法实现了对该表达式的括号匹配检验：
 */

public class StackMatch {
    public static void main(String[] args) {
        //测试
        System.out.println(match("(){}[]{([()])}")); //输出true 表达式合法
        System.out.println(match("()[]()}")); //输出false 表达式不合法
        System.out.println(match("{[()]()[{}]}")); //true
        System.out.println(match("{[()]}}")); //false
    }

    /**
     * @param expression 括号表达式
     * @return 栈是否为空
     */
    //括号匹配
    public static boolean match(String expression) {
        //1.先创建一个栈
        Stack<Character> stack = new Stack<>();
        //2.循环遍历表达式的每个字符
        for (int i = 0; i < expression.length(); i++) {
            char ch = expression.charAt(i); //得到表达式中的每个字符
            //3.判断
            switch (ch) {
                case ')':   //pop()方法，删除栈顶元素，并返回
                    if (!stack.empty() && stack.pop() == '(') {
                        break; //当栈不为空，且当前栈顶元素为左括号类型时，退出switch语句，继续下一轮判断比较
                    } else {
                        return false;  //否则直接退出方法，返回false，代表不合法表达式
                    }
                case ']':
                    if (!stack.empty() && stack.pop() == '[') {
                        break;
                    } else {
                        return false;
                    }
                case '}':
                    if (!stack.empty() && stack.pop() == '{') {
                        break;
                    } else {
                        return false;
                    }
                default:  //以上情况都没有，说明该字符不是右括号类型，而是左括号类型，直接把元素压入栈中
                    stack.push(ch);  //push()方法，把元素添加到栈中，并返回
                    break;
            }
        }
        return stack.empty();  //字符读完的时候，如果是表达式合法，栈应该是空的，如果栈非空，
                                //那么则说明存在左括号没有相应的右括号与之匹配，也是非法的情况。
    }
}
