package com.chapter10.network.algorithm.stack;

import java.util.Stack;

/**
 * 日期：2023/4/12
 * 需求/说明：栈应用-进制转换
 */

public class StackConversion {
    public static void main(String[] args) {
        //测试
        conversion(125);
        System.out.println();
        conversion(2007);
    }

    //以10进制转为8进制为例
    public static void conversion(int num) {
        //1.先创建一个栈
        Stack<Integer> stack = new Stack<>();
        //2.把该数模8的值放入栈中，然后让该数除以8
        while (num != 0) {
            Integer push = stack.push(num % 8); // 1 % 8 = 1
            num /= 8; // 1 / 8 = 0
            //System.out.println(push); //输出入栈的元素
        }

        while (!stack.empty()) {
            System.out.print(stack.pop()); //依次从栈顶取出，组合和起来即为转换后的8进制值
        }

    }
}
