package com.chapter10.network.algorithm.stack;

public class Stack04 {
    public static void main(String[] args) throws Exception {
        LinkedStack linkedStack = new LinkedStack();
        linkedStack.push("1");
        linkedStack.push("2");
        linkedStack.push("3");

        while (!linkedStack.isEmpty()) {
            System.out.println(linkedStack.pop());
        }


    }
}

/**
 * 栈的特点是先进后出：
 * 因此我们可以使用头插法，每次在头部插入，出栈时只需获取链表的头结点即可。
 * <p>
 * 链栈与顺序栈的区别：
 * 顺序栈底层是数组，因此必须初始化一个数组的容量，也就是栈的容量，链栈则无需此操作
 * 对比链栈和顺序栈的实现，可以发现入栈和出战方法的时间复杂度都是O（1），效率上没有区别，但是顺序栈占用的空间会相对更多
 * 一些，顺序栈是通过指针指向假设的栈顶，其他元素其实依然存在，但链栈的栈顶之前的元素会被垃圾回收，因此链栈的实现综合时间和
 * 空间来看，更优秀一些。
 */
class LinkedStack implements IStack {
    //这是首结点
    Node node;

    public LinkedStack() {
        node = new Node();
    }

    @Override
    public void clear() {
        node.next = null;
        node.object = null;
    }

    @Override
    public boolean isEmpty() {
        return node.object == null ? true : false;
    }

    @Override
    public int length() {
        if (node.object == null)
            return 0;
        int j = 1;
        Node nodeNew = node;
        while (nodeNew.next != null) {
            j++;
            nodeNew = nodeNew.next;
        }
        return j;
    }

    @Override
    public Object peek() {
        return node.object;
    }

    @Override
    public void push(Object object) throws Exception {
        if (node.object == null) {
            node.object = object;
            return;
        }
        //头插法
        node = new Node(object, node);
    }

    @Override
    public Object pop() {
        if (node.object == null)
            return null;
        Node tem = node;
        node = node.next == null ? new Node() : node.next;
        return tem.object;
    }
}


//节点类
class Node {
    public Object object;
    public Node next;

    public Node() {
    }

    public Node(Object object) {
        this.object = object;
    }

    public Node(Node next) {
        this.next = next;
    }

    public Node(Object object, Node next) {
        this.object = object;
        this.next = next;
    }

    @Override
    public String toString() {
        return "Node{" +
                "object=" + object +
                ", next=" + next +
                '}';
    }
}

/**
 * 该接口是：栈的顶层接口
 * 他的实现类会有：顺序栈、链栈
 * <p>
 * 栈：先入后出
 */
interface IStack {
    void clear();//清空方法

    boolean isEmpty();//判空方法

    int length();//栈深度方法

    Object peek();//取栈顶元素并返回值，若栈为空，返回null

    void push(Object object) throws Exception;//入栈操作,元素进入栈顶

    Object pop();//将栈顶元素出站
}
