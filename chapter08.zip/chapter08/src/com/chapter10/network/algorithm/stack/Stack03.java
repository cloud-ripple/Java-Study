package com.chapter10.network.algorithm.stack;

import java.util.Stack;

/**
 * 日期：2023/4/10
 * 需求/说明：顺序栈的实现-Java的 Collection集合 中自带的"栈"(stack)的示例
 */

public class Stack03 {
    public static void main(String[] args) {
        int tmp = 0;
        Stack<Integer> stack = new Stack<Integer>();

        // 将10, 20, 30 依次推入栈中
        stack.push(10);
        stack.push(20);
        stack.push(30);

        // 将“栈顶元素”赋值给tmp，并删除“栈顶元素”
        tmp = stack.pop();
        //System.out.printf("tmp=%d\n", tmp);

        // 只将“栈顶”赋值给tmp，不删除该元素.
        tmp = (int) stack.peek();
        //System.out.printf("tmp=%d\n", tmp);

        stack.push(40);
        while (!stack.empty()) {
            tmp = (int) stack.pop();
            System.out.printf("tmp=%d\n", tmp);
        }
    }
}
