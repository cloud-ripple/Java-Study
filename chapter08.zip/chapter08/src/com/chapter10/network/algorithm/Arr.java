package com.chapter10.network.algorithm;

/**
 * 日期：2023/3/15
 * 需求/说明：
 */

public class Arr {
    private int[] array;
    private int size;
    public Arr(int capacity) {
        this.array = new int[capacity];
        size = 0;
    }

    /**
     * 数组插入元素
     * @param index 插入的位置
     * @param element 插入的元素
     * */
    public void insert(int index, int element) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("超出数组实际元素范围");
        }
        //如果实际元素达到数组容量上限，则对数组进行扩容
        if (size >= array.length) {
            resize();
        }
        //从右向左循环，将元素逐个向右挪1位
        for (int i = size - 1; i >= index; i--) {
            array[i + 1] = array[i];
        }
        //腾出的位置放入新元素
        array[index] = element;
        size++;
    }
    //数组扩容
    public void resize() {
        int[] newArr = new int[array.length * 2];
        //从旧数组复制到新数组
        System.arraycopy(array, 0, newArr, 0, array.length);
        array = newArr;
    }
    //输出数组
    public void output() {
        for (int i = 0; i < size; i++) {
            System.out.println(array[i]);
        }
    }

    public static void main(String[] args) {

    }

    //数组删除元素
    public int delete(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("超出访问范围");
        }
        int deleteElement = array[index];
        //从左向右循环，将元素逐个向左挪1位
        for (int i = index; i < size -1; i++) {
            array[i] = array[i + 1];
        }
        size--;
        return deleteElement;
    }
}
