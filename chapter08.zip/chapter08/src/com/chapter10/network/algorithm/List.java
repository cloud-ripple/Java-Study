package com.chapter10.network.algorithm;

/**
 * 日期：2023/3/15
 * 需求/说明：
 */

public interface List<E> {
    boolean add(E item); //添加元素
    boolean add(int index, E item);//插入元素
    E remove(int index); //删除元素
    int indexOf(E item); //定位元素
    E get(int index); //取表元素
    int size(); //求线性表长度
    void clear();//清空线性表
    boolean isEmpty(); //判断线性表是否为空
}
