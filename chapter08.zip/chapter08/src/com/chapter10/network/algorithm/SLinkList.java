package com.chapter10.network.algorithm;

/**
 * 日期：2023/3/15
 * 需求/说明：线性表的实现方式-单链表
 */

public class SLinkList<E> implements List<E> {
    private Node<E> start;// 单链表的头引用
    int size;// 单链表的长度

    private static class Node<E> {
        E item;
        Node<E> next;

        Node(E element, Node<E> next) {
            this.item = element;
            this.next = next;
        }
    }

    // 初始化线性表
    public SLinkList() {
        start = null;
    }
    // 添加元素，将元素添加在单链表的末尾
    public boolean add(E item) {
        if (start == null) {
            start = new Node<E>(item, null);
        } else {
            Node<E> current = start;
            while (current.next != null) {
                current = current.next;
            }
            current.next = new Node<E>(item, null);
        }
        size++;
        return true;
    }
    // 在单链表的第index索引位置前插入一个数据元素
    public boolean add(int index, E item) {
        Node<E> current;
        Node<E> previous;
        if (index < 0 || index > size) {
            return false;
        }
        Node<E> newNode = new Node<E>(item, null);
        // 在空链表或第一个元素前插入第一个元素
        if (index == 0) {
            newNode.next = start;
            start = newNode;
            size++;
        } else {
            // 单链表的两个元素间插入一个元素
            current = start;
            previous = null;
            int j = 0;
            while (current != null && j < index) {
                previous = current;
                current = current.next;
                j++;
            }
            if (j == index) {
                previous.next = newNode;
                newNode.next = current;
                size++;
            }
        }
        return true;
    }
    // 删除单链表中的索引位置为index的数据元素
    public E remove(int index) {
        E oldValue = null;
        if (isEmpty() || index < 0 || index > size - 1) {
            oldValue = null;
        }
        Node<E> current = start;
        if (index == 0) {
            oldValue = current.item;
            start = current.next;
            size--;
        } else {
            Node<E> previous = null;
            int j = 1;
            while (current.next != null && j <= index) {
                previous = current;
                current = current.next;
                j++;
            }
            previous.next = current.next;
            oldValue = current.item;
            current = null;
            size--;
        }
        return oldValue;
    }
    // 在单链表中查找数据元素item数据位置
    public int indexOf(E item) {
        int index = 0;
        if (item == null) {
            for (Node<E> x = start; x != null; x = x.next) {
                if (x.item == null)
                    return index;
                index++;
            }
        } else {
            for (Node<E> x = start; x != null; x = x.next) {
                if (item.equals(x.item))
                    return index;
                index++;
            }
        }
        return -1;
    }
    // 获得单链表的第index索引位置的数据元素
    public E get(int index) {
        E item = null;
        if (isEmpty() || index < 0 || index > size - 1) {
            item = null;
        }
        Node<E> current = start;
        int j = 0;
        while (current.next != null && j < index) {
            current = current.next;
            j++;
        }
        if (j == index) {
            item = current.item;
        }
        return item;
    }
    //求单链表长度
    public int size() {
        return size;
    }
    //清空单链表
    public void clear() {
        for (Node<E> x = start; x != null;) {
            Node<E> next = x.next;
            x.item = null;
            x.next = null;
            x = next;
        }
        start = null;
        size = 0;
    }
    //判断单链表是否为空
    public boolean isEmpty() {
        return size == 0;
    }

}