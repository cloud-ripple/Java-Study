package com.chapter10.network;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 日期：2023/3/13
 * 需求/说明：服务端
 *1.编写一个服务端，和一个客户端
 *2.服务端在9999端口监听
 *3.客户端连接到服务端，发送一张图片
 *4.服务器端接收到客户端发送的图片，保存到 src下，发送 "收到图片"再退出
 *5.客户端接收到服务端发送的"收到图片"，再退出
 */

public class SocketTCPServer03 {
    public static void main(String[] args) throws IOException {
        //服务端在监听8888端口  先运行此程序 后DOS下 输入 netstat -an 命令即可查看端口监听状况
        ServerSocket serverSocket = new ServerSocket(8888);
        System.out.println("本机8888端口正在监听中...");
        Socket socket = serverSocket.accept();

        InputStream inputStream = socket.getInputStream(); //服务端到客户端的输入流，用于读取由客户端通过数据通道发送过来的数据
        BufferedInputStream bis = new BufferedInputStream(inputStream);

        String src = "D:\\idea_java_project\\chapter08\\src\\bobo.jpg"; //读取客户端发送过来的图片并拷贝写入到此文件中
        FileOutputStream fileOutputStream = new FileOutputStream(src);
        BufferedOutputStream bos = new BufferedOutputStream(fileOutputStream);

        //边读边写
        byte[] buf = new byte[1024];
        int readLen = 0;
        while ((readLen = bis.read(buf)) != -1) {
            bos.write(buf, 0, readLen); //写入图片到其它文件夹中
        }

        OutputStream outputStream = socket.getOutputStream(); //服务端到客户端的输出流，从数据通道写入数据
        outputStream.write("收到图片".getBytes()); //向客户端写入数据(发送)
        socket.shutdownOutput(); //写入结束标记  通过数据通道写入时，必须设置写入结束标记

        bis.close();
        bos.close();

        outputStream.close();

        socket.close();
        serverSocket.close();
        System.out.println("服务端退出");
    }
}
