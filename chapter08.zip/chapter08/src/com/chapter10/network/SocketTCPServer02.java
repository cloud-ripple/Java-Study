package com.chapter10.network;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 日期：2023/3/13
 * 需求/说明：TCP字符流编程
 * 服务端
 * 1.编写一个服务器端和一个客户端
 *  * 2.服务器端在9999端口监听
 *  * 3.客户端连接到服务器端，发送 “hello, server"，并接收服务器端回发的"hello,client"，再退出
 *  * 4.服务器端接收到 客户端发送的信息，输出，并发送 "hello,client"，再退出
 */

public class SocketTCPServer02 {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(9090);
        System.out.println("服务端，在" + serverSocket.getLocalPort() + " 端口监听，等待连接");

        Socket socket = serverSocket.accept();

        //读取由客户端通过数据通道写入的数据
        InputStream inputStream = socket.getInputStream();
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
        String s = bufferedReader.readLine();
        System.out.println(s);

        //服务端通过数据通道写入数据
        OutputStream outputStream = socket.getOutputStream();
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
        BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
        bufferedWriter.write("server: hello, client 字符流");
        bufferedWriter.newLine(); //插入一个换行符，表示写入的内容结束
        /** 要求对方使用readLine()方法来读取，否则客户端读取不到结束符 */
        bufferedWriter.flush(); //如果使用的字符流，需要手动刷新，否则数据不会写入数据通道

        //socket.shutdownOutput(); //和newLine()方法等价，都是设置写入结束标记

        //关闭流
        bufferedWriter.close(); //关闭外层流
        bufferedReader.close();
        socket.close();
        serverSocket.close();
        System.out.println("服务端退出");

    }
}
