package com.chapter10.network.QQServer.qqframe;

import com.chapter10.network.QQServer.qqserver.service.QQServer;

/**
 * 日期：2023/3/19
 * 需求/说明：该类创建QQServer，启动后台服务
 */

public class QQFrame {
    public static void main(String[] args) {
        new QQServer();
        //1.离线留言和发文件
        //1.当有客户端发送消息或文件，如果用户不在线
        //2.登陆后可以接收离线的消息或文件
    }
}
