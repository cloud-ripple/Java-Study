package com.chapter10.network.QQServer.qqserver.service;

import com.chapter10.network.QQClient.qqcommon.Message;
import com.chapter10.network.QQClient.qqcommon.MessageType;
import com.chapter10.network.QQClient.qqcommon.User;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 日期：2023/3/19
 * 需求/说明：服务端连接客户端的线程-该类的一个对象和某个客户端保持通信
 */

public class ServerConnectClientThread extends Thread {
    private Socket socket = null;
    private String userId; //连接到服务端的用户ID

    public ServerConnectClientThread(Socket socket, String userId) {
        this.socket = socket;
        this.userId = userId;
    }

    public Socket getSocket() {
        return socket;
    }

    @Override
    public void run() { //这里线程处于run的状态，可以发送/接收消息
        while (true) {
            try {
                System.out.println("\n服务端和客户端 " + userId + "保持通信，读取数据..");
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                Message message = (Message) ois.readObject();
                //这里就是已经有一个用户连接到服务器上了，通过userId服务器找到对应需要发送消息的用户
                //服务器接收到用户的message后就可以利用get方法找到接收方
                //根据message的消息类型，做相应的业务处理
                if (message.getMessageType().equals(MessageType.MESSAGE_GET_ONLINE_FRIEND)) {
                    //客户端要拉取在线用户列表  按照形式：韩立 韩立 123456
                    System.out.println(message.getSender() + " 要在线用户列表");
                    String onlineUser = ManageClientThreads.getOnlineUser();

                    //返回message,构建一个Message对象，返回给客户端
                    Message message2 = new Message();
                    message2.setMessageType(MessageType.MESSAGE_RET_ONLINE_FRIEND); //设置消息类型
                    message2.setContent(onlineUser); //填充在线用户
                    message2.setGetter(message.getSender()); //
                    //写入数据通道，返回给客户端
                    ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                    oos.writeObject(message2);

                } else if (message.getMessageType().equals(MessageType.MESSAGE_COMM_MES)) { //私聊类型
                    //根据message获取getter接收用户ID，然后得到对应的线程
                    ServerConnectClientThread connectClientThread = ManageClientThreads.getConnectClientThread(message.getGetter());
                    //得到对应的socket的对象输出流，将message对象转发给指定的客户端
                    ObjectOutputStream oos = new ObjectOutputStream(connectClientThread.getSocket().getOutputStream());
                    oos.writeObject(message);

                } else if (message.getMessageType().equals(MessageType.MESSAGE_TO_ALL_MES)) { //群发类型
                    //需要遍历 管理线程的集合，把所有的线程的socket得到，然后把message进行转发即可
                    HashMap<String, ServerConnectClientThread> map = ManageClientThreads.getMap();

                    Iterator<String> iterator = map.keySet().iterator();
                    while (iterator.hasNext()) { //循环遍历
                        //取出在线用户ID
                        String onlineUserId = iterator.next();
                        if (!onlineUserId.equals(message.getSender())) { //排除群发消息的这个用户
                            //进行转发message
                            ObjectOutputStream oos = new ObjectOutputStream(map.get(onlineUserId).getSocket().getOutputStream());
                            oos.writeObject(message);
                        }
                    }
                } else if (message.getMessageType().equals(MessageType.MESSAGE_FILE_MES)) {
                    //根据接收者的用户ID 从管理服务端连接客户端的线程中拿到其对应的线程，构建对象输出流将从客户端读取到的message对象原封转发给客户端
                    ServerConnectClientThread connectClientThread = ManageClientThreads.getConnectClientThread(message.getGetter());
                    ObjectOutputStream oos = new ObjectOutputStream(connectClientThread.getSocket().getOutputStream());
                    oos.writeObject(message); //把带有文件相关参数的message转发回复给客户端

                } else if (message.getMessageType().equals(MessageType.MESSAGE_CLIENT_EXIT)){ //客户端要求退出
                    System.out.println("\n" + message.getSender() + " 退出");
                    //将这个客户端用户对应的线程，从集合中删除
                    Thread.sleep(50);
                    ManageClientThreads.removeClientThread(message.getSender());
                    socket.close(); //关闭当前线程持有的socket连接
                    break; //退出while循环，即退出线程
                } else {
                    System.out.println("其它消息类型，暂时不处理");
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
}
