package com.chapter10.network.QQServer.qqserver.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

/**
 * 日期：2023/3/19
 * 需求/说明：该类用于管理和客户端通信的线程
 */

public class ManageClientThreads {
    //key 是userId， value 是userId对应的线程
    private static HashMap<String, ServerConnectClientThread> map = new HashMap<>();

    //获取线程集合
    public static HashMap<String, ServerConnectClientThread> getMap() {
        return map;
    }

    //添加服务端连接客户端的线程 对象到集合中
    public static void addClientThread(String userId, ServerConnectClientThread connectClientThread) {
        map.put(userId, connectClientThread);
    }

    //从集合中删除某个线程，根据指定的用户ID删除对应的 服务端连接客户端的线程
    public static void removeClientThread(String userId) {
        map.remove(userId);
    }

    //根据userId获取和客户端保持通信的对应线程
    public static ServerConnectClientThread getConnectClientThread(String userId) {
        return map.get(userId);
    }

    //编写方法，可以返回在线用户列表
    public static String getOnlineUser() {
        //集合遍历，hashMap的key
        Set<String> keySet = map.keySet();
        Iterator<String> iterator = keySet.iterator();
        String onlineUser = "";
        while (iterator.hasNext()) {
            onlineUser += iterator.next().toString() + " ";
        }
        return onlineUser;
    }
}
