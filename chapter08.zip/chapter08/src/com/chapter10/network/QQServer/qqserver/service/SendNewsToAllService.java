package com.chapter10.network.QQServer.qqserver.service;

import com.chapter10.network.QQClient.qqclient.utils.Utility;
import com.chapter10.network.QQClient.qqcommon.Message;
import com.chapter10.network.QQClient.qqcommon.MessageType;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Iterator;

/**
 * 日期：2023/3/22
 * 需求/说明：服务器推送新闻
 */

public class SendNewsToAllService implements Runnable {
    @Override
    public void run() {
        while (true) {
            System.out.print("请输入服务器要推送的新闻或消息[输入 exit 停止推送]：\n");
            String news = Utility.readString(200);
            if ("exit".equals(news)) {
                break;
            }
            //构建一个message对象 群发
            Message message = new Message();
            message.setSender("服务器");
            message.setContent(news);
            message.setMessageType(MessageType.MESSAGE_TO_ALL_MES); //不设置消息类型的话，客户端会出现空指针异常
            LocalDateTime dateTime = LocalDateTime.now();
            String formatDateTime = dateTime.format(DateTimeFormatter.ofPattern("YYYY/MM/dd hh:mm:ss"));
            message.setSendTime(formatDateTime);
            System.out.println("服务器推送了一条消息：" + news);
            //遍历当前所有的通信线程
            HashMap<String, ServerConnectClientThread> map = ManageClientThreads.getMap(); //得到服务端连接客户端线程的集合
            Iterator<String> iterator = map.keySet().iterator();
            while (iterator.hasNext()) {
                String userId = iterator.next();
                try {
                    ObjectOutputStream oos = new ObjectOutputStream(map.get(userId).getSocket().getOutputStream());
                    oos.writeObject(message);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
