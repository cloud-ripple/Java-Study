package com.chapter10.network.QQServer.qqserver.service;

import com.chapter10.network.QQClient.qqcommon.Message;
import com.chapter10.network.QQClient.qqcommon.MessageType;
import com.chapter10.network.QQClient.qqcommon.User;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 日期：2023/3/19
 * 需求/说明：这是服务器，在监听9999，等待客户端的连接，并保持通信
 */

public class QQServer {

    private ServerSocket serverSocket = null;

    //创建一个集合，存放多个用户，如果是这些用户登录，就认为是合法
    //HashMap 没有处理线程安全，因此在多线程情况下是不安全的
    //ConcurrentHashMap 可以处理并发的集合，处理的线程安全，即线程同步处理，在多线程情况下是安全的
    private static ConcurrentHashMap<String, User> validUsers = new ConcurrentHashMap<>();
    private static ConcurrentHashMap<String, ArrayList<Message>> offLineUsers = new ConcurrentHashMap<>();

    public static ConcurrentHashMap<String, ArrayList<Message>> getOffLineUsers() {
        return offLineUsers;
    }

    public static void setOffLineUsers(ConcurrentHashMap<String, ArrayList<Message>> offLineUsers) {
        QQServer.offLineUsers = offLineUsers;
    }

    public static ConcurrentHashMap<String, User> getValidUsers() {
        return validUsers;
    }

    public static void setValidUsers(ConcurrentHashMap<String, User> validUsers) {
        QQServer.validUsers = validUsers;
    }

    static { //初始化一次
        validUsers.put("100", new User("100", "123456"));
        validUsers.put("200", new User("200", "123456"));
        validUsers.put("300", new User("300", "123456"));
        validUsers.put("韩立", new User("韩立", "123456"));
        validUsers.put("忘语", new User("忘语", "123456"));
    }

    //验证用户是否有效的方法
    private boolean checkUser(String userId, String password) {
        User user = validUsers.get(userId); //通过key获取value
        if (user == null) { //说明userId没有存在集合validUsers的key中
            return false;
        }
        if (!user.getPassword().equals(password)) { //userId存在集合中，但是密码错误
            return false;
        }
        return true;
    }

    public QQServer() {
        //注意：端口可以写在配置文件
        try {
            System.out.println("服务端在9999端口监听..");
            //启动服务器推送新闻的线程
            new Thread(new SendNewsToAllService()).start();
            serverSocket = new ServerSocket(9999);

            while (true) { //当和某个客户端连接后，会保持继续监听,并不是只监听一次。会有多个客户端
                Socket socket = serverSocket.accept(); //循环监听，如果没有客户端连接，就会阻塞在这里，下面的不会执行
                //得到Socket关联的对象输入流,用于读取客户端通过数据通道写入的用户信息
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                //得到Socket关联的对象输出流，用于写入回复信息，让客户端那边去读取
                ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());

                User user = (User) ois.readObject(); //读取客户端发送过来的User对象
                Message message = new Message(); //创建一个Message对象，准备回复客户端，不管是否登录成功，都要回复消息给客户端

                //验证(从数据库)  先自己指定用户ID和密码，可以用HashMap来模拟数据库
                if (checkUser(user.getUserId(), user.getPassword())) { //合法用户
                    message.setMessageType(MessageType.MESSAGE_LOGIN_SUCCEED); //修改回复消息类型为登录成功状态
                    user.setOnline(true);
                    //然后将message对象回复客户端，通过对象输出流写入数据通道Socket
                    oos.writeObject(message); //回复
                    //此时创建一个线程，并指定用户ID，socket，和客户端保持通信，该线程需要持有Socket对象
                    ServerConnectClientThread connectClientThread = new ServerConnectClientThread(socket, user.getUserId());
                    connectClientThread.start(); //启动线程
                    //把该userId对应的线程对象放到集合中，进行管理
                    ManageClientThreads.addClientThread(user.getUserId(), connectClientThread);
                } else { //登录失败
                    System.out.println("用户ID = " + user.getUserId() + " pwd = " + user.getPassword() + " 验证失败");
                    message.setMessageType(MessageType.MESSAGE_LOGIN_FAIL); //修改回复消息类型为登录失败状态
                    oos.writeObject(message); //回复
                    //关闭socket
                    socket.close();
                }
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            //如果服务端退出了上面的while循环，说明服务器不在继续监听，因此需要关闭ServerSocket
            try {
                serverSocket.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
