package com.chapter10.network.homework03;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 日期：2023/3/14
 * 需求/说明：
 * 1.编写客户端和服务端程序
 *  * 2.客户端可以输入一个音乐文件名，比如 张子琪的 透明，
 *  * 服务端收到音乐名后，可以给客户端返回这个音乐文件，如果服务器没有这个文件，返回一个默认的音乐即可
 *  * 3.客户端收到文件后，保存到本地 d:\\
 */

public class Server {
    public static void main(String[] args) throws IOException {
        //1. 服务端监听3456端口
        ServerSocket serverSocket = new ServerSocket(3456);
        System.out.println("服务端在3456端口等待监听");
        //2. 等待客户端连接
        // 当没有客户端连接3456端口时，程序会阻塞，等待连接
        // 如果有客户端连接，则会返回Socket对象，程序继续
        Socket socket = serverSocket.accept();

        OutputStream out = socket.getOutputStream();
        InputStream input = socket.getInputStream();

        int readLen = 0;
        byte[] buf = new byte[1024];
        String content = null;
        while ((readLen = input.read(buf)) != -1) {
            content = new String(buf, 0, readLen);
            System.out.println("服务端接收到了由客户端发送过来的音乐文件名：" + content);
        }

        File file = new File("src\\" + content);
        FileInputStream fileInputStream = new FileInputStream(file);
        buf = new byte[1024];
        readLen = 0;

        if (file.exists()) {
            while ((readLen = fileInputStream.read(buf)) != -1) {
                out.write(buf, 0, readLen);
            }
            socket.shutdownOutput();
            System.out.println("服务端有此音乐文件，并已发送给了客户端");
        } else {
            System.out.println(file.getName() + " 文件不存在");
        }

        out.close();
        input.close();
        fileInputStream.close();
        socket.close();
        serverSocket.close();
        System.out.println("服务端退出");
    }
}
