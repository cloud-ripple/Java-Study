package com.chapter10.network.homework03;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

/**
 * 日期：2023/3/14
 * 需求/说明：
 * 1.编写客户端和服务端程序
 *  * 2.客户端可以输入一个音乐文件名，比如 张子琪的 透明，
 *  * 服务端收到音乐名后，可以给客户端返回这个音乐文件，如果服务器没有这个文件，返回一个默认的音乐即可
 *  * 3.客户端收到文件后，保存到本地 d:\\
 */

public class Client {
    public static void main(String[] args) throws IOException {
        //1. 客户端连接本机3456端口
        Socket socket = new Socket(InetAddress.getLocalHost(), 3456);

        OutputStream out = socket.getOutputStream();
        InputStream input = socket.getInputStream();

        System.out.print("请输入你在服务端(本项目src目录下)想要查找的文件名：");
        String key = new Scanner(System.in).next();
        out.write(key.getBytes());
        //out.write("tank.wav".getBytes());
        socket.shutdownOutput();

        //String filePath = "d:\\tank_copy2.wav";
        String filePath = "d:\\" + key;
        FileOutputStream fileOut = new FileOutputStream(filePath);
        int readLen = 0;
        byte[] buf = new byte[1024];
        while ((readLen = input.read(buf)) != -1) {
            fileOut.write(buf, 0, readLen);
        }
        System.out.println("文件保存在d盘下，成功");

        out.close();
        input.close();
        fileOut.close();
        socket.close();

        System.out.println("客户端退出");
    }
}
