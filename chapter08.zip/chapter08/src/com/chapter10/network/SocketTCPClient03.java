package com.chapter10.network;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

/**
 * 日期：2023/3/13
 * 需求/说明：客户端
 *1.编写一个服务端，和一个客户端
 *  *2.服务端在9999端口监听
 *  *3.客户端连接到服务端，发送一张图片
 *  *4.服务器端接收到客户端发送的图片，保存到 src下，发送 "收到图片"再退出
 *  *5.客户端接收到服务端发送的"收到图片"，再退出
 */

public class SocketTCPClient03 {
    public static void main(String[] args) throws IOException {
        //建立与服务端的数据通道  客户端连接服务端8888端口，得到Socket对象
        Socket socket = new Socket(InetAddress.getLocalHost(), 8888); //与本地主机连接

        String filePath = "d:\\flower.jpg";
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(filePath)); //文件输入流

        OutputStream outputStream = socket.getOutputStream(); //客户端到服务端的输出流
        BufferedOutputStream bos = new BufferedOutputStream(outputStream); //缓冲输出流

        //先读取d盘下的图片文件，一边读一边写入数据通道，然后服务端从数据通道读取
        byte[] buf = new byte[1024];
        int readLen = 0;
        while ((readLen = bis.read(buf)) != -1) {
            bos.write(buf, 0, readLen);
        }

        socket.shutdownOutput(); //循环结束，即读取完毕，设置数据通道写入结束标志
        //通过数据通道写入时，必须设置写入结束标记

        InputStream inputStream = socket.getInputStream(); //客户端到服务端的输入流，用于读取由服务端通过数据通道发送过来的数据
        readLen = 0;
        buf = new byte[1024];
        while ((readLen = inputStream.read(buf)) != -1) { //读取服务端写入的 "收到图片"后，直接输出
            System.out.println(new String(buf, 0, readLen));
        }

        //关闭流
        bis.close();
        outputStream.close();
        inputStream.close();
        //bos.close(); //缓冲输出流通过数据通道写入数据时，不能关闭或刷新

        socket.close();
        System.out.println("客户端退出");
    }
}
