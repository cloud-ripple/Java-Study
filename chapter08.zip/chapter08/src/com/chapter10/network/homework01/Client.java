package com.chapter10.network.homework01;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

/**
 * 日期：2023/3/14
 * 需求/说明：
 * 1.使用字符流的方式，编写一个客户端程序和服务器端程序
 * 2.客户端发送”name",服务器端接收到后。返回“我是 nova”，nova是你自己的名字
 * 3.客户端发送 “hobby”，服务器端接收到后。返回 “编写java程序”
 * 4.不是这两个问题，回复“你说啥尼”
 */

//客户端
public class Client {
    public static void main(String[] args) throws IOException {
        //1.创建Socket对象，在本机7777端口建立数据通道
        Socket socket = new Socket(InetAddress.getLocalHost(), 7777);

        //2.通过数据通道Socket对象，获取客户端的输出流，用于向服务端发送数据
        OutputStream outs = socket.getOutputStream();
        OutputStreamWriter writer = new OutputStreamWriter(outs); //字符转换流 --> 字符输出流
        BufferedWriter bw = new BufferedWriter(writer); //缓冲字符输出流

        //3.客户端的输入流，用于读取服务端通过数据通道写入的数据
        InputStream ins = socket.getInputStream(); //字节输入流
        InputStreamReader reader = new InputStreamReader(ins); //字符转换流--> 字符输入流
        BufferedReader br = new BufferedReader(reader); //缓冲字符输入流


        //写入 和 读取
        while (true) {
            System.out.print("请输入你的问题：");
            String key = new Scanner(System.in).next();
            if ("不问了".equals(key)) {
                break;
            }
            bw.write(key);
            bw.newLine();
            bw.flush();

            String str = br.readLine();
            System.out.println(str);
        }

        bw.close();
        br.close();
        socket.close();
        System.out.println("客户端退出");
    }
}


