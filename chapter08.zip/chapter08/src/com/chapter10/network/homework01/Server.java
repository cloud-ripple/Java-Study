package com.chapter10.network.homework01;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 日期：2023/3/14
 * 需求/说明：
 * 1.使用字符流的方式，编写一个客户端程序和服务器端程序
 * 2.客户端发送”name",服务器端接收到后。返回“我是 nova”，nova是你自己的名字
 * 3.客户端发送 “hobby”，服务器端接收到后。返回 “编写java程序”
 * 4.不是这两个问题，回复“你说啥尼”
 */

//服务端
public class Server {
    public static void main(String[] args) throws IOException {
        //1.创建ServerSocket对象，服务端在7777端口监听
        ServerSocket serverSocket = new ServerSocket(7777);
        System.out.println("服务端在7777端口等待监听...");

        //2.accept()方法返回一个Socket对象，数据通道
        Socket socket = serverSocket.accept();

        //3.由Socket对象构建服务端的输入流，用于读取客户端通过数据通道发送过来的数据
        InputStream ins = socket.getInputStream(); //字节输入流
        InputStreamReader reader = new InputStreamReader(ins); //字符转换流--> 字符输入流
        BufferedReader br = new BufferedReader(reader); //缓冲字符输入流

        //4.由Socket对象构建服务端的输出流，用于写入数据 到数据通道让客户端来读取
        OutputStream outs = socket.getOutputStream();
        OutputStreamWriter writer = new OutputStreamWriter(outs); //字符转换流 --> 字符输出流
        BufferedWriter bw = new BufferedWriter(writer); //缓冲字符输出流

        //读取 和 写入
        String line = "";
        while ((line = br.readLine()) != null) { //循环读取客户端发送的数据
            if ("name".equals(line)) { //如果客户端发送过来的是 name
                bw.write("我是 啵啵"); //把回复内容写入数据通道，让客户端读取
            } else if ("hobby".equals(line)) {
                bw.write("喜欢打篮球");
            } else {
                bw.write("你说啥尼");
            }
            bw.newLine();
            bw.flush();
            System.out.println("服务端接收到了客户端发送的问题 = " + line);
        }


        br.close();
        bw.close();
        socket.close();
        serverSocket.close();
        System.out.println("服务端退出");
    }
}
