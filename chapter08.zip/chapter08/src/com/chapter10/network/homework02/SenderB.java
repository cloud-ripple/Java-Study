package com.chapter10.network.homework02;

import java.io.IOException;
import java.net.*;

/**
 * 日期：2023/3/14
 * 需求/说明：
 * 1.编写一个接收端A，和一个发送端B，使用UDP协议完成
 *  * 2.接收端在8888端口等待接收数据(receive)
 *  * 3.发送端向接收端发送数据 “四大名著是哪些”
 *  * 4.接收端收到发送端发送的 问题后，返回 “四大名著是....”，否则返回what?
 */

public class SenderB {
    public static void main(String[] args) throws IOException {
        DatagramSocket socket = new DatagramSocket(1111);
        //发送数据
        byte[] data = "四大名著是哪些".getBytes();
        DatagramPacket packet = new DatagramPacket(data, data.length, InetAddress.getLocalHost(), 8888);
        socket.send(packet);

        //接收回复
        data = new byte[1024];
        packet = new DatagramPacket(data, data.length);
        socket.receive(packet);
        System.out.println(new String(packet.getData(), 0, packet.getLength()));
    }
}
