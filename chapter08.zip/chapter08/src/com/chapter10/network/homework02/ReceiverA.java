package com.chapter10.network.homework02;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 * 日期：2023/3/14
 * 需求/说明：
 * 1.编写一个接收端A，和一个发送端B，使用UDP协议完成
 *  * 2.接收端在8888端口等待接收数据(receive)
 *  * 3.发送端向接收端发送数据 “四大名著是哪些”
 *  * 4.接收端收到发送端发送的 问题后，返回 “四大名著是....”，否则返回what?
 */

public class ReceiverA {
    public static void main(String[] args) throws IOException {
        DatagramSocket socket = new DatagramSocket(8888);

        //接收数据
        byte[] buf = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buf, buf.length);
        socket.receive(packet);
        byte[] data = packet.getData();
        int length = packet.getLength();
        System.out.println(new String(data, 0, length));

        //发送/回复
        buf = "四大名著是 凡人修仙传 忘语".getBytes();
        packet = new DatagramPacket(buf, buf.length, InetAddress.getLocalHost(), 1111);
        socket.send(packet);
    }
}
