package com.chapter10.network;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
/**
 * 日期：2023/3/13
 * 需求/说明：UDP网络通信编程 - 接收端
 * 1.编写一个接收端A，和一个发送端B
 * 2.接收端A在9999端口登台接收数据(receive)
 * 3.发送端B向接收端A发送数据 "hello,明天吃火锅"
 * 4.接收端A接收到发送端B发送的数据，回复”好的，明天见“，再退出
 */

public class UDPReceiverA {
    public static void main(String[] args) throws IOException {
        //1. 创建一个 DatagramSocket对象，准备在 9999 端口接收数据
        DatagramSocket datagramSocket = new DatagramSocket(9999);
        //2. 构建一个DatagramPacket对象，准备接收数据，一个数据包最大 64k
        byte[] buf = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buf, buf.length);
        //3. 调用接收方法，将通过网络传输的 DatagramPacket对象填充到 此处的packet对象
        //提示：当有数据包发送到本机的9999端口时，就会接收到数据
        //如果没有数据包发送到本机的9999端口，就会阻塞等待，下面代码暂停执行
        System.out.println("接收端A，等待接收数据..");
        datagramSocket.receive(packet); //接收数据

        //4.可以把packet进行拆包，取出数据，并显示
        int length = packet.getLength(); //实际接收到的数据字节长度
        byte[] data = packet.getData(); //接收到数据

        String str = new String(data, 0, length);
        System.out.println(str); //输出数据

        //---------发送/恢复数据给发送端B
        data = "好的，明天见！".getBytes();
        packet = new DatagramPacket(data, data.length, InetAddress.getByName("192.168.56.1"), 9998);
        datagramSocket.send(packet); //发送数据包

        //5.关闭资源
        datagramSocket.close();

    }
}
