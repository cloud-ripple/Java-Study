package com.chapter10.final_;

public class FinalDetail01 {
    public static void main(String[] args) {
        CC cc = new CC(); //final修饰的类CC，不可以继承，但是可以实例化对象
    }
}
class AA {
    /** 1. final修饰的属性在定义时，必须赋初值,赋值可以在如下位置之一：
     * a. 定义时 b. 在构造器中 c. 在代码块中 */
    public final double TAX_RATE = 0.08; //被final修饰后，不赋值会报错 a. 定义时
    public final double TAX_PRICE; //也可以在构造器中给它赋值
    public final double TAX_DISTANCE; //也可以在代码块中赋值，这样才不会报错
    public AA() { //b. 构造器中
        TAX_PRICE = 1.1;
    }
    { //c. 代码块中
        TAX_DISTANCE = 8.8;
    }
}
class BB {
    /** 2. 如果final修饰的属性是静态的，则初始化的位置只能是：
     * a.定义时 b.在静态代码块中，不能在构造器中赋值 */
    public static final double TAX_RATE1 = 99; //a.定义时
    public static final double TAX_RATE2; //b.在静态代码块中
    //public static final double TAX_RATE3; //不能在构造器中赋值
    static {
        TAX_RATE2 = 6.6;
    }
    /** 3. 构造器是在创建实例对象的时候才触发调用，而静态属性(类变量)则是在类加载的时候就触发调用了
     * 由于构造器可能存在不调用的情况，且final修饰的必须给初值，所以不能在构造器中赋值 */
//    public BB() { //不能在构造器中赋值
//        TAX_RATE3 = 8.8;
//    }
}
/** 4. final类不能继承，但是可以实例化对象,即可以创建新对象*/
final class CC{}
/** 5. 如果类不是final类，但是含有final方法，则该方法虽然不能重写，但是可以被继承 */
class DD { //父类
    public final void cal() { //final修饰的方法不能被子类重写，可以继承
        System.out.println("cal()方法");
    }
}
class EE extends DD { //子类
    //在子类中可以继承使用父类中的final方法 cal()
    public static void main(String[] args) {
        new EE().cal(); //通过实例对象来调用方法
    }
}
