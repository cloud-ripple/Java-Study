package com.chapter10.final_;

public class FinalDetail02 {
    public static void main(String[] args) {
        System.out.println(BBB.num); //通过类名访问静态属性
    }
}
/** 6. 一般来说，如果一个类已经是final类了，就没有必要再将方法修饰成final方法。 */
final class AAA {
    public final void cry() {}
}

class BBB {
/** 类什么时候会被加载
a. 创建对象实例时(new 对象)
b. 创建子类对象实例，父类也会被加载，且父类先被加载，子类后被加载
c. 使用类的静态成员时(即静态属性、静态方法)，父类也会被加载，且父类先被加载，子类后被加载 */
//如果只是使用类的静态成员时(只是通过类名访问调用)，普通代码块并不会执行(因为并没有创建实例对象，new 对象)
//注意：1. static静态代码块是类加载时，执行调用，且只会执行一次
//     2. 普通代码块(非静态，相当于构造器)是在创建对象时调用的，每创建一个新对象，就执行调用一次
    /** 7. final和static 往往搭配使用，效率更高，不会导致类加载
     * 即在访问静态成员的时候，类不会加载，所以静态代码块不会被执行*/
    public final static int num = 1000;
    static { //由于静态属性num被final修饰了，在访问num时，类不会被加载，所以该静态代码块不会被调用
        System.out.println("BBB 静态代码块被执行");
    }
}
