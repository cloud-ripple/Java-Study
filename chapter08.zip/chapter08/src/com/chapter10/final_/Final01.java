package com.chapter10.final_;

public class Final01 {
    public static void main(String[] args) {
       // E.TAX_RATE = 9.9; //报错 final修饰后不能被修改
        System.out.println(E.TAX_RATE);
    }
}
//如果希望A类不能被其它类继承，使用final修饰
final class A {}
//class B extends A {} //报错 A类不能被继承

class C {
    //如果不希望父类的某个方法被子类覆盖或重写(override)时，可以用final关键字修饰
    public final void hi() {}
}
//报错 不能重写
//class D extends C {
//    @Override
//    public void hi() { //重写了父类hi()方法
//        super.hi();
//    }
//}

//当不希望类的某个属性的值被修改，可以用final修饰
class E {
    public final static double TAX_RATE = 0.08;
}