package com.chapter10.final_;

public class FinalExercise01 {
    //编写一个程序，能够计算圆形面积。圆周率为3.14，赋值的位置3个方式都要求写一下
    public static void main(String[] args) {
        Circle circle = new Circle(5.0);
        System.out.println(circle.area());
    }
}
class Circle {
    private double radius;
    private final double PI;
    //静态代码块只能直接调用静态成员(静态属性和静态方法)，普通代码块可以调用任意成员
    //在静态方法中，只能访问静态成员(即静态变量或静态方法)，如果非要访问非静态成员，只能创建一个实例对象
    //非静态方法，可以访问所有成员(即静态和非静态都可以)
    //前提是，必须遵守访问权限的规则
    {
        PI = 3.14;
    }
    /**  如果final修饰的属性是静态的，则初始化的位置只能是
     * ：a.定义时 b.在静态代码块中，不能在构造器中赋值。*/

    public Circle(double radius) { //无参构造器
        this.radius = radius;
        //PI = 3.14;
    }
    public double area() {
        return PI * radius * radius;
    }
}
class Something {
    public int oneAdd(final int x) {
        //++x; 错误 不能修改final修饰的 x 的值
        return x + 1; //正确 x本身并没有发生变化，只是返回了一个新值
    }
}
