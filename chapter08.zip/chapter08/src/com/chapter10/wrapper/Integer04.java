package com.chapter10.wrapper;

/**
 * 日期：2023/2/8
 * 需求/说明：Integer创建机制
 */

public class Integer04 {
    public static void main(String[] args) {
        Integer i = new Integer(1);
        Integer j = new Integer(1);
        System.out.println(i == j); //false 只要是new 对象，那么肯定是不同的

        Integer m = 1; //自动装箱 底层 Integer.valueOf(1);
        Integer n = 1;
        System.out.println(m == n); //true
        //通过调试进入源码如下，如果i 在-128~127范围内直接返回，不会new Integer
        //public static Integer valueOf(int i) {
        //        if (i >= IntegerCache.low && i <= IntegerCache.high)
        //            return IntegerCache.cache[i + (-IntegerCache.low)];
        //        return new Integer(i);
        //    }
        Integer x = 128;
        Integer y = 128;
        System.out.println(x == y); //false

        Integer i1 = new Integer(127);
        Integer i2 = new Integer(127);
        System.out.println(i1 == i2); //false

        Integer i3 = new Integer(128);
        Integer i4 = new Integer(128);
        System.out.println(i3 == i4); //false

        Integer i5 = 127;
        Integer i6 = 127;
        System.out.println(i5 == i6); //true

        Integer i7 = 128;
        Integer i8 = 128;
        System.out.println(i7 == i8); //false

        Integer i9 = 127; //底层 Integer.valuesOf(127);
        Integer i10 = new Integer(127); //new 对象
        System.out.println(i9 == i10); //false

        //只要有基本数据类型，判断的是值是否相等
        Integer i11 = 127;
        int i12 = 127;
        System.out.println(i11 == i12); //true

        Integer i13 = 128;
        int i14 = 128;
        System.out.println(i13 == i14); //true
    }
}
