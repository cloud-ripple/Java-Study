package com.chapter10.wrapper;

/**
 * 日期：2023/2/5
 * 需求/说明：装箱：基本类型-->包装类型，反之，拆箱。
 */

public class Integer01 {
    public static void main(String[] args) {
        //int <--> Integer的装箱和拆箱，其它包装类的用法相似
        //jdk5前是手动装箱和拆箱
        //1.手动装箱，两种方式：
        int n1 = 100;
        Integer integer1 = new Integer(n1);
        Integer integer2 = Integer.valueOf(n1);

        //2.手动拆箱
        int i = integer1.intValue();

        //jdk5后，就可以自动装箱和拆箱
        int n2 = 200; //直接把一个基本数据类型赋给对象
        Integer integer3 = n2; //自动装箱 int --> Integer
        //底层使用的仍然是 new Integer(int value);本质上并没有发生变化

        int n3 = integer3; //自动拆箱 Integer --> int
        //底层使用的仍然是 intValue()方法
    }
}
