package com.chapter10.thread;

/**
 * 日期：2023/3/7
 * 需求/说明：线程插队练习
 * 1.主线程每隔1秒，输出hi，一共10次
 * 2.当输出到5次hi时，启动一个子线程(要求实现Runnable接口方式)
 * 每隔1秒输出hello，等该线程输出10次hello后，退出
 * 3.主线程继续输出hi,知道主线程退出
 */

public class Thread08 {
    public static void main(String[] args) throws InterruptedException {

        Thread thread = new Thread(new T5()); //构造器接收一个实现了Runnable接口的类对象
        for (int i = 1; i <= 10 ; i++) {
            Thread.sleep(1000);
            System.out.println("hi " + i);
            if (i == 5) {
                thread.start(); //启动子线程 T5
                thread.join(); //让子线程插队 执行完子线程的任务后，再继续执行主线程
            }
        }
        System.out.println("主线程结束..");
    }
}
class T5 implements Runnable {
    @Override
    public void run() {
        for (int i = 1; i <= 10; i++) {
            System.out.println("hello " + i);

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        System.out.println("子线程结束...");
    }
}
