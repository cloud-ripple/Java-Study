package com.chapter10.thread;

/**
 * 日期：2023/3/9
 * 需求/说明：
 * 1. 有2个用户分别从同一个卡上取钱，总额：10000
 * 2. 每次都取1000，当余额不足时，就不能取款了
 * 3. 不能出现 超取 现象 ---> 线程同步问题
 */

public class Thread13 {
    public static void main(String[] args) {
        User user = new User();
        Thread thread1 = new Thread(user);
        thread1.setName("用户 A");
        Thread thread2 = new Thread(user);
        thread2.setName("用户 B");

        //启动2个线程
        thread1.start();
        thread2.start();
    }
}

class User implements Runnable {

    private int money  = 10000; //同一个用户共享资源
    //如果是继承Thread的方式，2个用户对应两个线程，使用静态修饰 private static int money  = 10000;
    @Override
    public void run() {
        while (true) {
            //1. 这里使用synchronized实现了线程同步
            //2. 当多个线程执行到这里时，就会去争夺 this对象锁
            //3. 哪个线程争夺到/获取了 this对象锁，就执行synchronized代码块，执行完后会释放this对象锁
            //4. 如果争夺不到对象锁，线程就会阻塞Blocked，准备继续争夺
            //5. this对象是一个非公平锁，即用户A抢到了锁，执行完代码块后，释放锁
            //此时，其它用户是处于阻塞Blocked状态，而紧接着用户A又抢到了this对象锁，继续执行代码块，然后再释放
            //而其它线程用户继续Blocked，直到抢到对象锁才可以执行代码块
            synchronized (this) { //线程同步，互斥锁，在任一时刻只允许有一个用户操作下面的代码
                if (money < 1000) {
                    System.out.println("余额不足");
                    break;
                }
                money -= 1000;
                System.out.println(Thread.currentThread().getName() + "取了1000，余额 = " + money);
               //用户每次取完1000，先休息一会(让其它用户取)，然后自己在取钱
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}