package com.chapter10.thread;

/**
 * 日期：2023/3/9
 * 需求/说明：线程死锁
 * 多个线程都占用了对方的锁资源，但不肯相让，导致了死锁，在编程时一定要避免死锁的发生。
 * 应用案例：
 * 妈妈：你先完成作业，才让你玩手机。
 * 小明：你先让我玩手机，我才完成作业。
 *
 * 下面操作会释放锁：
 * (1)当前线程的同步方法、同步代码块执行结束
 * 案例：上完厕所，完事出来
 * (2)当前线程在同步方法、同步代码块中遇到 return、break.
 * (3)当前线程在同步代码块、同步方法中出现了未处理的 Error或Exception，导致异常结束
 * 案例：没有正常的完事，发现忘带纸，不得已出来
 * (4)当前线程在同步代码块、同步方法中执行了线程对象的 wait()方法，当前线程暂停，并释放锁。
 * 案例：没有正常完事，觉得需要酝酿下，所以出来等会再进去
 */

public class Thread11 {
    public static void main(String[] args) {
        //模拟死锁现象
        DeadLock A = new DeadLock(true); //flag对于A线程来说是 true
        A.setName("A线程"); //修改线程名
        DeadLock B = new DeadLock(false); //flag对于B线程来说是 false
        B.setName("B线程");
        //启动线程
        A.start();
        B.start();

    }
}
class DeadLock extends Thread {
    static Object o1 = new Object(); //保证多线程共享一个对象，这里使用static
    static Object o2 = new Object();
    boolean flag;

    public DeadLock(boolean flag) {
        this.flag = flag;
    }
    //1. 如哦flag为true，线程A 就会先得到/持有 o1对象锁
    //2. 如果线程A 得不到 o2对象锁，就会Blocked 锁住

    //3. 如果flag为false，线程B就会先得到/持有 o2对象锁，然后尝试去获取 o1对象锁
    //4. 如果线程B 得不到 o1对象锁，就会Blocked 锁住
    @Override
    public void run() {
        if (flag) {
            synchronized (o1) { //对象互斥锁，下面是同步代码
                System.out.println(Thread.currentThread().getName() + "进入1");
                synchronized (o2) {
                    System.out.println(Thread.currentThread().getName() + "进入2");
                }
            }
        } else {
            synchronized (o2) {
                System.out.println(Thread.currentThread().getName() + "进入3");
                synchronized (o1) {
                    System.out.println(Thread.currentThread().getName() + "进入4");
                }
            }
        }
    }
}