package com.chapter10.thread;

/**
 * 日期：2023/3/6
 * 需求/说明：创建线程的两种方式：
 * (1)继承Thread类，重写run方法
 */

public class Thread01 {
    public static void main(String[] args)  {
        //创建Cat对象，可以当作线程使用
        Cat cat = new Cat();
        cat.start(); //启动线程 --> 最终会执行cat的run方法
        /** 这时，主线程和子线程是交替执行 */
        /* 线程机制底层源码：
        1. public synchronized void start() {
                start0();
        }
        //真正实现多线程的效果，是start0(),而不是run()方法
        2. private native void start0(); //该方法是一个本地方法，由JVM来调用，底层是c/c++实现
        * */

        /** 为什么是start(),而不直接调用run()方法 */
        //cat.run(); //run方法就是一个普通的方法，并没有真正的启动一个线程，只会把run方法执行完毕，才会向下执行，相当于单线程
        //说明：当main线程启动一个子线程 Thread-0 ,主线程不会阻塞，会继续执行
        System.out.println("主线程继续执行" + Thread.currentThread().getName()); //主线程名 main
        for (int i = 0; i < 50; i++) {
            System.out.println("主线程 i = " + i);
            //让主线程休眠
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }

    }
}

//1.当一个类继承了Tread类，该类就可以当作线程使用
//2. run()方法 是Thread类实现了 Runnable接口的run方法
class Cat extends Thread {
    int times; //次数
    @Override
    public void run() { //重写run方法，编写自己的业务逻辑
        while(true) {
            //该线程每隔1秒，在控制台输出 "喵喵，我是小猫咪"
            System.out.println("喵喵，我是小猫咪" + (++times) + " 线程名 = " + Thread.currentThread().getName());
            //让该线程休眠1秒
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            if (times == 80) {
                break; //当输出80次时，退出while循环，这时候线程也就退出
            }
        }
    }
}
