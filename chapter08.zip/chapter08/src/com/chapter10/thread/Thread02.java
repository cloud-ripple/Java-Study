package com.chapter10.thread;

/**
 * 日期：2023/3/6
 * 需求/说明：创建线程的两种方式：
 * (2)实现Runnable接口，重写run方法
 */

public class Thread02 {
    public static void main(String[] args) {
        Dog dog = new Dog();
        //dog.run(); //直接调用run方法，不会启动线程
        //创建一个Thread对象，把dog对象(实现了Runnable接口)放入Thread，这里底层使用了设计模式[代理模式]
        Thread thread = new Thread(dog);
        thread.start(); //启动线程

        /** 演示代理模式创建线程 */
        Tiger tiger = new Tiger();
        ThreadProxy threadProxy = new ThreadProxy(tiger); //通过构造器传入一个实现了Runnable接口的对象
        //相当于 Runnable target = new Tiger(); 接口多态，可以接受一个实现了该接口的对象(看作 向上转型，父类的引用指向了子类对象)
        threadProxy.start(); //启动线程
    }
}

class Animal {}
class Tiger extends Animal implements Runnable {
    int count = 0;
    @Override
    public void run() { //动态绑定机制
        while (true) {
            System.out.println("老虎嗷嗷叫.." + (++count));
            //休眠一下
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            if (count == 20) {
                break;
            }
        }
    }
}

//Proxy(代理) 演示实现Runnable接口，创建线程机制
class ThreadProxy implements Runnable {

    private Runnable target = null; //属性，类型是Runnable

    public ThreadProxy(Runnable target) { //构造器接收一个实现了Runnable接口的子类对象
        this.target = target;
    }

    @Override
    public void run() {
        if (target != null) {
            target.run(); //由于动态绑定机制 target的运行类型，是通过构造器传入进来的一个实现了Runnable接口的子类对象
            /** 最终会调用该实现类Tiger对象中的run()方法 */
        }
    }

    public void start() {
        start0();
    }

    public void start0() { //该方法才是真正实现多线程的
        run(); //调用的是ThreadProxy本类中的run方法
    }
}


class Dog implements Runnable {
    int count = 0;

    @Override
    public void run() { //就是一个普通方法，不会真正的启动线程
        while (true) {
            System.out.println("小狗汪汪叫" + (++count) + Thread.currentThread().getName()); //打印出，次数和线程名
            //休眠1秒
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            if (count == 10) { //输出10次，退出
                break;
            }
        }
    }
}