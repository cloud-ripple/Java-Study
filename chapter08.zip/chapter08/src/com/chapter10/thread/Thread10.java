package com.chapter10.thread;

/**
 * 日期：2023/3/7
 * 需求/说明：线程7大状态-线程的生命周期
 * JDK中用 Thread.State 枚举表示了线程的几种状态
 */

public class Thread10 {
    public static void main(String[] args) throws InterruptedException {
        T10 t10 = new T10();
        System.out.println(t10.getName() + " 当前状态 --> " + t10.getState()); //输出该线程的当前状态
        t10.start(); //启动线程

        while (t10.getState() != Thread.State.TERMINATED) { //如果线程的状态不是终止状态，就一致输出查看当前到底是什么状态
            System.out.println(t10.getName() + " 当前状态 --> " + t10.getState());
            Thread.sleep(1000);
        }
        //再输出最后的线程状态
        System.out.println(t10.getName() + " 当前状态 --> " + t10.getState());

    }
}

class T10 extends Thread {
    @Override
    public void run() {
        while (true) {
            for (int i = 0; i < 10; i++) {
                System.out.println("子线程输出 hi" + i);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            break;  //for循环结束后，退出while,也就退出run了
        }
    }
}