package com.chapter10.thread;

/**
 * 日期：2023/3/7
 * 需求/说明：线程常用方法-线程插队
 * (1)yield: 线程的礼让，让出CPU，让其它线程执行，但礼让的时间不确定，所以也不一定礼让成功。
 * (2)join:线程的插队，插队的线程一旦插队成功，则肯定先执行完插入的线程所有的任务
 * 案例：
 * 创建一个子线程，每个1s输出hello，输出20次，主线程每个1秒，输出hi，输出20次
 * 要求：两个线程同时执行，当主线程输出5次后，就让子线程运行完毕，之后主线程再继续
 */

public class Thread07 {
    public static void main(String[] args) throws InterruptedException {
        T4 t4 = new T4();
        t4.start(); //启动子线程

        //主线程
        for (int i = 1; i <= 20; i++) {

            System.out.println("主线程吃包子 " + i + " 当前线程名=" + Thread.currentThread().getName());
            //休眠1秒
            Thread.sleep(1000);
            //输出5次后，让子线程插队 一旦插队成功，则肯定先执行完插入的线程所有的任务
            //之后再继续执行主线程的任务
            if (i == 5) { //
                System.out.println("主线程吃完5个包子，让子线程先吃");
                /** join()方法，线程插队 */
                t4.join(); //这里相当于让t4子线程先执行完毕
                /** yield()方法，线程礼让，不一定成功 */
                //t4.yield();
                System.out.println("子线程说，我吃完了，主线程接着吃");
            }
            /** 线程是同时交替执行的，如果让某个线程插队，就优先让该插队的线程先执行完任务，然后再继续执行其它线程
             * 就好比 老大(主线程 main)  小弟(子线程) 两人同时吃包子 ，你吃你的，我吃我的
             * 突然调用join()方法，让子线程t4插队，然后老大说了句：小弟你先吃，等你吃完，我在吃。*/
        }

    }
}
class T4 extends Thread {
    @Override
    public void run() {
        for (int i = 1; i <= 20; i++) {

            System.out.println("子线程吃包子 " + i + " 当前线程名=" + Thread.currentThread().getName());
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}