package com.chapter10.thread;

/**
 * 日期：2023/3/7
 * 需求/说明：守护线程
 * 1)用户线程：也叫工作线程，当线程的任务执行完或通知方式结束
 * (2)守护线程：一般是为工作线程服务的，当所有的用户线程结束，守护线程自动结束
 * (3)常见的守护线程：垃圾回收机制
 */

public class Thread09 {
    public static void main(String[] args) throws InterruptedException {
        MyDaemonThread myDaemonThread = new MyDaemonThread();
        /** 如果我么希望当主线程main结束后，子线程自动结束
         只需将子线程设为守护线程即可 */
        myDaemonThread.setDaemon(true);

        myDaemonThread.start(); //先设置守护，再启动

        for (int i = 1; i <= 10; i++) { //main线程
            System.out.println("bobo在辛苦的工作..");
            Thread.sleep(1000);
        }
        //System.out.println("当主线程任务结束，即输出10次后，子线程依然继续执行");
    }
}

//Daemon(守护)
class MyDaemonThread extends Thread {
    @Override
    public void run() { //子线程
        for (; ;) { //无限循环
            try {
                Thread.sleep(1000); //休眠
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println("啵啵和薇薇快乐聊天。。。");
        }
    }
}
