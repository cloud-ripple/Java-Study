package com.chapter10.thread;

/**
 * 日期：2023/3/6
 * 需求/说明：多线程，模拟三个窗口同时售票100张
 */

public class Thread04 {
    public static void main(String[] args) {
        //测试 1.使用继承Thread方式
//        SellTicket01 sellTicket1 = new SellTicket01();
//        SellTicket01 sellTicket2 = new SellTicket01();
//        SellTicket01 sellTicket3 = new SellTicket01();
//        //启动售票线程
//        sellTicket1.start(); //三个线程窗口  会出现超卖现象
//        sellTicket2.start();
//        sellTicket3.start();
//
//        System.out.println("----------------------");
//        //测试 2.使用实现Runnable接口的方式
//        SellTicket02 ticket = new SellTicket02();
//
//        Thread thread1 = new Thread(ticket);
//        Thread thread2 = new Thread(ticket);
//        Thread thread3 = new Thread(ticket);
//        thread1.start(); //三个线程窗口  会出现超卖现象
//        thread2.start();
//        thread3.start();

        //测试 3.使用synchronized实现线程同步   就不会出现超卖现象
        SellTicket03 sellTicket03 = new SellTicket03();
        //启动3个线程
        new Thread(sellTicket03).start();
        new Thread(sellTicket03).start();
        new Thread(sellTicket03).start();

    }
}

//使用继承Thread方式
class SellTicket01 extends Thread {

    private static int ticketNum = 100; //类变量 让多个线程共享 ticketNum 总共100张
    @Override
    public void run() {
        while (true) {
            if (ticketNum <= 0) {
                System.out.println("售票结束..");
                break;
            }
            //休眠50毫秒，继续卖票
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            System.out.println("窗口 " + Thread.currentThread().getName() + " 售出一张票"
            + ", 剩余票数 = " + (--ticketNum));
        }
    }
}
//使用实现Runnable接口的方式
class SellTicket02 implements Runnable {

    private int ticketNum = 100; //

    @Override
    public void run() {

        while (true) {
            if (ticketNum <= 0) {
                System.out.println("售票结束..");
                break;
            }
            //休眠50毫秒，继续卖票
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println("窗口 " + Thread.currentThread().getName() + " 售出一张票"
                    + ", 剩余票数 = " + (--ticketNum));
        }
    }
}

//实现Runnable接口的方式  使用synchronized实现线程同步
class SellTicket03 implements Runnable {

    private int ticketNum = 100; //
    private boolean loop = true;
    Object object = new Object();

    //1. public synchronized void sell() {} 就是一个同步方法
    //2. 这时锁在 this对象
    //3. 也可以在代码块上写 synchronized，同步代码块

    //(5)同步方法(非静态的)的锁可以是this，也可以是其它对象(要求是同一个对象)
    //(6)同步方法(静态的)的锁为当前类本身。
    //4. 如果在静态方法中，实现一个同步代码块,可以这样写 线程操作的对象类.class
    //synchronized (SellTicket03.class) {
    //     System.out.println("m2");
    // }
    public synchronized static void m1() {

    }

    public static void m2() {
        synchronized (SellTicket03.class) { //这里的锁对象不能为this,因为静态方法中不允许出现
            System.out.println("m2");
        }
    }

    public /* synchronized */ void sell() {  //同步方法，在同一个时刻，只能有一个线程来执行该方法
        //同步代码块
        synchronized (this) { //这时互斥锁在this当前对象 动态绑定机制，谁调用该方法，this就代表谁
            if (ticketNum <= 0) {
                System.out.println("售票结束..");
                loop = false;
                return; //退出方法
            }
            System.out.println("窗口 " + Thread.currentThread().getName() + " 售出一张票"
                    + ", 剩余票数 = " + (--ticketNum));
            //休眠50毫秒，继续卖票
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        synchronized (object) { //这时互斥锁在object对象 三个线程同时操作一个object对象
            if (ticketNum <= 0) {
                System.out.println("售票结束..");
                loop = false;
                return; //退出方法
            }
            System.out.println("窗口 " + Thread.currentThread().getName() + " 售出一张票"
                    + ", 剩余票数 = " + (--ticketNum));
            //休眠50毫秒，继续卖票
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Override
    public void run() {
        while (loop) {
            sell();
        }
    }
}