package com.chapter10.thread;

/**
 * 日期：2023/3/6
 * 需求/说明：多个子线程案例
 * 编写一个程序，创建两个线程，一个线程每隔1秒输出 “hello,bobo" ，输出10次，退出
 * 一个线程每隔1秒输出 ”hi"，输出5次退出
 */

public class Thread03 {
    public static void main(String[] args) {
        Thread thread1 = new Thread(new T1());
        Thread thread2 = new Thread(new T2());
        //构造器public Thread(Runnable target)，接受一个实现了Runnable接口的类对象
        thread1.start(); //启动第一个线程
        /** 两个子线程会交替执行 */
        thread2.start(); //启动第二个线程
    }
}
class T1 implements Runnable {

    @Override
    public void run() {
        int count = 0;
        while (true) {
            System.out.println("hello,bobo " + (++count) + " 此子线程名为：" + Thread.currentThread().getName());
            //每输出一句，休眠1秒
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            if (count == 10) {
                break;
            }
        }
    }
}

class T2 implements Runnable {

    @Override
    public void run() {
        int count = 0;
        while (true) {
            System.out.println("hi " + (++count) + " 此子线程名为：" + Thread.currentThread().getName());
            //每输出一句，休眠1秒
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            if (count == 5) {
                break;
            }
        }
    }
}
