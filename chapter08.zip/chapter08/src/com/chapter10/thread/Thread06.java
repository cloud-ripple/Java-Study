package com.chapter10.thread;

/**
 * 日期：2023/3/7
 * 需求/说明：线程常用方法，及注意事项和细节
 */

public class Thread06 {
    public static void main(String[] args) throws InterruptedException {
        T3 t3 = new T3();
        t3.setName("bobo"); //设置线程名称，使之与参数name相同
        t3.setPriority(Thread.MIN_PRIORITY); //设置线程优先级 最小为1
        t3.start(); //启动子线程t3
        //主线程打印5次 hi，然后就中断子线程
        for (int i = 0; i < 5; i++) {
            Thread.sleep(1000); //每隔1秒打印一次
            System.out.println("hi 别停啊，你倒是接着吃啊" + (i + 1));
        }
        System.out.println(t3.getName() + " 线程的优先级 = " + t3.getPriority()); //获取线程名称 和优先级

        //打印完5次hi ，就中断正在休眠的子线程
        t3.interrupt(); //当执行到这里，就会中断 t3线程的休眠，原本子线程是休眠20秒的，中断后，让其继续执行
        //如果没有调用interrupt()方法，那么只有休眠时间达到20秒后，子线程才会继续执行，接着吃包子

    }
}
class T3 extends Thread {
    @Override
    public void run() {
        while (true) {
            for (int i = 0; i < 100; i++) {
                //Thread.currentThread().getName() 获取当前线程的名称
                System.out.println(Thread.currentThread().getName() + " 正在吃包子----" + i);
            }
            try { //一次性吃100个包子，休息20秒后再接着吃
                System.out.println(Thread.currentThread().getName() + " 休眠中---");
                Thread.sleep(20000);
            } catch (InterruptedException e) {
                //当该线程执行到一个interrupt 方法时，就会catch一个异常，可以加入自己的业务代码
                //InterruptedException 是捕获到一个中断异常
                System.out.println(Thread.currentThread().getName() + " 被interrupt了，继续开吃");
            }
        }
    }
}