package com.chapter10.thread;

/**
 * 日期：2023/3/6
 * 需求/说明：通知线程退出-线程终止
 * (1)当线程完成任务后，会自动退出
 * (2)还可以通过使用变量来控制run()方法退出的方式，停止线程，即通知方式
 */

public class Thread05 {
    //需求：启动一个线程t，要求在main线程中去停止线程t
    public static void main(String[] args) throws InterruptedException {
        T t = new T();
        t.start();
        //如果希望main线程去控制t子线程的终止，修改loop,退出run方法，从而终止 t线程 --> 通知
        //让主线程休眠10秒钟，再通知 t线程退出
        Thread.sleep(10 * 1000);
        t.setLoop(false);
    }
}

class T extends Thread {
    int count = 0;
    //设置一个控制变量
    private boolean loop = true;
    @Override
    public void run() {
        while (loop) {
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println("T 运行中..." + (++count));
        }
    }

    public boolean isLoop() {
        return loop;
    }

    public void setLoop(boolean loop) {
        this.loop = loop;
    }
}