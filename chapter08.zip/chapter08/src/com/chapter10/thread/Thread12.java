package com.chapter10.thread;

import java.util.Scanner;

/**
 * 日期：2023/3/9
 * 需求/说明：
 * 1. 在main方法中启动两个线程
 * 2. 第一个线程循环随机打印100以内的整数
 * 3. 直到第二个线程从键盘读取了 “Q” 命令
 */

public class Thread12 {
    public static void main(String[] args) {
        A a = new A();
        B b = new B(a);

        a.start();
        b.start();
    }

}

class A extends Thread {

    private boolean loop = true;

    @Override
    public void run() {
        while (loop) {
            System.out.println((int)(Math.random() * 100 + 1));
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        System.out.println("A线程退出");
    }

    public void setLoop(boolean loop) {
        this.loop = loop;
    }
}

class B extends Thread {

    private A a;

    public B(A a) {
        this.a = a;
    }

    @Override
    public void run() {
        while (true) {
            System.out.print("请输入命令：");
            char key = new Scanner(System.in).next().toUpperCase().charAt(0);
            if (key == 'Q') {
                a.setLoop(false); //以通知方式结束A线程
                System.out.println("B线程退出");
                break;
            }
        }
    }
}