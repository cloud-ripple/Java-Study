package com.chapter10.abstract_;

public class AbstractExercise01 {
    public static void main(String[] args) {
        Manager jack = new Manager("jack", 1, 5000);
        jack.work();
        CommonEmployee bobo = new CommonEmployee("bobo", 2, 9000);
        bobo.work();
    }
}
/** 写法错误 加了final修饰后该类就不能被其它类继承
 * 而抽象类本身就需要子类去继承并实现其所有方法 */
//abstract final class A {} //写法错误
/** 静态方法不能被重写，abstract和static不能同时出现 */
//abstract public static void test(); //写法错误
/** 私有方法，子类不能去重写实现 */
//abstract private void test2(); //写法错误

abstract class Employee {
    private String name;
    private int id;
    private double salary;

    public Employee(String name, int id, double salary) {
        this.name = name;
        this.id = id;
        this.salary = salary;
    }
    //抽象方法 让子类去实现具体的..
    public abstract void work();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}

class Manager extends Employee {
    private double bonus; //奖金
    public Manager(String name, int id, double salary) {
        super(name, id, salary);
    }

    @Override
    public void work() {
        System.out.println("经理 " + getName() + " 工作中..");
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }
}

class CommonEmployee extends Employee {
    public CommonEmployee(String name, int id, double salary) {
        super(name, id, salary);
    }

    @Override
    public void work() {
        System.out.println("普通员工 " + getName() + " 正在工作中..");
    }
}
