package com.chapter10.abstract_;
/** 设计一个抽象类
 * 编写方法calculateTime，可以计算某段代码的耗时时间
 * 编写抽象方法job(),
 * 编写一个子类，继承抽象类，并实现job方法
 * */
abstract public class Template { //抽象类-模板设计模式

    public abstract void job(); //抽象方法 让子类去重写实现

    public void calculateTime() { //计算时间方法
        //得到开始的时间
        long start = System.currentTimeMillis(); //以毫秒为单位
        //把要统计的任务，放在这里
        job(); //方法会进行动态绑定机制，由对象运行类型决定，调用其各自的job()方法
        //得到结束的时间
        long end = System.currentTimeMillis();
        System.out.println("job()方法的 执行时间用了 " + (end - start) + "毫秒"); //结束时间减去开始时间
    }
}
