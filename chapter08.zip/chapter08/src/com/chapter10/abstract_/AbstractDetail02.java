package com.chapter10.abstract_;

public class AbstractDetail02 {
}

/** 如果一个类继承了抽象类，则它必须实现抽象类的所有抽象方法，除非它自己也声明为abstract抽象类 */
abstract class E {
    public abstract void hi() ; //抽象方法
    public abstract void say();
}
abstract class F extends E {

}

class G extends E {
    @Override
    public void hi() { //此处相当于子类G实现了父类E的所有抽象方法
       /** 注意是实现所有方法 */
    }

    @Override
    public void say() {

    }
}
/** 抽象方法不能使用private、final、和static来修饰，static静态方法不能被重写
 * 因为这些关键字都是和子类重写(override)相违背的 */

 abstract class H {
    //private abstract void hi(); 错误
    //public final abstract void hi(); 错误
    //public static abstract void hi(); 错误
}

//抽象类可以有任意成员(因为抽象类还是类)
abstract class D {
    public int n1 = 10;
    public static String name = "bobo";
    public void hi() { //实现方法
        System.out.println("hi");
    }
    public abstract void hello(); //抽象方法不能有主体
}