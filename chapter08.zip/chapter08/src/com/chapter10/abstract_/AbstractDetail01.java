package com.chapter10.abstract_;

public class AbstractDetail01 {
    public static void main(String[] args) {
        //抽象类不能被实例化，即不能new 对象
        //new A(); 写法错误，类A是一个抽象类
    }
}
abstract class A {}

//一旦类包含了abstract方法，则这个类必须声明为abstract类
//class B { //写法错误，因为有了抽象方法，必须把B类修饰为抽象类
//    public abstract void hi();
//}

//abstract只能修饰类和方法，不能修饰属性和其他的
//class C {
//    public abstract int n1 = 100; //错误
//}
