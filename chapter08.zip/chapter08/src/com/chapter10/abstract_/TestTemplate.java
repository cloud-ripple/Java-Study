package com.chapter10.abstract_;

public class TestTemplate {
    public static void main(String[] args) {
        AA aa = new AA();
        aa.calculateTime(); //继承了父类Template，会去父类找到calculateTime()方法

        BB bb = new BB();
        bb.calculateTime();
    }
}

class AA  extends Template {
//    public void calculateTime() { //计算时间方法
//        //得到开始的时间
//        long start = System.currentTimeMillis(); //以毫秒为单位
//        //把要统计的任务，放在这里
//        job1();
//        //得到结束的时间
//        long end = System.currentTimeMillis();
//        System.out.println("AA 执行时间用了 " + (end - start) + "毫秒"); //结束时间减去开始时间
//    }

    //计算任务1
    @Override
    public void job() { //重写实现了父类Template 的抽象方法job
        long num = 0;
        for (long i = 1; i <= 10000000; i++) {
            num += i;
        }
    }
}

class BB extends Template {
//    public void calculateTime() { //计算时间方法
//        //得到开始的时间
//        long start = System.currentTimeMillis(); //以毫秒为单位
//        //把要统计的任务，放在这里
//        job();
//        //得到结束的时间
//        long end = System.currentTimeMillis();
//        System.out.println("AA 执行时间用了 " + (end - start) + "毫秒"); //结束时间减去开始时间
//    }
    //计算任务2
    @Override
    public void job() { //重写实现了父类Template 的抽象方法job
        long num = 1;
        for (long i = 1; i <= 80000; i++) {
            num *= i;
        }
    }
}
