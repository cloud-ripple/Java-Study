package com.chapter10.arrays;

import java.util.Arrays;
import java.util.List;

/**
 * 日期：2023/2/21
 * 需求/说明：
 */

public class Arrays02 {
    public static void main(String[] args) {
        //binarySearch 通过二分搜索法进行查找，要求必须排好序
        Integer[] arr = {1, 2, 90, 123, 567}; //从小到大排序
        //1.使用binarySearch方法 二叉查找
        //2.要求数组是有序的
        //3.如果查找的元素存在则返回该元素下标，不存在则返回当前元素应该在的位置 + 1 的负数
        //如查找 568 在数组中不存在，按理论来说该元素应该在 567后面，
        // 即位于下标为5处，返回 -（5 + 1） ---> -6
        //底层代码：return -(low + 1);  // key not found.
        int index = Arrays.binarySearch(arr, 568);
        System.out.println("查找的元素索引下标 = " + index);

        //copyOf 数组元素的复制
        //1.从 arr数组中，拷贝 arr.length个元素到新数组 newArr中
        //2.如果拷贝的长度大于arr.length原来数组的长度，就在新数组的后面增加 null值
        //3.如果拷贝的长度小于0 ，会抛出异常
        Integer[] newArr = Arrays.copyOf(arr, arr.length);
        Integer[] newArr2 = Arrays.copyOf(arr, arr.length + 2);
        System.out.println("拷贝完毕后的数组元素情况：" + Arrays.toString(newArr));
        //输出 [1, 2, 90, 123, 567]
        System.out.println("拷贝完毕后的数组元素情况：" + Arrays.toString(newArr2));
        //输出 [1, 2, 90, 123, 567, null, null]

        //fill 数组元素的填充（替换）
        //使用 88 去替换 num数组中的所有元素
        Integer[] num = new Integer[]{7, 4, 0};
        Arrays.fill(num, 88);
        System.out.println("数组填充后的元素情况：" + Arrays.toString(num));
        //输出 [88, 88, 88]

        //equals 比较两个数组元素内容是否完全一致
        Integer[] arr2 = {2, 9};
        //1.如果两个数组的元素一样，则返回true,否则返回false
        boolean equals = Arrays.equals(arr, arr2);
        System.out.println(equals);

        //asList 将一组值。转换成List集合
        List<Integer> list = Arrays.asList(1, 2, 5, 7, 0);
        System.out.println(list);

    }
}
