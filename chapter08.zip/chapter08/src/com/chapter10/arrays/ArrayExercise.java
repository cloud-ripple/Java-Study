package com.chapter10.arrays;

import java.util.Arrays;
import java.util.Comparator;

/**
 * 日期：2023/2/21
 * 需求/说明：自定义Book类，里面包含name和price，按price排序从大到小，要求使用两种排序方式
 * 有一个Book[] books = 5本书对象
 */

public class ArrayExercise {
    public static void main(String[] args) {
        Book[] books = new Book[4];
        books[0] = new Book("红楼梦", 99.9);
        books[1] = new Book("西游记", 19.7);
        books[2] = new Book("数据结构与算法", 34);
        books[3] = new Book("java", 77);

        m1(books, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                double price1 = (Double) o1;
                double price2 = (Double) o2;
                return (int)(price1 - price2);
            }
        });
        //以字符串形式输出数组中的元素，即输出每一个Book对象
        System.out.println(Arrays.toString(books));
    }
    public static void m1(Book[] books, Comparator c) {
        Book bookTemp = null;
        for (int i = 0; i < books.length - 1; i++) {
            for (int j = 0; j < books.length - 1 -i; j++) {
                if (c.compare(books[j].getPrice(), books[j + 1].getPrice()) < 0) {
                    bookTemp = books[j + 1];
                    books[j + 1] = books[j];
                    books[j] = bookTemp;
                }
            }
        }
    }
}
class Book {
    private String name;
    private double price;
    public Book(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return "Book{" +
                "name='" + name + '\'' +
                ", price=" + price +
                '}';
    }
}