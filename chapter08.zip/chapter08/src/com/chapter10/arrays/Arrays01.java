package com.chapter10.arrays;

import java.util.Arrays;
import java.util.Comparator;

/**
 * 日期：2023/2/20
 * 需求/说明：Arrays类常用方法
 */

public class Arrays01 {
    public static void main(String[] args) {
        /*
        (1) toString返回数组的字符串形式

        (2) sort 排序
        (3) binarySearch 通过二分搜索法进行查找，要求必须排好序
        (4) copyOf 数组元素的复制
        (5) fill 数组元素的填充
        (6) equals 比较两个数组元素内容是否完全一致
        (7) asList 将一组值。转换成list
        */
        Integer[] integers = {1, 20, 90};
        System.out.println(Arrays.toString(integers)); //输出 [1, 20, 90]

        Integer arr[] = {1, -1, 7, 0, 99};
        //1.可以直接使用冒泡排序，也可以使用Arrays类提供的sort方法排序
        //2.因为数组是引用类型，所以通过sort排序后，会直接影响到实参arr
        //3.sort重载的，也可以通过传入一个接口 Comparator 实现定制排序
        //4.调用sort(T[] a, Comparator<? super T> c)方法，传入两个参数
        //排序的数组arr, 实现了Comparator接口的一个匿名内部类，要求实现compare方法
        Arrays.sort(arr); //默认排序方法
        //定制排序
        Arrays.sort(arr, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                //向下转型
                Integer i1 = (Integer) o1;
                Integer i2 = (Integer) o2;
                return i1 - i2; //底层实际调用的是compare方法，i1 - i2的大小比较 决定排序规则
            /* 底层代码：
            if (c.compare(pivot, a[mid]) < 0)
                 right = mid;
            else
                 left = mid + 1;
            */
            }
        });
        //以字符串形式显示数组信息
        System.out.println(Arrays.toString(arr));

        //模拟排序
        int[] arr2 = {1, -1, 8, 0, 20};
        bubble01(arr2);
        System.out.println("冒泡排序后数组情况：" + Arrays.toString(arr2));

        bubble02(arr2, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                //这里的o1,o2就是调用方法时传入的实参arr[j], arr[j + 1]
                int i1 = (Integer) o1; //向下转型 + 自动拆箱
                int i2 = (Integer) o2;
                return i1 - i2; //返回一个int值
            }
        });
        System.out.println("定制排序后数组的情况：" + Arrays.toString(arr2));

    }
    //使用冒泡排序
    public static void bubble01(int[] arr) {
        int temp = 0;
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - 1 - i; j++) {
                //从小到大排序
                if (arr[j] > arr[j + 1]) {
                    temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    //结合冒泡 + 定制排序
    public static void bubble02(int[] arr, Comparator c) {
        int temp = 0;
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - 1 - i; j++) {
                //数组的排序由compare方法返回的值的大小决定
                if (c.compare(arr[j], arr[j + 1]) > 0) {
                    temp = arr[j]; //如果返回的值大于0 就交换
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
}
