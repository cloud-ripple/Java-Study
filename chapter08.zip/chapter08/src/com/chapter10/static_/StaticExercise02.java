package com.chapter10.static_;

public class StaticExercise02 {
    public static void main(String[] args) {
        //静态方法可以直接用类名调用
        System.out.println("总数是：" + Person.getTotalPerson()); // 0
        Person p1 = new Person();
        System.out.println("p1 的 id = " + p1.getId()); // 1
        Person p2 = new Person();
        //此时 静态变量total在构造器中已经自增为2了
        System.out.println("p2 的 id = " + p2.getId()); // 2
        System.out.println("总数是：" + Person.getTotalPerson()); // 2
    }
}
class Person {
    private int id;
    private static int total = 0;
    public static int getTotalPerson() {
        //id++; //写法错误 id是普通成员变量，在静态方法中只能访问静态变量或静态方法
        return total;
    }
    public Person() {//构造器(非静态方法)
        total++; //普通成员方法中，既可以访问普通变量/方法，也可以访问静态变量/方法
        id = total; //把一个静态变量 赋给 非静态变量
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public static int getTotal() {
        return total;
    }

    public static void setTotal(int total) {
        Person.total = total;
    }
}

