package com.chapter10.static_;

public class StaticMethod {
    public static void main(String[] args) {
        Stu bobo = new Stu("bobo");
        Stu.payFee(5000); //用对象名调用效果一样等价 bobo.payFee(5000);

        Stu jack = new Stu("jack");
        jack.payFee(3000);
        Stu.showFee();// 与jack.showFee()等价; //输出 8000
    }
}
class Stu {
    private String name; //普通属性
    private static double fee = 0; //静态变量，累计学费
    private int n1 = 100;
    private static int n2 = 200;

    public void say() {

    }
    public static void hi() {
        /** 类方法中不允许使用和对象有关的关键字，比如this、super。普通方法(成员方法)可以 */
        //System.out.println(this.n1); 错误
    }
    /** 类方法(静态方法中)只能访问静态变量或静态方法 */
    //普通成员方法，既可以访问普通变量/方法，也可以访问静态变量/方法
    public static void hello() {
        //两种方式等价
        System.out.println(n2);
        System.out.println(Stu.n2);
        hi(); //静态方法
        //say(); 错误，是非静态方法不能调用，静态的只能访问静态的
    }

    public Stu(String name) {
        this.name = name;
    }
    //1. 当方法使用了static修饰后，该方法就是静态方法
    public static void payFee(double fee) {
        Stu.fee += fee; //累加到类变量
    }
    public static void showFee() {
        System.out.println("总学费：" + Stu.fee);
    }
}
