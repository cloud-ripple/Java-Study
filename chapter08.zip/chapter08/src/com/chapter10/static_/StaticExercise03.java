package com.chapter10.static_;

public class StaticExercise03 {
    public static void main(String[] args) {
        Per.setTotalPer(3);
        System.out.println(Per.getTotal()); // 3
        new Per(); //创建一个实例对象(匿名)
        System.out.println(Per.getTotal()); // 4
        //此处 静态变量total已经在构造器中累加到4了，再new Per()时，再次调用构造器
        //静态变量又累积加一，即total=5,然后再赋给成员变量 id
        System.out.println("成员属性 id = " + new Per().getId()); // 5
    }
}
class Per {
    private int id;
    private static int total = 0;
    public static void setTotalPer(int total) {
    /** 类方法(静态方法)中不允许使用和对象有关的关键字，比如this、super。但普通方法(成员方法)可以 */
        //this.total = total;  //写法错误
        Per.total = total;
        /** 静态方法，只能访问静态成员(即静态变量或静态方法) */
        /** 在静态方法中，不能直接访问该类中的非静态成员(属性、方法)，必须创建该类的一个实例对象后
        才能通过这个对象去访问类中的非静态成员 */
        System.out.println(new Per().id); //创建实例对象(匿名)访问非静态属性
        Per per = new Per();
        per.getId(); //通过对象名调用本类的非静态方法
    }
    public Per() { //构造器(非静态方法)，即成员方法
        total++; //可以访问静态变量
        id = total;
    }

    public int getId() {
        return id;
    }

    public static int getTotal() {
        return total;
    }
}
