package com.chapter10.static_;

public class TestMain {
    private static String name = "韩顺平教育"; //静态属性/类变量
    private int n1 = 100; //非静态，普通属性
    //静态方法
    public static void hi() {
        System.out.println("TestMain类中的 静态hi()方法");
    }
    //非静态方法 即实例方法、普通方法
    public void cry() {
        System.out.println("TestMain类中的 非静态cry()方法");
    }

    public static void main(String[] args) {
        /** 1. 静态方法main()中 可以直接访问本类的静态成员(属性和方法) */
        System.out.println("name = " + name);
        hi(); //同一个类中直接调用 与TestMain.hi()等价
        /** 2. 在静态方法中只能访问静态成员，不可以访问非静态成员 */
        //System.out.println(n1); 写法错误，该属性是非静态的
        //cry(); 写法错误，该方法是非静态的，不能在静态方法中调用
        /** 3. 如果在静态方法中要访问本类的非静态成员，
         * 必须创建该类的一个实例对象后，才能通过这个对象去访问类中的非静态成员 */
        TestMain testMain = new TestMain();
        System.out.println(testMain.n1);
        new TestMain().cry(); //匿名对象访问
    }
}
