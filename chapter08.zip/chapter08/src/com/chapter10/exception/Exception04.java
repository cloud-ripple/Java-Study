package com.chapter10.exception;

/**
 * 日期：2023/2/5
 * 需求/说明：自定义异常
 * 当接收对象年龄时，要求范围在18-120之间，否则抛出一个自定义异常
 */

public class Exception04 {
    public static void main(String[] args) {
        int age = 80;
        if (!(age >= 18 && age <= 120)) {
            //通过构造器设置信息
            throw new AgeException("年龄需要在18-120之间");
        }
    }
}

class AgeException extends RuntimeException {
    public AgeException(String message) { //构造器
        super(message);
    }
}