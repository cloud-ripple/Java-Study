package com.chapter10.exception;

import java.util.Scanner;

/**
 * 日期：2023/2/5
 * 需求/说明：用户输入一个数，判断是否为整数，如果不是就一直输入，直到输入整数为止
 */

public class Exception03 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int num;
        while (true) {
            try { //比如：用户输入hello字符串，是不能转换成一个整数的
                num = Integer.parseInt(scanner.next()); //如果在此处有异常发生，则下面的语句不会执行，则一直循环
                break; //如果上面没有异常发生，说明用户输入的数可以转换成整数，则继续执行该语句，会退出循环
            } catch (NumberFormatException e) { //捕获到异常进行处理
                System.out.println("你输入的不是一个整数，请重新输入");
            }
        }
        //循环结束后
        System.out.println("你输入的数为：" + num);
    }
}
