package com.chapter10.exception;

/**
 * 日期：2023/2/4
 * 需求/说明：异常处理入门
 */

public class Exception01 {
    public static void main(String[] args) {
        int num1 = 10;
        int num2 = 0;
        //int res = num1 / num2;
        //1. 执行到这里后，因为num2 = 0，程序会抛出异常ArithmeticException
        //2. 当抛出异常后，程序就退出，崩溃了，下面的代码不再执行
        System.out.println("程序继续运行..");
        //3. 引出异常处理机制，保障程序的健壮性

        try {
            int res = num1 / num2;
        } catch (Exception e) {
            System.out.println("出现异常的原因:" + e.getMessage());
        }
        System.out.println("程序继续运行..");
    }
}
