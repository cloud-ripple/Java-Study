package com.chapter10.system;

import java.util.Arrays;

/**
 * 日期：2023/2/21
 * 需求/说明：System类常见方法
 */

public class System01 {
    public static void main(String[] args) {
        //(1) exit 退出当前程序
        System.out.println("ok1");
        //System.exit(0); //此处，程序退出,下面的所有代码不再执行
        System.out.println("ok2"); //ok2 不会输出

        //(2) arraycopy 复制数组元素，比较适合底层调用，一般使用 Arrays.copyOf完成复制数组
        int[] src = {1, 2, 3};
        int[] dest = new int[3]; //dest 当前是 {0,0,0}
        /* 第一个参数 src 源数组
        第二个参数 srcPoc 从源数组的哪个索引位置开始拷贝
        第三个参数 dest 目标数组 即把源数组的数据拷贝到哪个数组
        第四个参数 destPos 把源数组的数据拷贝到目标数组的哪个索引
        第五个参数 length 从源数组拷贝拷贝多少个数据到目标数组 */
        System.arraycopy(src, 0, dest, 1, 2);
        System.out.println("dest = " + Arrays.toString(dest)); // [0, 1, 2]

        //(3) currentTimeMillis 返回当前时间的毫秒数
        System.out.println(System.currentTimeMillis());
        //(4) gc 运行垃圾回收机制 System.gc();
    }
}
