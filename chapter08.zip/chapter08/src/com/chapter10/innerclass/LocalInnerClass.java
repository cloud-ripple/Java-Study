package com.chapter10.innerclass;
/**
 * 局部内部类 */
public class LocalInnerClass {
    public static void main(String[] args) {
        Outer02 outer02 = new Outer02();
        outer02.m1();
    }
}
class Outer02 { //外部类
    private int n1 = 100;
    private void m2(){ } //私有方法

    public void m1() { //方法
        //1. 定义：局部内部类是定义在外部类的局部位置，比如方法中，并且有类名。
        //3. 不能添加访问修饰符，因为它的地位就是一个局部变量。局部变量是不能使用修饰符的。
        //但是可以使用final修饰，因为局部变量也可以使用final.
        final class Inner02 { //局部内部类，本质仍然是一个类(final修饰后就不能被继承)
            //2. 可以直接访问外部类的所有成员，包含私有的
            private int n1 = 15;
            public void f1() {
                System.out.println("局部内部类中可以访问外部类的所有成员，比如n1=" + n1);
                m2(); //访问方法
                //7. 外部其它类 不能访问 局部内部类(因为局部内部类的定位是一个局部变量)
                //8. 如果外部类和局部内部类的成员重名时，默认遵循就近原则
                //如果想访问外部类的成员，则可以使用 --> 外部类名.this.成员 方式去访问
                /** 解读：Outer02.this 本质就是外部类的对象，即那个对象调用了m1()方法
                 * Outer02.this就是那个对象
                 */
                System.out.println("外部类的n1=" + Outer02.this.n1);
            }
        }
        //5. 局部内部类 访问 外部类的成员：访问方式---> 直接访问
        //6. 外部类 访问 局部内部类的成员：访问方式---> 创建对象，再访问(注意，必须在作用域内)
        Inner02 inner02 = new Inner02();
        System.out.println(inner02.n1);
        inner02.f1();
    }
    //4. 作用域：仅仅在定义它的方法或代码块中。
    /** Inner02局部变量只能在m1()方法体中使用 */
}
