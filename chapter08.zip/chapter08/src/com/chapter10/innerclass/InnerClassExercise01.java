package com.chapter10.innerclass;
/**
 * 匿名内部类使用场景实践
 * 当作实参直接传递，简洁高效。*/
public class InnerClassExercise01 {
    public static void main(String[] args) {
        f1(new IL() {
            @Override
            public void show() {
                System.out.println("这是一幅名画..");
            }
        });
    }
    //这里的形参接收一个实现该接口的类对象
    public static void f1(IL il ) { //静态方法，形参是接口类型
        il.show();
        //il的运行类型--> 实现了该接口的一个匿名内部类
        //jdk底层在创建匿名内部类后，立即马上就创建了实例,并且把对象地址返回
        //因为匿名内部类既是一个类的定义，同时它本身也是一个对象
    }
}
//接口
interface IL {
    public abstract void show();
}