package com.chapter10.innerclass;

public class AnonymousInnerClassDetail {
    public static void main(String[] args) {
        Outer05 outer05 = new Outer05();
        outer05.f1();
    }
}
class Outer05 {
    private int n1 = 99;
    public void f1() {
        //创建一个基于类的匿名内部类
        Person p = new Person() {
            @Override
            public void hi(String str) {
                System.out.println("匿名内部类重写了hi()方法");
            }
        };
        p.hi(""); //动态绑定，调用方法由运行类型决定
        /** 因为匿名内部类既是一个类的定义，同时它本身也是一个对象，因此从语法上看
         它既有定义类的特征，也有创建对象的特征，因此可以调用匿名内部类方法。*/
        //可以直接调用
        new Person() {
            @Override
            public void hi(String str) {
                System.out.println("匿名内部类重写了hi()方法");
            }
        }.hi("hello");
    }
}
class Person {
    public void hi(String str) {
        System.out.println("Person say hi()");
    }
}
