package com.chapter10.innerclass;
/**
 * 成员内部类 */
public class MemberInnerClass01 {
    public static void main(String[] args) {
        Outer08 outer08 = new Outer08();
        outer08.t1();
        //外部其它类访问成员内部类方式：
        Outer08.Inner08 inner08 = outer08.new Inner08();
    }
}
class Outer08 { //外部类
    private int n1 = 10;
    public String name = "啵啵";
    //成员内部类是定义在外部类的成员位置，并且没有static修饰。
    //(1) 可以直接访问外部类的所有成员，包含私有的
    //(2) 可以添加任意访问修饰符(public、protected、默认、private),
    /** 因为它本身的定位就是一个成员。*/
     public class Inner08 { //成员内部类
        public void say() {
            System.out.println("Outer08的 n1 = " + n1 + " name = " + name);
        }
    }
    public void t1() {
        //使用成员内部类
        Inner08 inner08 = new Inner08();
        inner08.say();
    }
}