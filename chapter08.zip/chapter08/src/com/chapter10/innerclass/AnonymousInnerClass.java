package com.chapter10.innerclass;

/**
 * 匿名内部类 */
public class AnonymousInnerClass {
    public static void main(String[] args) {
        Outer04 outer04 = new Outer04();
        outer04.method();
    }
}
class Outer04 { //外部类

    private int n1 = 10;
    /** 1.基于接口的匿名内部类 */
    //1. 需求:想使用A接口，并创建对象
    //2. 传统方式：是单独写一个类，实现该接口，并创建对象
    //A tiger = new Tiger();
    //tiger.cry();
    //3. 假如需求是 Tiger 类只是使用一次，后面不再使用
    //4. 解决方案：可以使用匿名内部类来简化开发
    //5. tiger的编译类型--> IA
    //6. tiger的运行类型--> 实现了该接口的一个匿名内部类(可以通过tiger.getClass()得到)
        /** 底层会分配类名，相当于：
            class Outer04$1 implements IA {
                @Override
                public void cry() {
                    System.out.println("老虎cry...");
                }
            }
        * */
    //7. jdk底层在创建匿名内部类 Outer04$1后，立即马上就创建了 Outer04$1实例
    //并且把对象地址返回给 tiger
    //8. 匿名内部类使用一次，就不能再使用
    public void method() {
        IA tiger = new IA() {
            @Override
            public void cry() {
                System.out.println("老虎cry...");
            }
        };
        tiger.cry();
        System.out.println("tiger的运行类型是：" + tiger.getClass());

        /** 2.基于类的匿名内部类
         * 如果基于的类是一个抽象类，则必须重写实现该抽象中的所有抽象方法 */
        //1. father的编译类型--> Father
        //2. father的运行类型--> 继承了该类的一个匿名内部类 Outer04$2
        //如果不加上{} --> Father father = new Father("jack");则代表创建对象
        //那么father的运行类型是Father。
        /** 底层会创建匿名内部类，相当于：
            class Outer04$2 extends Father {
                @Override
                public void test() {
                    System.out.println("匿名内部类重写了test()方法");
                }
            }
        * */
        //3. 同时也直接返回了匿名内部类Outer04$2的对象
        Father father = new Father("jack") { //加上{}就代表是个匿名内部类
            @Override
            public void test() {
                System.out.println("匿名内部类重写了test()方法");
            }
        };
        father.test();
        //方法的调用由运行类型决定，会调用匿名内部类Outer04$2中的test()方法。
        System.out.println("father对象的运行类型:" + father.getClass());
        /** 3. 匿名内部类细节 */
        //因为匿名内部类既是一个类的定义，同时它本身也是一个对象，因此从语法上看
        //它既有定义类的特征，也有创建对象的特征，因此可以调用匿名内部类方法。
        new IA() {
            @Override
            public void cry() {
                System.out.println("直接调用cry()方法");
            }
        }.cry();
    }
}
interface IA {
    public abstract void cry();
}
//class Tiger implements A {
//    @Override
//    public void cry() {
//        System.out.println("老虎cry...");
//    }
//}
class Father {
    public Father(String name) {
        super();
    }
    public void test() {

    }
}