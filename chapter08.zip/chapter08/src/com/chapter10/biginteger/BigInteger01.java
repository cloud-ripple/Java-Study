package com.chapter10.biginteger;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * 日期：2023/2/21
 * 需求/说明：大数处理方案-BigInteger和BigDecimal类
 */

public class BigInteger01 {
    public static void main(String[] args) {
        //需要处理很大的数时，long不够用
        BigInteger bigInteger = new BigInteger("23458649067580780985908598");
        BigInteger bigInteger1 = new BigInteger("100");

        /*1.在对BigInteger 进行加减乘除的时候，需要使用相对应的方法，不能常规进行 + - * /
        */
        System.out.println(bigInteger.add(bigInteger1)); //两数相加
        System.out.println(bigInteger.subtract(bigInteger1)); //减
        System.out.println(bigInteger.multiply(bigInteger1)); //乘
        System.out.println(bigInteger.divide(bigInteger1)); //除

        //当需要保存一个精度很高的数时，double不够用，使用 BigDecimal
        double d = 1999.111111111111111467878889d;
        System.out.println(d); //输出的数没有完整保存
        BigDecimal bigDecimal1 = new BigDecimal("1999.111111111111111467878889");
        BigDecimal bigDecimal2 = new BigDecimal("1999.1");
        System.out.println(bigDecimal1);
        //如果对BigDecimal进行运算，比如加减乘除，也需要使用相对应的方法

    }
}
