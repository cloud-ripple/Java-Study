package com.chapter10.codeBlock;

public class CodeBlockDetail03 {
    public static void main(String[] args) {
        BBB bbb = new BBB();
        //先输出父类普通代码块，然后才是父类构造器中的内容，
        //然后才是子类的普通代码块，子类构造器中的内容
    }
}
class AAA { //父类是Object

    public AAA() {
        /** 构造器的最前面隐含了这两个步骤 */
        //1. super(); 调用父类无参构造器
        //2. 再调用本类的普通代码块，然后才输出下面的语句
        System.out.println("AAA() 构造器被调用...");
    }
    {
        System.out.println("AAA的普通代码块.."); //最先输出
    }
}
class BBB extends AAA {
    {
        System.out.println("BBB的普通代码块..");
    }
    public BBB() {
        /** 构造器的最前面隐含了这两个步骤 */
        //1. super(); 调用父类无参构造器
        //2. 再调用本类的普通代码块，然后才输出下面的语句
        System.out.println("BBB() 构造器被调用...");
    }
}