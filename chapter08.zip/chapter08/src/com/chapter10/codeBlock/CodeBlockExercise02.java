package com.chapter10.codeBlock;

public class CodeBlockExercise02 {
}
class Sample {
    Sample(String s) { //默认访问修饰符 有参构造器
        System.out.println(s);
    }
    Sample() { //默认访问修饰符 无参构造器
        System.out.println("Sample() 默认无参构造器被调用");
    }
}
class Test {
    //默认访问修饰符类型 普通属性
    Sample sam1 = new Sample("sam1成员初始化"); //3
    //静态属性
    static Sample sam = new Sample("静态成员sam初始化"); //1
    static { //静态代码块
        System.out.println("static块执行"); //2
        if (sam == null) {
            System.out.println("sam is null");
        }
    }
    Test() { //默认访问修饰符 无参构造器
        System.out.println("Test() 默认构造器被调用"); //4
    }

    public static void main(String[] args) {
        Test a = new Test();
    }
}