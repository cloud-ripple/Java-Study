package com.chapter10.codeBlock;
/** 演示 单例模式 饿汉式 */
public class SingleTon01 {
    public static void main(String[] args) {
        //通过方法可以获取对象
        GirlFriend instance1 = GirlFriend.getInstance();
        System.out.println(instance1.toString());
        //两次获取的对象都是同一个，地址相同
        GirlFriend instance2 = GirlFriend.getInstance();
        System.out.println(instance2.toString());
        System.out.println(instance1 == instance2); //true
    }
}
//有一个类，GirlFriend,只能有一个女朋友
class GirlFriend {
    private String name;
    //静态属性 在加载类的时候就已经创建好对象了
    private static GirlFriend gf = new GirlFriend("bobo"); //类的内部创建对象
    //如何保障只能创建一个GirlFriend对象 ---> 构造器私有化
    /** 单例模式 饿汉式 */
    //步骤：构造器私有化(防止直接new 对象)、类的内部创建对象、向外暴露一个静态的公共方法、代码实现
    private GirlFriend(String name) {
        this.name = name;
    }
    //公共静态方法，可以直接用类名调用，而不再需要new 对象通过对象来调用，返回一个GirlFriend对象
    public static GirlFriend getInstance() {
        return gf; //静态方法里只能访问静态成员
    }

    @Override
    public String toString() {
        return "GirlFriend{" +
                "name='" + name + '\'' +
                '}';
    }
}