package com.chapter10.codeBlock;

public class CodeBlockDetail02 {
    public static void main(String[] args) {
    /** (多个)静态属性和静态代码块的调用优先级一样，按照顺序，谁在前谁先调用*/
        A a = new A();
        //先输出 静态方法getN1()被调用.. 再输出  A 静态代码块01 再输出 普通方法getN2()被调用..
    /** 完成静态的初始化后，再进行普通代码块和普通属性(两者优先级一样)的初始化 最后才是构造器的调用 */
    }
}
class A {
    public A() { //构造器的调用优先级最低，最后调用
        System.out.println("A() 无参构造器被调用");
    }

    private int n2 = getN2(); //普通属性的初始化
    private static int n1 = getN1(); //静态属性的初始化
    //普通代码块
    {
        System.out.println("A 普通代码块02");
    }
    //静态代码块
    static {
        System.out.println("A 静态代码块01");
    }
    //普通方法
    public int getN2() {
        System.out.println("普通方法getN2()被调用..");
        return 200;
    }
    //静态方法
    public static int getN1() {
        System.out.println("静态方法getN1()被调用..");
        return 100;
    }
}
