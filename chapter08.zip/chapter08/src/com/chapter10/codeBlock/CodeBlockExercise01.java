package com.chapter10.codeBlock;

public class CodeBlockExercise01 {
    public static void main(String[] args) {
        System.out.println("total = " + Test01.total);
        //1. 在访问使用类的静态成员时，类会被加载，直接导致静态属性初始化，静态代码块执行
        //2. 之后total的值变成100，并且输出 代码块中的 in static block!
        //3. 静态成员准备工作好后，才是上面的输出语句，即输出 total = 100
        System.out.println("total = " + Test01.total);
        //4. 此处，类又会加载，同上，但是一个类中的同一个静态代码块只会被执行一次，即加载过后就不执行了
        //5. 最后输出 total = 100
    }
}
class Test01 {
    public static int total; //类变量
    static { //静态代码块
        total = 100;
        System.out.println("in static block!");
    }
}

