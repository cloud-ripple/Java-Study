package com.chapter10.codeBlock;

public class CodeBlock01 {
    public static void main(String[] args) {
        Movie movie1 = new Movie("你好，李焕英"); //调用的是第一个构造器
        System.out.println("--------------------");
        Movie movie2 = new Movie("凡人修仙传", 99.8, "忘语");
    }
}
class Movie {
    private String name;
    private double price;
    private String director;
    /** 3个构造器 ---> 构成重载 overload */
    //1. 下面的三个构造器都有相同的语句，代码冗余
    //2. 这时候可以把相同的语句，放入到一个代码块中
    //3. 这样当我们不管调用哪个构造器，创建对象时，都会先调用代码块的内容
    //4. 代码块调用的顺序优先于构造器
    {
        System.out.println("电影屏幕打开..");
        System.out.println("广告开始..");
        System.out.println("电影正式开始");
    };
    public Movie(String name) {
//        System.out.println("电影屏幕打开..");
//        System.out.println("广告开始..");
//        System.out.println("电影正式开始");
        this.name = name;
        System.out.println("Movie(String name) 被调用");
    }

    public Movie(String name, double price) {
//        System.out.println("电影屏幕打开..");
//        System.out.println("广告开始..");
//        System.out.println("电影正式开始");
        this.name = name;
        this.price = price;
    }

    public Movie(String name, double price, String director) {
//        System.out.println("电影屏幕打开..");
//        System.out.println("广告开始..");
//        System.out.println("电影正式开始");
        this.name = name;
        this.price = price;
        this.director = director;
        System.out.println("Movie(String name, double price, String director) 被调用");
    }
}
