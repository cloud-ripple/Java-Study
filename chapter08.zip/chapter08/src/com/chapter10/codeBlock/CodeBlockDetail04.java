package com.chapter10.codeBlock;

public class CodeBlockDetail04 {
    public static void main(String[] args) {
        new B02();
        //1. 首先进行类的加载
        // 1.1 先加载父类A02
        // 1.2 再加载子类B02
        //2. 创建对象 从子类构造器走起
        /** 最先完成静态部分的初始化，即静态属性和静态代码块两者优先级一样 (先父类的静态，后子类的静态)
         * 其次是普通代码块或普通属性两者优先级一样 (先父类普通部分，后子类普通部分)
         * 最后是构造器 (先父类构造器，后子类构造器) */
        //小结顺序如下：
        /** 1. 父类静态部分、子类静态部分、
         *  2. 父类普通属性或普通代码块、父类构造器、
         *  3. 子类普通属性或普通代码块、子类构造器 */
    }
}
//细节(7)
class C02 {
    private int n1 = 100;
    private static int n2 = 200;
    private void m1() {

    }
    private static void m2() {

    }
    static {
       /** 1. 静态代码块，只能调用静态成员 */
       //System.out.println(n1); 错误
        System.out.println(n2); //正确
       // m1(); 错误
        m2(); //正确 同一个类中方法直接调用

        /** 2. 如果非要调用普通成员，可以创建new实例对象，通过对象来访问调用 */
        System.out.println(new C02().n1); //正确
        new C02().m1(); //正确

        /** 3. 静态成员(类变量、类方法)也可以用实例对象来访问调用，但推荐用类名访问调用 */
        System.out.println(new C02().n2); //正确
        new C02().m2(); //正确
    };

    {
       /** 4. 普通代码块，可以访问调用任意所有成员 ,即静态、非静态都可以 */
        System.out.println(n1);
        System.out.println(n2);
        m1();
        m2();
    };
}

class A02 { //父类
    private static int n1 = getVal01(); //静态属性初始化
    static { //静态代码块
        System.out.println("父类A02的一个静态代码块");
    }
    { //普通代码块
        System.out.println("父类A02的一个普通代码块");
    }
    public int n3 = getVal02(); //普通属性初始化
    public static int getVal01() { //静态方法
        System.out.println("父类中的 静态方法getVal01() 被调用...");
        return 10;
    }
    public int getVal02() { //普通方法
        System.out.println("父类中的 普通方法getVal02() 被调用...");
        return 10;
    }
    public A02() { //父类无参构造器
        /** 隐藏了2个步骤 */
        // super(); 调用父类无参构造器
        // 调用普通代码块
        System.out.println("父类A02() 构造器被调用");
    }
}

class B02 extends A02 {
    private static int n3 = getVal03();
    static {
        System.out.println("子类B02的一个静态代码块");
    }
    public int n5 = getVal04();
    {
        System.out.println("子类B02的一个普通代码块");
    }
    public static int getVal03() {
        System.out.println("子类中的 静态方法getVal03() 被调用...");
        return 10;
    }
    public int getVal04() {
        System.out.println("子类中的 普通方法getVal04() 被调用...");
        return 10;
    }
    public B02() { //子类无参构造器
        /** 隐藏了2个步骤 */
        // super(); 调用父类无参构造器
        // 调用普通代码块
        System.out.println("子类B02()构造器被调用");
    }
}
