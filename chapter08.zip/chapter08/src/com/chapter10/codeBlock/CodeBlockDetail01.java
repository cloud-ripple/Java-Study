package com.chapter10.codeBlock;

public class CodeBlockDetail01 {
    public static void main(String[] args) {
        /** (1) static静态代码块，作用就是对类进行初始化，而且它是随着类的加载而执行
         并且只会执行一次，
         如果是普通代码块，每创建一个对象就执行
         * (2) 类什么时候被加载 */
        //a. 创建对象实例时(new 对象)
        new BB();
        //b. 创建子类对象实例，父类也会被加载 先加载父类，然后加载子类
        AA aa = new AA();
        //c. 使用类的静态成员时(即静态属性、静态方法),父类也会被加载 先加载父类，然后加载子类
        //先执行父类的静态代码块，然后执行子类的静态代码块，然后才是静态属性
        System.out.println(Cat.n1); //先执行静态代码块，再输出静态属性
        /**(3) static只会执行一次(即每个类中的静态代码块只会执行一次后就不再重复执行)，*/
        DD dd1 = new DD();
        DD dd2 = new DD(); //DD类中static静态代码块只会执行一次，因为类也只加载了一次
        /** (4) 对于普通代码块(即非静态代码块)，每创建一个对象就执行调用一次
         * 如果只是使用类的静态成员时，普通代码块并不会执行 (只有在创建对象时才会执行调用) */
        //创建了两个DD对象，则该类中的普通代码块会被执行两次
        System.out.println(DD.n1); //输出属性值 8888
        //访问类的静态成员(属性、方法)，普通代码块不会被执行，但静态代码块一定会被执行，且只执行一次
    }
}

class DD {
    public static int n1 = 8888; //静态属性
    static { //静态代码块
        System.out.println("DD类 的静态代码块被执行..");
    }
    { //普通代码块（非静态）
        System.out.println("DD类 的普通代码块被执行..");
    }
}

class Animal {
    static {
        System.out.println("Animal类 的静态代码块被执行..");
    }
}
class Cat extends Animal {
    public static int n1 = 999; //静态属性

    static {
        System.out.println("Cat类 的静态代码块被执行..");
    }
}
class BB {
    static {
        System.out.println("BB父类 的静态代码块1被执行..");
    }
}
class AA extends BB {
    static {
        System.out.println("AA类 的静态代码块1被执行..");
    }
}
