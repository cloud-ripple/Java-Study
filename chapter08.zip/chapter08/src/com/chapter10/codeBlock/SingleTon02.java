package com.chapter10.codeBlock;
/** 演示 单例模式 懒汉式 */
public class SingleTon02 {
    public static void main(String[] args) {
        System.out.println(Cat2.n1); //访问了静态属性，会加载类，但是并没有创建对象，构造器也没有被调用
        //获取对象
        Cat2 instance = Cat2.getInstance(); //此时才创建了对象，构造器也被调用
        System.out.println(instance.toString()); //输出实例对象的信息
        //再次调用getInstance()返回的任然是上次创建的对象,不会创建新的对象,两次实例对象都是同一个
        Cat2 instance2 = Cat2.getInstance();
        System.out.println(instance2);
    }
}
class Cat2 {
    private String name;
    public static int n1 = 999;
    private static Cat2 cat2; //定义一个静态对象属性，默认为null，先不创建对象
    private Cat2(String name) { //私有构造器，防止私有化
        System.out.println("构造器被调用，就表明已经创建了对象");
        this.name = name;
    }
    //公共方法，获取对象
    public static Cat2 getInstance() {
        if (cat2 == null) { //如果没有创建对象
            cat2 = new Cat2("小花猫"); //只有在用到对象的时候才创建
        }
        return cat2;
    }

    @Override
    public String toString() {
        return "Cat2{" +
                "name='" + name + '\'' +
                '}';
    }
}