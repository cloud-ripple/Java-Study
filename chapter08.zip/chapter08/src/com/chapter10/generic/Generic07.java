package com.chapter10.generic;

/**
 * 日期：2023/3/3
 * 需求/说明：自定义泛型接口 基本语法和注意细节
 */

public class Generic07 {
    public static void main(String[] args) {

    }
}

//因为接口IA继承了接口IUsb, 所以类AA实现该接口时，也要实现接口IUsb中的所有抽象方法
class AA implements IA {

    @Override
    public Double get(String s) {
        return null;
    }

    @Override
    public void hi(Double aDouble) {

    }

    @Override
    public void run(Double r1, Double r2, String u1, String u2) {

    }
}

/** 没有指定泛型类型时IUsb<U, R>，默认为Object. */
class BB implements IUsb {

    @Override
    public Object get(Object o) {
        return null;
    }

    @Override
    public void hi(Object o) {

    }

    @Override
    public void run(Object r1, Object r2, Object u1, Object u2) {

    }
}
/** 在继承接口时，指定泛型接口IUsb<U, R>的类型 即 U --> 代表String类型，R --> Double*/
interface IA extends IUsb<String, Double> {

}

interface IUsb<U, R> {

    //(1)接口中，静态成员也不能使用泛型
    int n = 10; //此语句在接口中等价于 --> public static final int n = 10; 而final修饰的必须初始化
    //U name; 写法错误 U为泛型，而它是静态的

    //(2)泛型接口的类型，在继承接口或者实现接口时确定
    //(3)没有指定类型，默认为Object.
    //普通方法中，可以使用接口泛型
    R get(U u);

    void hi(R r);

    void run(R r1, R r2, U u1, U u2);

    //在jdk8中，可以在接口中，使用默认方法
    default R method(U u) {
        return null;
    }
}



