package com.chapter10.generic;

/**
 * 日期：2023/3/3
 * 需求/说明：自定义泛型类 基本语法和注意细节
 */

public class Generic06 {
    public static void main(String[] args) {

    }
}

//1.Tiger类后面泛型<T, R, M>，称为自定义泛型
//2. T, R, M 泛型的标识符，一般是单个大写字母，可以多个任意字母
//3. (1)普通成员(即非静态)可以使用泛型(属性、方法)
class Tiger<T, R, M> {
    String name;
    R r; //属性使用到泛型
    T t;
    M m;
    //4. (2)使用泛型的数组，不能初始化
    //T[] ts = new T[9]; //写法错误 因为数组在new 时不能确定T的类型，就无法在内存开辟空间


    public Tiger(String name, R r, T t, M m) {
        this.name = name;
        this.r = r;
        this.t = t;
        this.m = m;
    }

    public R getR() { //返回类型使用到泛型
        return r;
    }

    public void setR(R r) { //方法使用到泛型
        this.r = r;
    }

    //5. (3)静态方法中不能使用类的泛型
    /** 因为静态是和类加载相关的，在类加载时，对象还没创建， 而泛型类型的确定是在创建对象是才知道的
     * 如果静态成员使用了泛型，JVM底层就无法完成初始化(不知道其类型) */
    public T getT() {
        return t;
    }

    public void setT(T t) {
        this.t = t;
    }

    public M getM() {
        return m;
    }

    public void setM(M m) {
        this.m = m;
    }
}
