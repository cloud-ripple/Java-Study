package com.chapter10.generic;

/**
 * 日期：2023/3/2
 * 需求/说明：
 * 泛型的作用：可以在类声明时通过一个标识表示类中某个属性的类型，或者是某个方法的返回值类型，或者是参数类型
 */

public class Generic03 {
    public static void main(String[] args) {
        /** 在你创建对象的时候，通过定义来指定其数据类型，即在编译期间就已经确定了 E是什么类型
         如果你在构造器中传入的数据类型和定义的数据类型不一致时，会直接报错 */
        //Person<String> person = new Person<String>(123); 写法错误
        Person<String> person = new Person<String>("bobo");
        person.showClass(); //运行类型是 String
        /* 1. 上面的 person对象 可以这样理解：相当于
        * class Person {
            String s;
            public Person(String s) { //E 也可以是参数类型
                    this.s = s;
            }
            public String method() { //E 也可以作为方法的返回类型
                return s;
            }
        }
        * */
        Person<Integer> person2 = new Person<Integer>(123);
        person2.showClass(); //运行类型是 Integer
        /* 2. 上面的 person2对象 可以这样理解：相当于
        * class Person {
            Integer s;
            public Person(Integer s) { //E 也可以是参数类型
                    this.s = s;
            }
            public Integer method() { //E 也可以作为方法的返回类型
                return s;
            }
        }
        * */
    }
}
class Person<E> {
    E s; //E 表示类中某个属性的类型
    /**
     * E表示 s的数据类型，到底是什么类型？
     在你创建对象的时候，通过定义来指定其数据类型，即在编译期间就已经确定了 E是什么类型
     如果你在构造器中传入的数据类型和定义的数据类型不一致时，会直接报错 */

    public Person(E s) { //E 也可以是参数类型
        this.s = s;
    }
    public E method() { //E 也可以作为方法的返回类型
        return s;
    }
    public void showClass() {
        System.out.println("显示s的运行类型 = " + s.getClass());
    }
}