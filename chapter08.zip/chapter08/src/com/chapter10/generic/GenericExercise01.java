package com.chapter10.generic;

import java.util.ArrayList;
import java.util.Comparator;

/**
 * 日期：2023/3/3
 * 需求/说明：
 * (1)定义Employee类，该类包含成员变量name,sal,birthday,其中birthday为MyDate类的对象
 * (2)为每一个属性定义get,set方法，重写toString方法
 * (3)MyDate类包含：成员变量month,day,year,
 * (4)创建该类的3个对象，并把这些对象放入 ArrayList集合中，使用泛型，
 * 对集合中的元素进行排序，并遍历输出
 * (5)排序方式：调用ArrayList的 sort方法，传入Comparator对象[使用泛型]，先按照name排序
 * 如果name相同，则按照生日日期的先后排序
 */

public class GenericExercise01 {
    public static void main(String[] args) {
        Employee wei = new Employee("bobo", 6799);
        Employee bobo = new Employee("bobo", 7800);
        Employee tom = new Employee("tom", 9800);

        MyDate date1 = new MyDate(2000, 8, 13);
        MyDate date2 = new MyDate(2004, 9, 5);
        MyDate date3 = new MyDate(2008, 7, 8);

        wei.setBirthday(date1);
        bobo.setBirthday(date2);
        tom.setBirthday(date3);

        ArrayList<Employee> list = new ArrayList<>();
        list.add(wei);
        list.add(bobo);
        list.add(tom);
        //排序 ArrayList的sort(Comparator<? super E> c)方法，接收一个实现了Comparator接口的匿名对象
        list.sort(new Comparator<Employee>() {
            @Override
            public int compare(Employee o1, Employee o2) {
                //比较Name
                //调用String类的 int compareTo(String anotherString)方法
                int i = o1.getName().compareTo(o2.getName());
                if (i != 0) {  //比较器，返回0表示相同元素，否则是不同元素
                    return i;
                }
                //如果name相同,就比较birthday ,包含年月日的比较
                //Employee类的getBirthday()方法，获取MyDate对象，并调用其compareTo方法
                int j = o1.getBirthday().compareTo(o2.getBirthday());
                if (j != 0) {
                    return j;
                }
                //如果以上都相同，按照sal比较
                return (int)(o1.getSal() - o2.getSal());

                /* 以下比较封装在了 MyDate类中的 compareTo方法
                int year = o1.getBirthday().getYear() - o2.getBirthday().getYear();
                if (year != 0) {
                    return year; //如果不等于0，说明，生日的年份year不相同，直接返回即可
                    //只有当compare方法返回0时才表示时相同元素
                }
                //如果以上信息都相同，那就按照day比较
                return o1.getBirthday().getDay() - o2.getBirthday().getDay();
                */
            }
        });

        //遍历输出
        for (Employee employee : list) {
            System.out.println(employee);
        }
    }
}

class Employee {
    private String name;
    private double sal;
    private MyDate birthday;

    public Employee(String name, double sal) {
        this.name = name;
        this.sal = sal;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSal() {
        return sal;
    }

    public void setSal(double sal) {
        this.sal = sal;
    }

    public MyDate getBirthday() {
        return birthday;
    }

    public void setBirthday(MyDate birthday) {
        this.birthday = birthday;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", sal=" + sal +
                ", birthday=" + birthday +
                '}';
    }
}

//MyDate类实现了Comparable接口比较器，泛型<MyDate>专门用于对MyDate类型进行比较
class MyDate implements Comparable<MyDate> {  //生日类
    private int month; //月份
    private int day; //天数
    private int year; //年份

    ////MyDate类实现了Comparable接口，一个比较器，重写了接口中的compareTo方法，用于比较
    @Override
    public int compareTo(MyDate o) { //对年 月 日 进行比较
        /** 此处的 year,谁调用了compareTo方法，那么就代表谁(这个对象)的year属性
         * 而 o 代表的是调用该方法传入的一个MyDate对象，即另外一个 */
         /* 比如前面调用该方法时 o1.getBirthday().compareTo(o2.getBirthday());
         * year代表对象 o1的属性，而o.getYear()得到的是o2对象的属性 */
        int yearMinus = year - o.getYear(); //year 等价--> this.year 代表当前类的
        //o.getYear()代表传入进来的其它MyDate对象的year
        if (yearMinus != 0) {
            return yearMinus; //如果不等于0，说明，生日的年份year不相同，直接返回即可
            //只有当compare方法返回0时才表示时相同元素
        }
        int monthMinus = month - o.getMonth(); //month 等价--> this.month
        if (monthMinus != 0) {
            return  monthMinus;
        }
        //如果以上信息都相同，那就按照day比较
        return day - o.getDay();
    }

    public MyDate(int year, int month, int day) {
        this.month = month;
        this.day = day;
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return "MyDate{" +
                "month=" + month +
                ", day=" + day +
                ", year=" + year +
                '}';
    }
}