package com.chapter10.generic;

import java.util.ArrayList;

/**
 * 日期：2023/3/2
 * 需求/说明：引出泛型
 */

public class Generic01 {
    public static void main(String[] args) {
        //在ArrayList中添加三个对象,遍历输出名字和年龄
        //使用传统方法来解决
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Dog("小白", 12));
        arrayList.add(new Dog("旺财", 6));
        arrayList.add(new Dog("小黑", 2));

        /** 假如我们不小心，添加了一个其它对象，比如Cat对象 */
        arrayList.add(new Cat("招财猫", 9));

        //遍历输出
        for (Object o : arrayList) {
            //向下转型
            Dog dog = (Dog)o; //报错 类型转换异常
            /**此时，遍历数组列表的过程中，向下转型会出错 即 Cat --> Dog 二者没有直接关系 */
            System.out.println(dog.getName() + "-" + dog.getAge());
        }
        //泛型的理解和好处-使用传统方法的问题分析
        //(1)不能对加入到集合ArrayList的数据类型进行约束，不安全
        //(2)遍历的时候，需要进行类型转换，如果集合中的数据量较大，对效率有影响

    }
}
class Dogs {
    private String name;
    private int age;

    public Dogs(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
class Cats {
    private String name;
    private int age;

    public Cats(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}