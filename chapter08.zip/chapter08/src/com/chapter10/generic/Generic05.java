package com.chapter10.generic;

import java.util.ArrayList;
import java.util.List;

/**
 * 日期：2023/3/3
 * 需求/说明：泛型使用细节和注意事项
 */

public class Generic05 {
    public static void main(String[] args) {
        //1.Pig<E> --> 先指定泛型E的类型是A类,
        /** 相当于public Pig(A e)构造器，参数e 接收一个A类对象，或者其子类对象 */
        Pig<A> pig1 = new Pig<A>(new A());
        Pig<A> pig2 = new Pig<A>(new B()); //
        //这里在定义泛型的时候，已经指定了其类型为A类，所以通过构造器参数传入一个其他类是错误的
        //除非传入一个子类对象，即让B继承A类就可以了

        //2.泛型使用形式
        ArrayList<Integer> list1 = new ArrayList<Integer>();
        //编译器会进行类型判断，右边泛型可以省略不写，推荐下面的写法方式
        ArrayList<Integer> list2 = new ArrayList<>();
        ArrayList<Pig> list3 = new ArrayList<>();

        //3.如果这样写： List list3 = new ArrayList(); 默认给他的泛型是 <E> E就是Object
        List list = new ArrayList(); //等价 --> List<Object> list = new ArrayList<>();

        Tigers tiger = new Tigers();
        /* 这样写，相当于 ：
        class Tigers<G> {
            Object e;
            public Tigers() {}

            public Tigers(Object e) {
                this.e = e;
            }
        }
        * */
    }
}

class A {}
class B extends A {}

class Pig<E> {
    E e;

    public Pig(E e) {
        this.e = e;
    }
}

class Tigers<G> {
    G e;

    public Tigers() {

    }

    public Tigers(G e) {
        this.e = e;
    }
}