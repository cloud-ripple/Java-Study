package com.chapter10.generic;

import org.junit.Test;

import java.util.*;

/**
 * 日期：2023/3/4
 * 需求/说明：
 * 定义个泛型类 DAO<T>, 在其中定义一个Map成员变量，Map的键为String类型，值为 T类型
 * 分别创建以下方法：
 * (1)public void save(String id, T entity) 保存T类型的对象到Map成员变量中
 * (2)public T get(String id) 从map中获取id对应的对象
 * (3)public void update(String id, T entity) 替换map中key为 id的内容，改为entity对象
 * (4)public List<T> list() 返回map中存放的所有T对象
 * (5)public void delete(String id) 删除指定id对象
 * 定义一个User类：
 * 该类包含：private成员变量 id, age, name
 * 创建DAO类的对象，分别调用其 save, get, update, list, delete方法来操作 User对象
 */

public class Generic11 {

    DAO<User> dao = new DAO<>();
    public static void main(String[] args) {

    }
    @Test
    public void test() {
        dao.save("1", new User(1, 22, "bobo"));
        dao.save("2", new User(2, 32, "wei"));

        List<User> list = dao.list();
        System.out.println(list);

        System.out.println("----修改后的元素情况---");
        dao.update("2", new User(4, 99, "jack"));
        list = dao.list(); //重新获取集合列表
        System.out.println(list); //输出

    }
}
//Map<K, V>是无序的双列集合，存放键值对，映射关系
class DAO<T> {
    private Map<String, T> map = new HashMap<>();  //key为 String类型, value为 泛型T

    public void save(String id, T entity) {
        map.put(id, entity);
    }

    public T get(String id) { //根据id获取map对象中的 对象
        return map.get(id); //Map接口中的 V get(Object key)方法 通过传入key来获取value
    }

    public void update(String id, T entity) { //替换map中key为 id的内容，改为entity对象
        map.put(id, entity);
    }

    //遍历map [k-v]，将map的所有value(entity),封装到ArrayList返回即可
    public List<T> list() { //返回map中存放的所有T对象
        List<T> list = new ArrayList<>(); //创建一个ArrayList，存放T泛型类型
        //遍历map方式1
        Collection<T> values = map.values();
        //Collection<V> values()方法，获取map中的全部值 V，并返回一个Collection集合
        /** 凡是实现了或者继承了 Collection接口的类，
         * 都能调用该接口中的 Iterator<E> iterator()方法返货一个迭代器对象 ，用于遍历 */
        Iterator<T> iterator = values.iterator();
        while(iterator.hasNext()) {
            list.add(iterator.next()); //添加T对象到集合中
            //next继续指向迭代器中的下一个T对象，并返回上一个
        }
        /* 或者使用 for增强遍历
        for (T t : values) {
            list.add(t);
        }
        */

        return list;

        /* 遍历map方式2 使用entrySet方法获取键值关系
        Set<Map.Entry<String, T>> entries = map.entrySet();
        // Set<Map.Entry<K, V>> entrySet()方法，获取map中的k-v键值对关系，并返回一个Set集合
        //而Set集合中存放的是Map.Entry，而Entry中存放的是k-v键值对关系
        Iterator<Map.Entry<String, T>> iterator1 = entries.iterator(); //迭代器
        while (iterator1.hasNext()) {
            Map.Entry<String, T> entry = iterator1.next();
            list.add(entry.getValue()); //通过 Entry接口中的 V getValue()方法获取值
        }
        */

        /* 遍历map方式3
        Set<String> keySet = map.keySet(); //keySet()方法，获取所有键集
        for (String key : keySet) {
            list.add(map.get(key)); //通过key获取value，并添加到list中
        }
        Iterator<String> iterator2 = keySet.iterator();
        while (iterator2.hasNext()) {
            list.add(map.get(iterator2.next()));
        }
        */
    }

    public void delete(String id) { //删除指定id对象
        map.remove(id);
    }
}

class User {
    private int id;
    private int age;
    private String name;

    public User(int id, int age, String name) {
        this.id = id;
        this.age = age;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", age=" + age +
                ", name='" + name + '\'' +
                '}';
    }
}