package com.chapter10.generic;

import java.util.ArrayList;

/**
 * 日期：2023/3/3
 * 需求/说明：自定义泛型方法 基本语法和注意细节
 */

public class Generic08 {
    public static void main(String[] args) {

        Car car = new Car();
        //(2)当泛型方法被调用时，类型会确定
        /** 当调用方法时，传入参数，编译器，就会确定类型 */
        car.fly("宝马", 100);
        System.out.println("----调用泛型方法，传入不同类型的参数，泛型类型会随之改变 ----");
        car.fly(300, 99.9);

        //(3)public void fly(E e) {}，修饰符后没有加上<T,R>泛型 该方法不是泛型方法，而是使用了泛型

        //泛型方法，可以使用类声明的类型，也可以使用自己声明的泛型
        //Fish<T,R>  其中T --> String   R --> ArrayList
        Fish<String, ArrayList> fish = new Fish<>();
        fish.hello(new ArrayList(), "bobo"); //
        //<K> void hello(R r, K k)方法  其中R -->ArrayList  k -->String

        /** 说白了，泛型就是一种可以去接收任意数据类型(不是基本类型)的类型 ，用任意多个字母(一般大写)代替 */

    }
}
//1.(1)泛型方法，可以定义在普通类中，也可以定义在泛型类中
class Car { //普通类
    public void run() { //普通方法

    }
    //说明
    //2. <T,R> 就是泛型，提供给 fly使用的
    public <T,R> void fly(T t, R r) { //泛型方法
        System.out.println("泛型T的运行类型：" + t.getClass()); //String
        System.out.println("泛型R的运行类型：" + r.getClass()); //int --> Integer自动装箱
    }
}

class Fish<T,R> { //泛型类
    public void run() { //普通方法

    }
    //3. <U,M> 就是泛型，提供给 eat使用的
    public <U,M> void eat(U u, M m) { //泛型方法

    }
    //4. 下面的fly方法不是泛型方法，只是使用了类声明的 泛型
    public void fly(T t) {

    }
    //5. 泛型方法，可以使用类声明的类型，也可以使用自己声明的泛型
    // <K>是泛型方法hello自己声明的类型，而 R是类声明的
    public <K> void hello(R r, K k) {

    }
}
