package com.chapter10.generic;

import java.util.ArrayList;

/**
 * 日期：2023/3/2
 * 需求/说明：泛型入门
 */

public class Generic02 {
    public static void main(String[] args) {
        //使用泛型
        ArrayList<Dog> arrayList = new ArrayList<Dog>(); //ArrayList是单列集合
        //HashMap<Dog, Cat> dogCatHashMap = new HashMap<>(); //Map双列集合
        /*
        * 1.ArrayList<Dog>表示存放到ArrayList集合中的元素类型是Dog类型
        * 2.如果编译器发现添加的类型不满足要求就会报错
        * 3.在遍历的时候，可以直接取出Dog类型，而不是Object
        * */
        arrayList.add(new Dog("小白", 12));
        arrayList.add(new Dog("旺财", 6));
        arrayList.add(new Dog("小黑", 2));

        for (Dog dog : arrayList) {
            System.out.println(dog.getName() + "-" + dog.getAge());
        }

    }
}
class Dog {
    private String name;
    private int age;

    public Dog(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
class Cat {
    private String name;
    private int age;

    public Cat(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}