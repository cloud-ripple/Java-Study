package com.chapter10.generic;

import java.util.ArrayList;
import java.util.List;

/**
 * 日期：2023/3/4
 * 需求/说明：泛型继承和通配符
 */

public class Generic10 {
    public static void main(String[] args) {
        Object obj = new String("xx");
        //(1)泛型没有继承性
        //List<Object> list = new ArrayList<String>(); 语法错误

        //(2) <?> :支持任意泛型类型
        //(3) <? extends A> : 支持A类以及A类的子类，规定了泛型的上限
        //(4) <? super A> : 支持A类以及A类的父类，不限于直接父类，规定了泛型的下限

        //举例说明下面三个方法的使用
        List<Object> list1 = new ArrayList<>();
        List<String> list2 = new ArrayList<>();
        List<AAA> list3 = new ArrayList<>();
        List<BBB> list4 = new ArrayList<>();
        List<CCC> list5 = new ArrayList<>();

        /** 如果是 List<?> c 表示任意的泛型类型都可以接收 */
        printCollection1(list1);
        printCollection1(list2);

        /** List<? extends AAA> c 可以接受AAA类或其子类 */
        //printCollection2(list1); //错误 集合list1中是Object类
        //printCollection2(list2); //错误 String类和AAA类没有关系
        printCollection2(list3); //ok list3中都是AAA类
        printCollection2(list4); //ok list4中是BBB类，而BBB继承了AAA
        printCollection2(list5); //ok list5中是CCC类，而CCC类继承了BBB，是AAA类的间接子类

        /** List<? super CCC> c 可以接受CCC类或其父类 */
        printCollection3(list1); //错误 集合list1中是Object类
        //printCollection3(list2); //错误 String类和CCC类没有关系
        printCollection3(list3); //ok list3中都是AAA类,它是CCC的间接父类
        printCollection3(list4); //ok list4中是BBB类，而BBB是CCC的父类
        printCollection3(list5); //ok list5中是CCC类


    }

    /** List<?> :支持任意泛型类型都可以接收 */
    public static void printCollection1(List<?> c) {
        for (Object o : c) {
            System.out.println(o); //通配符，取出时就是Object
        }
    }
    /** List<? extends AAA>，可以接收 AAA或者AAA的子类 ，表示上限 */
    public static void printCollection2(List<? extends AAA> c) {
        for (Object o : c) {
            System.out.println(o);
        }
    }
    /** List<? super CCC> ,可以接收 CCC或者CCC的父类，表示下限 */
    public static void printCollection3(List<? super CCC> c) {
        for (Object o : c) {
            System.out.println(o);
        }
    }
}

class AAA {

}
class BBB extends AAA {}
class CCC extends BBB {}
