package com.chapter10.generic;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * 日期：2023/3/2
 * 需求/说明：泛型应用实例
 */

public class Generic04 {
    public static void main(String[] args) {
        //1.创建3个学生对象
        //2.放入到 HashMap中，要求 Key是String name, Value是学生对象
        //3.使用两种方式遍历
        HashMap<String, Student> map = new HashMap<>();
        Student student1 = new Student("学生1", 23);
        Student student2 = new Student("学生2", 26);
        Student student3 = new Student("学生3", 14);

        map.put(student1.name, student1);
        map.put(student2.name, student2);
        map.put(student3.name, student3);

        Set<Map.Entry<String, Student>> entries = map.entrySet();
        for (Map.Entry entry : entries) {
            System.out.println(entry.getKey() + "-" + entry.getValue());
        }


    }
}
class Student {
    public String name;
    public int age;

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}