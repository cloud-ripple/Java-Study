package com.chapter10.generic;

/**
 * 日期：2023/3/4
 * 需求/说明：泛型方法练习案例
 */

public class Generic09 {
    public static void main(String[] args) {
        Apple<String, Integer, Double> apple = new Apple<>();
        apple.fly(10);  //int --> Integer自动装箱
        apple.fly(new Tom());
        //输出 Integer  Tom
    }
}
class Apple<T,R,M> {
    public <E> void fly(E e) {
        System.out.println(e.getClass().getSimpleName()); //输出运行类型的类名
    }
    /*
    public void eat(U u) {
       //该方法，语法错误，使用的泛型U在类中没有声明，除非该方法自己声明一个U泛型
    }
    */

    public void run(M m) {

    }
}
class Tom {

}