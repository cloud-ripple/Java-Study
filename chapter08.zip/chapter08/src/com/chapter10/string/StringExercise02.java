package com.chapter10.string;

/**
 * 日期：2023/2/21
 * 需求/说明：注册处理案例
 */

public class StringExercise02 {
    //输入用户名、密码、邮箱、如果信息录入正确，则提示注册成功，否则生成异常对象
    //要求：1.用户名长度为2或3或4
    //2.密码的长度为6，要求全是数字
    //3.邮箱中包含@和. 并且@在.的前面
    public static void main(String[] args) {
        String userName = "bobo";
        String pwd = "123456";
        String email = "twb@52022.com";
        String result = "";
//        try {
//            result = isDigital(userName, pwd, email);
//        } catch (Exception e) {
//            System.out.println(e.getMessage());
//        }
//        System.out.println(result);
        try {
            userRegister(userName, pwd, email);
            //如果在此处调用方法时产生异常，下面的代码不会执行，直接进入catch语句块
            System.out.println("你已注册成功");
        } catch (Exception e) {
            System.out.println(e.getMessage()); //打印异常信息
        }

    }

    //自己写的
    public static String isDigital(String userName, String pwd, String email) {
        char[] chars = pwd.toCharArray();
        boolean isNum = false;
        for (char ch : chars) {
            if (ch >= '0' && ch <= '9') {
                isNum = true;
            } else {
                System.out.println("输入的密码不是纯数字");
                break;
            }
        }
        boolean isInclude = false;
        int index1 = email.indexOf("@");
        int index2 = email.indexOf(".");
        if (index1 != -1 && index2 != -1 && index2 < index1) {
            isInclude = true;
        }


        if (!(userName.length() >= 2 && userName.length() <= 4 && pwd.length() == 6
                && isNum && isInclude)) {
            throw new RuntimeException("输入信息错误！");
        } else {
            return "注册成功";
        }

    }

    //老韩写的
    public static void userRegister(String name, String pwd, String email) {
        //1.
        int userLen = name.length();
        if (!(userLen >= 2 && userLen <= 4)) {
            throw new RuntimeException("用户长度应为2~4之间");
        }

        //2.
        if (!(pwd.length() == 6 && isDigital(pwd))) {
            throw new RuntimeException("密码长度不为6或者不是纯数字");
        }

        //3.
        int index1 = email.indexOf('@'); //获取字符
        //indexOf():获取字符在字符串中第一次出现的索引，索引从0开始，如果找不到，返回-1
        int index2 = email.indexOf('.');
        if (!(index1 > 0 && index2 > index1)) {
            throw new RuntimeException("邮箱中要包含@和. 并且@在.的前面");
        }

        //上面三个条件都满足，即没有发生异常

    }
    //单独写一个方法，判断密码是否为纯数字
    public static boolean isDigital(String str) {
        char[] chars = str.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            if (chars[i] < '0' || chars[i] > '9') {
                return false;
            }
        }
        return true;
    }
}
