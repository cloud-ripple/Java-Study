package com.chapter10.string;

/**
 * 日期：2023/2/8
 * 需求/说明：String类常用方法
 */

public class String03 {
    public static void main(String[] args) {
        /*
        equals():区分大小写，判断内容是否相等
        equalsIgnoreCase():忽略大小写的判断内容是否相等
        length():获取字符的个数
        indexOf():获取字符在字符串中第一次出现的索引，索引从0开始，如果找不到，返回-1
        LastIndexOf():获取字符在字符串中最后一次出现的索引，索引从0开始，如果找不到，返回-1
        substring():截取指定范围的子串
        trim():去前后空格
        charAt():获取某索引处的字符，注意不能使用Str[index]方式   */
        String s1 = "wer@terwe@g";
        int index = s1.indexOf('@');
        System.out.println(index); //3

        String name = "hello,张三";
        System.out.println(name.substring(6)); //张三 从索引6开始截取后面所有的内容
        System.out.println(name.substring(0, 5)); //从索引0开始截取5个字符

        String names = "jack";
        int age = 22;
        double score = 98.8;
        char gender = '女';
        //占位符：%s字符串、%c字符、%d整型、%.2f浮点型
        //方式1
        String info = String.format(
                "我的姓名是%s 年龄是%d, 成绩是%.2f 性别是%c",
                names, age, score, gender);
        //方式2
        String formatStr = "我的姓名是%s 年龄是%d, 成绩是%.2f 性别是%c";
        String info2 = String.format(formatStr, names, age, score, gender);
        System.out.println(info2);

    }
}
