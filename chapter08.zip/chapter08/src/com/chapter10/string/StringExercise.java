package com.chapter10.string;

/**
 * 日期：2023/2/21
 * 需求/说明：String翻转
 */

public class StringExercise {
    public static void main(String[] args) {
        //1.将字符串中指定部分进行反转，比如将 "a bcde f" --> "a edcb f"
        /*思路分析：
        1.把String转成 char[],因为char[] 的元素是可以交换的
        * */
        String s = "abcdef";
        try {
            //从下标起始位置1处(start) 到 下标4处(end)之间进行反转
            s = reverse(s, 1, 4);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return; //如果捕获到异常，下面的代码不再执行，直接退出
        }
        System.out.println("反转后的字符串：" + s);
    }

    public static String reverse(String str, int start, int end) {
        //对输入的参数进行校验
        //1.先写出正确的常规情况
        //2.然后取反即可
        if (!(str != null && start >= 0 && end > start && end < str.length())) {
            throw new RuntimeException("参数不正确！");
        }
        char[] chars = str.toCharArray(); //把String转成char[]
        char temp = ' '; //辅助交换变量
        for (int i = start, j = end; i < j; i++, j--) {
            //只有当左边的下标小于右边的下标时才交换，起始处(在左边)下标递增，结束处(右边)下标递减
            temp = chars[i]; //把起始元素提出来
            chars[i] = chars[j]; //把结束(最后)一个元素放到起始处，即下标为1和4的字符相互交换
            chars[j] = temp;
        }
        //使用chars重新构建一个String返回
        return new String(chars);
    }
}
