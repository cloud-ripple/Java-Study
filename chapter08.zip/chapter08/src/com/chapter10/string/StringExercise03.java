package com.chapter10.string;

/**
 * 日期：2023/2/22
 * 需求/说明：字符串统计案例
 */

public class StringExercise03 {
    /*1.需求:输入形式为：Han shun Ping的人名，以Ping,Han.S 的形式打印出来
    其中S是中间单词的首字母
    2.例如:输入 ”William Jefferson Clinton", 输出形式为：Clinton, William.J
    * */
    public static void main(String[] args) {
        System.out.println(method("William Jefferson Clinton"));
        printName("William Jefferson Clinton");
    }

    //自己写的
    public static String method(String name) {
        int index = 0;
        String result = null;
        int i = name.lastIndexOf(" ");
        int j = name.indexOf(" ");
        if (i > 0) {
            index = i;
            result = name.substring(index + 1) + ", ";
        }
        result += name.substring(0, j);
        if (j > 0) {
            index = j;
            result += "." + name.charAt(index + 1);
            //System.out.println((name.charAt(index + 1) + "").toUpperCase());
        }

        return result;
    }

    //老韩写的
    /*思路分析：
    1.对输入的字符串进行分割，使用split()方法
    2.分割后，对得到的字符串数组String[] 进行格式化String.format()
    3.对输入的字符串进行校验即可
    * */
    public static void printName(String str) {
        if (str == null) {
            System.out.println("字符串不能为空");
            return;
        }
        String[] names = str.split(" "); //按照空格分割字符串，字符串数组中有3个字符串
        if (names.length != 3) {
            System.out.println("输入的字符串格式不对 XXX XXX XXX");
            return;
        }
        //把字符串格式化，利用占位符，把分割的第二个字符串全部改成大写然后取第一个字符
        //占位符：%s字符串、%c字符、%d整型、%.2f浮点型
        String str2 = String.format("%s, %s .%c", names[2], names[0], names[1].toUpperCase().charAt(0));
        System.out.println(str2);
    }
}
