package com.chapter10.string;

/**
 * 日期：2023/2/22
 * 需求/说明：字符串统计案例
 */

public class StringExercise04 {
    /*需求：输入字符串，判断里面有多少个大写字母，多少个小写字母，多少个数字
     * */
    public static void main(String[] args) {
        count("1234QwertTQw99");
    }

    public static void count(String str) {
        if (str == null) {
            System.out.println("输入的字符串不能为空");
            return; //下面的代码不再执行，直接返回
        }
        //1.先把字符串转成字符数组，然后循环遍历每一个字符
        char[] chars = str.toCharArray();
        int countUpper = 0; //统计大写字母个数
        int countLower = 0; //统计小写子么个数
        int countNum = 0; //统计数字个数

        for (int i = 0; i < chars.length; i++) {
            if (chars[i] >= 'A' && chars[i] <= 'Z') {
                countUpper++; //大写
            } else if (chars[i] >= 'a' && chars[i] <= 'z') {
                countLower++; //小写
            } else {
                countNum++; //数字
            }
        }
        System.out.println("大写字母个数：" + countUpper);
        System.out.println("小写字母个数：" + countLower);
        System.out.println("数字个数：" + countNum);
    }
}
