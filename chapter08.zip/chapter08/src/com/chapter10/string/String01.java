package com.chapter10.string;

/**
 * 日期：2023/2/8
 * 需求/说明：String类的理解和创建对象
 */

public class String01 {
    public static void main(String[] args) {
        /*1. "jack" 字符串常量，双引号括起来的字符序列
          2. 字符串里的字符使用Unicode字符编码，一个字符(不区分字母还是汉字)占两个字节
          3. String类有很多的构造器，构造器重载
          4. String类实现了接口 Serializable，可以串行化，即可以在网络传输。
                          接口 Comparable，让String对象可以比较大小
          5. String类是final类，不能被其他类继承
          有属性 private final char value[]; //看源码，用于存放字符串内容
          注意：value是一个final类型，不可以修改地址空间，
          即当value指向一个地址后，就不能再指向另外一个地址空间了,但是单个字符内容可以变化 */

        String name = "jack";
        name = "tom";
        final char value[] = {'a', 'b', 'c'};
        char[] v2 = {'t', 'o', 'm'};
        value[0] = 'H';
        //value = v2; 写法错误，final修饰的value不能再指向新的地址空间

    }
}
