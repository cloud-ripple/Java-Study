package com.chapter10.string;

/**
 * 日期：2023/2/8
 * 需求/说明：String类练习题
 */

public class String02 {
    public static void main(String[] args) {
        String a = "hsp"; //a 指向常量池的"hsp"数据空间
        String b = new String("hsp");
        //b 指向堆中的对象 value，而value又指向常量池中的空间地址
        System.out.println(a.equals(b)); //true 比较字符串内容
        System.out.println(a == b); //false 两者指向不同的对象

        //1. 当调用intern()方法时，如果池中已经包含一个
        // 等于此String对象的字符串(用equals(Object)方法确定)，则返回池中的字符串。
        //否则，将此String对象添加到池中，并返回此String对的引用
        //2. intern()方法最终返回的是常量池的地址(对象)
        System.out.println(a == b.intern()); //true
        System.out.println(b == b.intern()); //false b指向的是堆中的对象

        String s1 = "hspedu"; //s1指向常量池 "hspedu"
        String s2 = "java"; //指向常量池 "java"
        String s4 = "java"; //指向常量池 "java"
        String s3 = new String("java");
        //s3指向堆中的对象value，而value又指向常量池中的数据空间
        System.out.println(s2 == s3); //false
        System.out.println(s2 == s4); //true
        System.out.println(s2.equals(s3)); //true
        System.out.println(s1 == s2); //false 两者虽然都指向常量池，但数据空间不一样

    }
}
