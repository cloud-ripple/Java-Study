package com.chapter10.enum_;

/**
 * 日期：2023/1/28
 * 需求/说明：enum关键字实现枚举
 */

public class Enumeration03 {
    public static void main(String[] args) {
        System.out.println(Season3.SPRING);
    }
}

enum Season3 { //枚举类

    //如果使用enum关键字类实现枚举类
    //1. 使用关键字 enum 替代class
    //2. public static final Season3 SPRING = new Season3("春天", "温暖") 直接使用
    // SPRING("春天", "温暖") ----> 常量对象名(构造器参数) 代替。这里必须指明，它调用的是哪个构造器
    //3. 如果有多个常量(对象),使用逗号间隔即可
    //SPRING("春天", "温暖"); 等价于----> public static final Season3 SPRING = new Season3("春天", "温暖");
    /** 如果使用enum来实现枚举，要求将定义的常量对象写在最前面 */
    SPRING("春天", "温暖"), //该枚举对象的位置编号 ---> 0
    WINTER("冬天", "寒冷"), //编号 1
    SUMMER("夏天", "炎热"), // 2
    AUTUMN("秋天", "凉爽"), // 3
    SPRING2("春天", "温暖"), // 4
    What(); //调用无参构造器，等价于 What; // 5
    //4. 如果使用无参构造器创建枚举对象，则实参列表和小括号都可以省略。
    /** 其它属性写在后面 */
    private String name;
    private String desc; //描述

    private Season3() { //无参构造器

    }
    private Season3(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public String getDesc() {
        return desc;
    }

    @Override
    public String toString() {
        return "Season{" +
                "name='" + name + '\'' +
                ", desc='" + desc + '\'' +
                '}';
    }
}