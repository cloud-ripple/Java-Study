package com.chapter10.enum_;

/**
 * 日期：2023/1/28
 * 需求/说明：
 * (1) 使用enum关键字后，就不能再继承其它类了，
 * 因为enum修饰的枚举类会默认隐式的继承父类Enum,而java是单继承机制
 * (2) 枚举类和普通类一样，可以实现接口，如下形式：
 enum 类名 implements 接口1，接口2 {

  }
 */

public class EnumDetail {
    public static void main(String[] args) {
        Music.CLASSIC_MUSIC.playing(); //访问Music类的静态属性，并调用其方法
    }
}

interface IPlaying {
    public abstract void playing();
}

enum Music implements IPlaying {
    //使用enum修饰类后
    CLASSIC_MUSIC; //定义一个枚举对象(常量)，CLASSIC_MUSIC就是Music枚举类的一个对象名
    //等价于 public static final Music CLASSIC_MUSIC = new Music();

    @Override
    public void playing() {
        System.out.println("正在播放音乐..");
    }
}