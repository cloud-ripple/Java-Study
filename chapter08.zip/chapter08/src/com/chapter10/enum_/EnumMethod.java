package com.chapter10.enum_;

/**
 * 日期：2023/1/28
 * 需求/说明：演示Enum类各种方法的使用
 */

public class EnumMethod {
    //enum类常用方法说明
    //使用关键字enum时，会隐式继承 Enum类，这样就可以使用Enum类的相关方法。
    //(1) toString(): Enum类已经重写过了，返回的是当前对象名，子类可以重写该方法，用于返回对象的属性信息
    //(2) name(): 返回档期啊对象名(常量名)，子类中不能重写
    //(3) ordinal(): 返回当前对象的位置坐标号，默认从0开始
    //(4) values(): 返回当前枚举类中所有的常量(对象)
    //(5) valuesOf(): 将字符串转换成枚举对象，要求字符串必须为已有的常量名，否则报异常
    //(6) compareTo(): 比较两个枚举常量，比较的是位置号。

    public static void main(String[] args) {
        //以使用Season3 枚举类，来演示各种方法
        Season3 autumn = Season3.AUTUMN; //秋天对象

        System.out.println(autumn.name()); //输出枚举对象的名字
        System.out.println(autumn.ordinal()); //输出该枚举对象的次序/编号，从0 开始

        Season3[] values = Season3.values(); //返回一个数组
        for (Season3 season : values) {
            System.out.println(season); //调用toString()方法
        }

        //根据你输入的 "AUTUMN"字符串到 Season3的枚举对象去查找
        //如果找到了，就返回，如果没有找到就报错
        Season3 autumn1 = Season3.valueOf("AUTUMN"); //5.
        System.out.println(autumn1); //调用toString()方法

        //把Season3.AUTUMN枚举对象的编号 和 Season3.SUMMER枚举对象的编号比较，两者相减
        System.out.println(Season3.AUTUMN.compareTo(Season3.SUMMER)); //3-2 --> 1

//        int[] nums = {1, 2, 9};
//        //普通的for循环
//        for (int i = 0; i < nums.length; i++) {
//            System.out.println(nums[i]);
//        }
//        //增强，简化的for循环  效果等价
//        //执行流程：依次从nums数组中去除数据，赋给i,如果取值完毕，则退出for
//        for (int i: nums) {
//            System.out.println("i = " + i);
//        }
    }
}
