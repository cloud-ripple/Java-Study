package com.chapter10.enum_;

/**
 * 日期：2023/1/28
 * 需求/说明：
 * 声明Week枚举类，其中包含星期一到星期日的定义，使用values方法，返回所有的枚举数组，并遍历，输出
 */

public class EnumExercise01 {
    public static void main(String[] args) {
        Week[] weeks = Week.values(); //获取所有枚举对象，返回一个数组
        for(Week week : weeks ) {
            System.out.println(week); //输出对象时，调用toString()方法
        }
    }
}
enum Week {
    //定义7个枚举对象，----> 对象名(构造器参数)
    MONDAY("星期一"),
    TUESDAY("星期二"),
    WEDNESDAY("星期三"),
    THURSDAY("星期四"),
    FRIDAY("星期五"),
    SATURDAY("星期六"),
    SUNDAY("星期天");

    private String name;

    private Week(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Week{" +
                "name='" + name + '\'' +
                '}';
    }
}